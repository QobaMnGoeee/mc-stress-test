package dev.bigshulker;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ShulkerListener implements Listener {

    private final BigShulkerPlugin plugin;
    private final ShulkerManager manager;

    // Қай ойыншы қай шалкерді ашып отыр (UUID -> шалкер item)
    private final Map<UUID, ItemStack> openShulkers = new HashMap<>();
    // Ойыншының инвентарындағы қай слотта шалкер бар
    private final Map<UUID, Integer> shulkerSlots = new HashMap<>();

    public ShulkerListener(BigShulkerPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getShulkerManager();
    }

    /**
     * Ойыншы шалкерді қолда ұстап оң батырмамен басқанда ашу
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR &&
                event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (!manager.isBigShulker(item)) return;

        // Блокка қарап тұрса — блокты өзінің әрекетін болдырма
        event.setCancelled(true);

        if (!player.hasPermission("bigshulker.use")) {
            player.sendMessage("§cСізде 54-слоттық шалкерді ашуға рұқсат жоқ!");
            return;
        }

        // Шалкерді аш
        openShulker(player, item, player.getInventory().getHeldItemSlot());
    }

    /**
     * Шалкерді ашу
     */
    private void openShulker(Player player, ItemStack shulkerItem, int slot) {
        Inventory inv = manager.openBigShulker(shulkerItem);
        openShulkers.put(player.getUniqueId(), shulkerItem.clone());
        shulkerSlots.put(player.getUniqueId(), slot);
        player.openInventory(inv);
        player.sendMessage("§5§l✦ §d54 Слоттық шалкер ашылды!");
    }

    /**
     * Инвентар жабылғанда заттарды сақтау
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();

        if (!openShulkers.containsKey(uuid)) return;

        ItemStack originalShulker = openShulkers.get(uuid);
        int slot = shulkerSlots.get(uuid);
        Inventory inv = event.getInventory();

        // Заттарды шалкерге сақта
        manager.saveContents(originalShulker, inv);

        // Инвентардағы шалкерді жаңарт
        player.getInventory().setItem(slot, originalShulker);
        player.updateInventory();

        openShulkers.remove(uuid);
        shulkerSlots.remove(uuid);

        player.sendMessage("§5§l✦ §7Шалкер заттары сақталды!");
    }

    /**
     * Шалкер ашық кезде ішіне шалкер салуға тыйым
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();

        if (!openShulkers.containsKey(uuid)) return;

        // Ішіне шалкер салуға болмайды (рекурсия болмасын)
        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();

        if (cursor != null && manager.isBigShulker(cursor)) {
            event.setCancelled(true);
            player.sendMessage("§cШалкер ішіне шалкер сала алмайсыз!");
            return;
        }

        if (current != null && manager.isBigShulker(current) &&
                event.getRawSlot() < event.getInventory().getSize()) {
            event.setCancelled(true);
            player.sendMessage("§cШалкер ішіне шалкер сала алмайсыз!");
        }
    }

    /**
     * Drag event үшін де тексеру
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();

        if (!openShulkers.containsKey(uuid)) return;

        if (manager.isBigShulker(event.getOldCursor())) {
            event.setCancelled(true);
            player.sendMessage("§cШалкер ішіне шалкер сала алмайсыз!");
        }
    }
}
