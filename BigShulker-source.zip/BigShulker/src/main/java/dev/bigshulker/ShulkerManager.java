package dev.bigshulker;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.List;

public class ShulkerManager {

    private final BigShulkerPlugin plugin;

    // NBT Keys
    public final NamespacedKey KEY_IS_BIG_SHULKER;
    public final NamespacedKey KEY_SHULKER_CONTENTS;

    public ShulkerManager(BigShulkerPlugin plugin) {
        this.plugin = plugin;
        this.KEY_IS_BIG_SHULKER = new NamespacedKey(plugin, "is_big_shulker");
        this.KEY_SHULKER_CONTENTS = new NamespacedKey(plugin, "shulker_contents");
    }

    /**
     * Жаңа 54 слоттық шалкер бокс жасайды
     */
    public ItemStack createBigShulker() {
        ItemStack shulker = new ItemStack(Material.PURPLE_SHULKER_BOX);
        ItemMeta meta = shulker.getItemMeta();

        meta.displayName(net.kyori.adventure.text.Component.text("§5§l✦ 54 Слоттық Шалкер ✦"));
        meta.lore(List.of(
                net.kyori.adventure.text.Component.text("§7━━━━━━━━━━━━━━━━━━━━━━"),
                net.kyori.adventure.text.Component.text("§d54 зат сыйдыратын арнайы шалкер"),
                net.kyori.adventure.text.Component.text("§7Жерге қойып аша аласыз"),
                net.kyori.adventure.text.Component.text("§7━━━━━━━━━━━━━━━━━━━━━━"),
                net.kyori.adventure.text.Component.text("§6✦ Донат шалкер §e[PREMIUM]")
        ));

        // NBT арқылы белгіле
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(KEY_IS_BIG_SHULKER, PersistentDataType.BOOLEAN, true);

        shulker.setItemMeta(meta);
        return shulker;
    }

    /**
     * Затты 54 слоттық шалкер екенін тексереді
     */
    public boolean isBigShulker(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        if (!item.hasItemMeta()) return false;
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        return pdc.has(KEY_IS_BIG_SHULKER, PersistentDataType.BOOLEAN);
    }

    /**
     * 54 слоттық GUI ашады
     */
    public Inventory openBigShulker(ItemStack shulkerItem) {
        Inventory inv = Bukkit.createInventory(null, 54,
                net.kyori.adventure.text.Component.text("§5✦ 54 Слоттық Шалкер ✦"));

        // Бұрын сақталған заттарды жүктейді
        String saved = getSavedContents(shulkerItem);
        if (saved != null) {
            ItemStack[] contents = deserializeContents(saved);
            if (contents != null) {
                inv.setContents(contents);
            }
        }

        return inv;
    }

    /**
     * Инвентар мазмұнын шалкерге сақтайды
     */
    public void saveContents(ItemStack shulkerItem, Inventory inventory) {
        String serialized = serializeContents(inventory.getContents());
        if (serialized == null) return;

        ItemMeta meta = shulkerItem.getItemMeta();
        meta.getPersistentDataContainer().set(KEY_SHULKER_CONTENTS,
                PersistentDataType.STRING, serialized);

        // Лорені жаңарт — зат санын көрсет
        int count = 0;
        for (ItemStack item : inventory.getContents()) {
            if (item != null && item.getType() != Material.AIR) count++;
        }

        int finalCount = count;
        meta.lore(List.of(
                net.kyori.adventure.text.Component.text("§7━━━━━━━━━━━━━━━━━━━━━━"),
                net.kyori.adventure.text.Component.text("§d54 зат сыйдыратын арнайы шалкер"),
                net.kyori.adventure.text.Component.text("§7Жерге қойып аша аласыз"),
                net.kyori.adventure.text.Component.text("§eЗаттар: §f" + finalCount + " §7/ 54"),
                net.kyori.adventure.text.Component.text("§7━━━━━━━━━━━━━━━━━━━━━━"),
                net.kyori.adventure.text.Component.text("§6✦ Донат шалкер §e[PREMIUM]")
        ));

        shulkerItem.setItemMeta(meta);
    }

    /**
     * Сақталған мазмұнды алады
     */
    public String getSavedContents(ItemStack item) {
        if (!item.hasItemMeta()) return null;
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        return pdc.get(KEY_SHULKER_CONTENTS, PersistentDataType.STRING);
    }

    /**
     * Инвентар мазмұнын Base64 string-ге айналдырады
     */
    private String serializeContents(ItemStack[] contents) {
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            BukkitObjectOutputStream dataOutput = new BukkitObjectOutputStream(outputStream);
            dataOutput.writeInt(contents.length);
            for (ItemStack item : contents) {
                dataOutput.writeObject(item);
            }
            dataOutput.close();
            return Base64.getEncoder().encodeToString(outputStream.toByteArray());
        } catch (Exception e) {
            plugin.getLogger().warning("Шалкер мазмұнын сақтау қатесі: " + e.getMessage());
            return null;
        }
    }

    /**
     * Base64 string-ді инвентар мазмұнына айналдырады
     */
    private ItemStack[] deserializeContents(String data) {
        try {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(Base64.getDecoder().decode(data));
            BukkitObjectInputStream dataInput = new BukkitObjectInputStream(inputStream);
            int length = dataInput.readInt();
            ItemStack[] items = new ItemStack[length];
            for (int i = 0; i < length; i++) {
                items[i] = (ItemStack) dataInput.readObject();
            }
            dataInput.close();
            return items;
        } catch (Exception e) {
            plugin.getLogger().warning("Шалкер мазмұнын жүктеу қатесі: " + e.getMessage());
            return null;
        }
    }
}
