package dev.bigshulker;

import org.bukkit.plugin.java.JavaPlugin;

public class BigShulkerPlugin extends JavaPlugin {

    private static BigShulkerPlugin instance;
    private ShulkerManager shulkerManager;

    @Override
    public void onEnable() {
        instance = this;
        shulkerManager = new ShulkerManager(this);

        // Register listeners
        getServer().getPluginManager().registerEvents(new ShulkerListener(this), this);

        // Register command
        GiveShulkerCommand giveCommand = new GiveShulkerCommand(this);
        getCommand("giveshulker").setExecutor(giveCommand);
        getCommand("giveshulker").setTabCompleter(giveCommand);

        getLogger().info("BigShulker плагині іске қосылды! 54 слоттық шалкер дайын.");
    }

    @Override
    public void onDisable() {
        getLogger().info("BigShulker плагині өшірілді.");
    }

    public static BigShulkerPlugin getInstance() {
        return instance;
    }

    public ShulkerManager getShulkerManager() {
        return shulkerManager;
    }
}
