package kz.nova.clans.data;

public class ClanMember {
    private String name;
    private ClanRole role;
    private final long joined;

    public ClanMember(String name, ClanRole role) {
        this.name = name;
        this.role = role;
        this.joined = System.currentTimeMillis();
    }

    public ClanMember(String name, ClanRole role, long joined) {
        this.name = name;
        this.role = role;
        this.joined = joined;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public ClanRole getRole() { return role; }
    public void setRole(ClanRole role) { this.role = role; }

    public long getJoined() { return joined; }
}
