package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanRole;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.DataManager;
import kz.nova.clans.managers.MenuManager;
import kz.nova.clans.managers.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class ClanCommand implements CommandExecutor, TabCompleter {

    private final NovaClans plugin;

    public ClanCommand(NovaClans plugin) {
        this.plugin = plugin;
    }

    private ClanManager getClanManager()   { return plugin.getClanManager(); }
    private DataManager getDataManager()   { return plugin.getDataManager(); }
    private MessageManager getMessageManager() { return plugin.getMessageManager(); }
    private MenuManager getMenuManager()   { return plugin.getMenuManager(); }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            getMessageManager().send(sender, "player-only");
            return true;
        }

        if (args.length == 0) {
            getMenuManager().openMainMenu(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "help"    -> handleHelp(player);
            case "create"  -> handleCreate(player, args);
            case "delete"  -> getClanManager().deleteClan(player);
            case "invite"  -> handleInvite(player, args);
            case "accept"  -> getClanManager().acceptInvite(player);
            case "deny"    -> getClanManager().denyInvite(player);
            case "kick"    -> handleKick(player, args);
            case "promote" -> handlePromote(player, args);
            case "role"    -> handleRole(player, args);
            case "chat"    -> getClanManager().toggleClanChat(player);
            case "storage" -> handleStorage(player, args);
            case "quest"   -> getMenuManager().openQuestMenu(player);
            case "top"     -> getMenuManager().openTopMenu(player);
            case "leave"   -> getClanManager().leaveClan(player);   // ← ЖАҢА КОМАНДА
            default        -> getMessageManager().send(player, "invalid-usage");
        }
        return true;
    }

    private void handleHelp(Player player) {
        getMessageManager().sendList(player, "clan-help");
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            getMessageManager().sendRaw(player, ": &e/clan create <атыңыз>");
            return;
        }
        getClanManager().createClan(player, args[1]);
    }

    private void handleInvite(Player player, String[] args) {
        if (args.length < 2) {
            getMessageManager().sendRaw(player, ": &e/clan invite <ойыншы>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            getMessageManager().send(player, "player-not-found", "{player}", args[1]);
            return;
        }
        getClanManager().invitePlayer(player, target);
    }

    private void handleKick(Player player, String[] args) {
        if (args.length < 2) {
            getMessageManager().sendRaw(player, ": &e/clan kick <ойыншы>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            getMessageManager().send(player, "player-not-found", "{player}", args[1]);
            return;
        }
        getClanManager().kickPlayer(player, target);
    }

    private void handlePromote(Player player, String[] args) {
        if (args.length < 2) {
            getMessageManager().sendRaw(player, ": &e/clan promote <ойыншы>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            getMessageManager().send(player, "player-not-found", "{player}", args[1]);
            return;
        }
        getClanManager().promoteMember(player, target);
    }

    private void handleRole(Player player, String[] args) {
        if (args.length < 3) {
            getMessageManager().sendRaw(player, ": &e/clan role <ойыншы> <MEMBER|DEPUTY>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            getMessageManager().send(player, "player-not-found", "{player}", args[1]);
            return;
        }
        ClanRole role = ClanRole.fromString(args[2]);
        if (role == null || role == ClanRole.LEADER) {
            getMessageManager().send(player, "clan-role-invalid");
            return;
        }
        getClanManager().setRole(player, target, role);
    }

    private void handleStorage(Player player, String[] args) {
        if (args.length == 1) {
            getMenuManager().openStorageInfoMenu(player);
            return;
        }
        switch (args[1].toLowerCase()) {
            case "add" -> {
                if (args.length < 3) {
                    getMessageManager().sendRaw(player, ": &e/clan storage add <сумма>");
                    return;
                }
                try {
                    double amount = Double.parseDouble(args[2]);
                    getClanManager().depositToStorage(player, amount);
                } catch (NumberFormatException e) {
                    getMessageManager().send(player, "clan-storage-invalid-amount");
                }
            }
            case "take" -> {
                if (args.length < 3) {
                    getMessageManager().sendRaw(player, ": &e/clan storage take <сумма>");
                    return;
                }
                try {
                    double amount = Double.parseDouble(args[2]);
                    getClanManager().withdrawFromStorage(player, amount);
                } catch (NumberFormatException e) {
                    getMessageManager().send(player, "clan-storage-invalid-amount");
                }
            }
            default -> getMenuManager().openStorageInfoMenu(player);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("help", "create", "delete", "invite", "accept", "deny",
                    "kick", "promote", "role", "chat", "storage", "quest", "top", "leave");
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("invite")
                || args[0].equalsIgnoreCase("kick")
                || args[0].equalsIgnoreCase("promote")
                || args[0].equalsIgnoreCase("role"))) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("role")) {
            return Arrays.asList("MEMBER", "DEPUTY");
        }
        return List.of();
    }
}
