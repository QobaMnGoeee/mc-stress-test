package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class NovaClanAdminCommand implements CommandExecutor, TabCompleter {

    private final NovaClans plugin;
    private static final String PREFIX = "&8[&eNovaClans&8] &r&e";

    public NovaClanAdminCommand(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) {
            plugin.getMessageManager().send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            sendAdminHelp(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload"  -> handleReload(sender);
            case "storage" -> handleStorage(sender, args);
            case "rename"  -> handleRename(sender, args);
            case "delete"  -> handleDelete(sender, args);
            case "levelup" -> handleLevelUp(sender, args);
            default        -> sendAdminHelp(sender);
        }
        return true;
    }

    private void sendAdminHelp(CommandSender sender) {
        plugin.getMessageManager().sendRaw(sender, PREFIX + "Admin Help:");
        plugin.getMessageManager().sendRaw(sender, PREFIX + "/novaclans reload &7— конфигты қайта жүктеу");
        plugin.getMessageManager().sendRaw(sender, PREFIX + "/novaclans storage &b<клан> &7— клан қоймасын ашу");
        plugin.getMessageManager().sendRaw(sender, PREFIX + "/novaclans rename &b<ескі> <жаңа> &7— кланды атын өзгерту");
        plugin.getMessageManager().sendRaw(sender, PREFIX + "/novaclans delete &b<клан> &7— кланды жою");
        plugin.getMessageManager().sendRaw(sender, PREFIX + "/novaclans levelup &b<1-5> <клан> &7— деңгей көтеру");
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        plugin.getMenuManager().reload();
        plugin.getMessageManager().reload();
        plugin.getMessageManager().sendRaw(sender, PREFIX + "Конфигурация қайта жүктелді.");
    }

    private void handleStorage(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().sendRaw(sender, ": &e/novaclans storage <клан>");
            return;
        }
        if (args.length < 2) {
            plugin.getMessageManager().sendRaw(sender, ": &e/novaclans storage <клан>");
            return;
        }
        ClanData clan = plugin.getDataManager().getClan(args[1]);
        if (clan == null) {
            plugin.getMessageManager().sendRaw(sender, "&cКлан табылмады: " + args[1]);
            return;
        }
        plugin.getMenuManager().openAdminVault(player, clan);
    }

    private void handleRename(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageManager().sendRaw(sender, ": &e/novaclans rename <ескі> <жаңа>");
            return;
        }
        ClanData clan = plugin.getDataManager().getClan(args[1]);
        if (clan == null) {
            plugin.getMessageManager().sendRaw(sender, "&cКлан табылмады: " + args[1]);
            return;
        }
        String oldName = clan.getName();
        plugin.getDataManager().renameClan(clan, args[2]);
        plugin.getDataManager().save();
        plugin.getMessageManager().sendRaw(sender, PREFIX + oldName + " → " + args[2]);
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            plugin.getMessageManager().sendRaw(sender, ": &e/novaclans delete <клан>");
            return;
        }
        if (!plugin.getDataManager().clanExists(args[1])) {
            plugin.getMessageManager().sendRaw(sender, "&cКлан табылмады: " + args[1]);
            return;
        }
        plugin.getDataManager().deleteClan(args[1]);
        plugin.getDataManager().save();
        plugin.getMessageManager().sendRaw(sender, PREFIX + args[1] + " кланы жойылды.");
    }

    private void handleLevelUp(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageManager().sendRaw(sender, ": &e/novaclans levelup <1-5> <клан>");
            return;
        }
        int level;
        try { level = Integer.parseInt(args[1]); }
        catch (NumberFormatException e) {
            plugin.getMessageManager().sendRaw(sender, "&cДеңгей 1-5 аралығында болуы керек.");
            return;
        }
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (level < 1 || level > maxLevel) {
            plugin.getMessageManager().sendRaw(sender, "&cДеңгей 1-" + maxLevel + " аралығында болуы керек.");
            return;
        }
        ClanData clan = plugin.getDataManager().getClan(args[2]);
        if (clan == null) {
            plugin.getMessageManager().sendRaw(sender, "&cКлан табылмады: " + args[2]);
            return;
        }
        clan.setLevel(level);
        plugin.getDataManager().save();
        plugin.getMessageManager().sendRaw(sender, PREFIX + clan.getName() + " кланының деңгейі " + level + " болды.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return Arrays.asList("reload", "storage", "rename", "delete", "levelup");
        if (args.length >= 2) {
            return plugin.getDataManager().getAllClans().stream()
                    .map(kz.nova.clans.data.ClanData::getName).toList();
        }
        return List.of();
    }
}
