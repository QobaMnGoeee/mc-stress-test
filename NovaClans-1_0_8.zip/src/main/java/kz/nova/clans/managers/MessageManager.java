package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.List;

public class MessageManager {

    private final NovaClans plugin;
    private YamlConfiguration messages;
    private static final String PREFIX = "&8[&eNovaClans&8] &r";

    public MessageManager(NovaClans plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) plugin.saveResource("messages.yml", false);
        messages = YamlConfiguration.loadConfiguration(file);
    }

    public String getRaw(String key, Object... args) {
        String msg = messages.getString(key, "&c[NovaClans] Хабарлама табылмады: " + key);
        if (args != null) {
            for (int i = 0; i + 1 < args.length; i += 2) {
                msg = msg.replace(String.valueOf(args[i]), String.valueOf(args[i + 1]));
            }
        }
        return msg;
    }

    public Component parse(String text) {
        if (text.startsWith("&") || text.contains("&")) {
            return LegacyComponentSerializer.legacyAmpersand().deserialize(text);
        }
        return MiniMessage.miniMessage().deserialize(text);
    }

    public void send(CommandSender sender, String key, Object... args) {
        String msg = getRaw(key, args);
        sender.sendMessage(parse(msg));
    }

    public void sendRaw(CommandSender sender, String text) {
        sender.sendMessage(parse(text));
    }

    public void sendList(CommandSender sender, String key, Object... args) {
        List<?> list = messages.getList(key);
        if (list == null || list.isEmpty()) return;
        for (Object item : list) {
            String line = String.valueOf(item);
            if (args != null) {
                for (int i = 0; i + 1 < args.length; i += 2) {
                    line = line.replace(String.valueOf(args[i]), String.valueOf(args[i + 1]));
                }
            }
            sender.sendMessage(parse(line));
        }
    }

    public void broadcast(String key, Object... args) {
        List<?> list = messages.getList(key);
        if (list == null || list.isEmpty()) {
            String msg = getRaw(key, args);
            Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(parse(msg)));
            return;
        }
        for (Object item : list) {
            String line = String.valueOf(item);
            if (args != null) {
                for (int i = 0; i + 1 < args.length; i += 2) {
                    line = line.replace(String.valueOf(args[i]), String.valueOf(args[i + 1]));
                }
            }
            Component comp = parse(line);
            Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(comp));
        }
    }
}
