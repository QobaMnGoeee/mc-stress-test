package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.*;

public class ClanManager {

    private final NovaClans plugin;
    private final Map<UUID, PendingInvite> pendingInvites = new HashMap<>();
    private final Set<UUID> clanChatToggled = new HashSet<>();
    private Economy economy;

    public ClanManager(NovaClans plugin) {
        this.plugin = plugin;
        setupVault();
    }

    private void setupVault() {
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp != null) {
            economy = rsp.getProvider();
        } else {
            plugin.getLogger().warning("Vault Economy not found!");
        }
    }

    public Economy getEconomy() { return economy; }

    private DataManager getDataManager() { return plugin.getDataManager(); }
    private MessageManager getMessageManager() { return plugin.getMessageManager(); }

    // ─── Create / Delete ────────────────────────────────────────────────────

    public boolean createClan(Player player, String name) {
        int minLen = plugin.getConfig().getInt("clan-name-min-length", 3);
        int maxLen = plugin.getConfig().getInt("clan-name-max-length", 16);
        double price = plugin.getConfig().getDouble("clan-create-price", 50000);

        if (name.length() < minLen || name.length() > maxLen || !name.matches("[a-zA-Z0-9_]+")) {
            getMessageManager().send(player, "clan-create-invalid-name",
                    "{min}", minLen, "{max}", maxLen);
            return false;
        }
        if (getDataManager().isInClan(player.getUniqueId())) {
            getMessageManager().send(player, "already-in-clan",
                    "{clan}", getDataManager().getClanByPlayer(player.getUniqueId()).getName());
            return false;
        }
        if (getDataManager().clanExists(name)) {
            getMessageManager().send(player, "clan-create-name-taken");
            return false;
        }
        if (economy != null && !economy.has(player, price)) {
            getMessageManager().send(player, "clan-create-no-money",
                    "{amount}", formatMoney(price));
            return false;
        }
        if (economy != null) economy.withdrawPlayer(player, price);
        boolean pvpDefault = plugin.getConfig().getBoolean("pvp-enabled-by-default", true);
        ClanData clan = new ClanData(name, player.getUniqueId(), pvpDefault);
        clan.addMember(player.getUniqueId(), player.getName(), ClanRole.LEADER);
        getDataManager().createClan(clan);
        getMessageManager().send(player, "clan-create-success",
                "{clan}", name, "{amount}", formatMoney(price));
        return true;
    }

    public boolean deleteClan(Player player) {
        if (!getDataManager().isInClan(player.getUniqueId())) {
            getMessageManager().send(player, "not-in-clan");
            return false;
        }
        ClanData clan = getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan.getMemberRole(player.getUniqueId()) != ClanRole.LEADER) {
            getMessageManager().send(player, "clan-delete-no-permission");
            return false;
        }
        String clanName = clan.getName();
        for (UUID uuid : new HashSet<>(clan.getMembers().keySet())) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null && !member.equals(player)) {
                getMessageManager().send(member, "clan-kick-notify", "{clan}", clanName);
            }
        }
        getDataManager().deleteClan(clanName);
        getMessageManager().send(player, "clan-delete-success", "{clan}", clanName);
        return true;
    }

    // ─── Leave (NEW) ─────────────────────────────────────────────────────────

    public boolean leaveClan(Player player) {
        if (!getDataManager().isInClan(player.getUniqueId())) {
            getMessageManager().send(player, "not-in-clan");
            return false;
        }
        ClanData clan = getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan.getMemberRole(player.getUniqueId()) == ClanRole.LEADER) {
            getMessageManager().send(player, "clan-leave-leader-error");
            return false;
        }
        String clanName = clan.getName();
        getDataManager().removePlayerFromClan(player.getUniqueId(), clan);
        getMessageManager().send(player, "clan-leave-success", "{clan}", clanName);
        notifyClan(clan, "clan-leave-notify", player.getUniqueId(),
                "{player}", player.getName(), "{clan}", clanName);
        getDataManager().save();
        return true;
    }

    // ─── Invite / Accept / Deny ──────────────────────────────────────────────

    public boolean invitePlayer(Player inviter, Player target) {
        if (!getDataManager().isInClan(inviter.getUniqueId())) {
            getMessageManager().send(inviter, "not-in-clan");
            return false;
        }
        ClanData clan = getDataManager().getClanByPlayer(inviter.getUniqueId());
        ClanRole inviterRole = clan.getMemberRole(inviter.getUniqueId());
        if (!inviterRole.isAtLeast(ClanRole.DEPUTY)) {
            getMessageManager().send(inviter, "clan-invite-no-permission");
            return false;
        }
        if (getDataManager().isInClan(target.getUniqueId())) {
            getMessageManager().send(inviter, "target-already-in-clan", "{player}", target.getName());
            return false;
        }
        int maxMembers = getMaxMembersForLevel(clan.getLevel());
        if (clan.getMemberCount() >= maxMembers) {
            getMessageManager().send(inviter, "clan-members-limit");
            return false;
        }
        pendingInvites.put(target.getUniqueId(), new PendingInvite(inviter.getUniqueId(), clan.getName()));
        getMessageManager().send(inviter, "clan-invite-sent", "{player}", target.getName());
        getMessageManager().send(target, "clan-invite-received",
                "{player}", inviter.getName(), "{clan}", clan.getName());
        Bukkit.getScheduler().runTaskLater(plugin, () -> pendingInvites.remove(target.getUniqueId()), 1200L);
        return true;
    }

    public boolean acceptInvite(Player player) {
        PendingInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            getMessageManager().send(player, "clan-invite-no-pending");
            return false;
        }
        ClanData clan = getDataManager().getClan(invite.getClanName());
        if (clan == null) return false;
        getDataManager().addPlayerToClan(player.getUniqueId(), clan, ClanRole.MEMBER, player.getName());
        getMessageManager().send(player, "clan-invite-accepted", "{player}", player.getName(), "{clan}", clan.getName());
        notifyClan(clan, "clan-invite-accepted", player.getUniqueId(), "{player}", player.getName());
        getDataManager().save();
        return true;
    }

    public boolean denyInvite(Player player) {
        PendingInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            getMessageManager().send(player, "clan-invite-no-pending");
            return false;
        }
        Player inviter = Bukkit.getPlayer(invite.getInviterUUID());
        if (inviter != null) {
            getMessageManager().send(inviter, "clan-invite-denied", "{player}", player.getName());
        }
        return true;
    }

    // ─── Kick ────────────────────────────────────────────────────────────────

    public boolean kickPlayer(Player kicker, Player target) {
        if (!getDataManager().isInClan(kicker.getUniqueId())) {
            getMessageManager().send(kicker, "not-in-clan");
            return false;
        }
        ClanData clan = getDataManager().getClanByPlayer(kicker.getUniqueId());
        ClanRole kickerRole = clan.getMemberRole(kicker.getUniqueId());
        if (!kickerRole.isAtLeast(ClanRole.DEPUTY)) {
            getMessageManager().send(kicker, "clan-kick-no-permission");
            return false;
        }
        if (!clan.hasMember(target.getUniqueId())) {
            getMessageManager().send(kicker, "target-not-in-clan", "{player}", target.getName());
            return false;
        }
        ClanRole targetRole = clan.getMemberRole(target.getUniqueId());
        if (targetRole == ClanRole.LEADER) {
            getMessageManager().send(kicker, "clan-kick-leader");
            return false;
        }
        if (kicker.getUniqueId().equals(target.getUniqueId())) {
            getMessageManager().send(kicker, "clan-kick-yourself");
            return false;
        }
        getDataManager().removePlayerFromClan(target.getUniqueId(), clan);
        getMessageManager().send(kicker, "clan-kick-success", "{player}", target.getName());
        getMessageManager().send(target, "clan-kick-notify", "{clan}", clan.getName());
        getDataManager().save();
        return true;
    }

    // ─── Promote (transfer leadership) ──────────────────────────────────────

    public boolean promoteMember(Player leader, Player target) {
        if (!getDataManager().isInClan(leader.getUniqueId())) {
            getMessageManager().send(leader, "not-in-clan");
            return false;
        }
        ClanData clan = getDataManager().getClanByPlayer(leader.getUniqueId());
        if (clan.getMemberRole(leader.getUniqueId()) != ClanRole.LEADER) {
            getMessageManager().send(leader, "clan-promote-no-permission");
            return false;
        }
        if (!clan.hasMember(target.getUniqueId())) {
            getMessageManager().send(leader, "target-not-in-clan", "{player}", target.getName());
            return false;
        }
        clan.getMember(leader.getUniqueId()).setRole(ClanRole.MEMBER);
        clan.getMember(target.getUniqueId()).setRole(ClanRole.LEADER);
        clan.setLeader(target.getUniqueId());
        getDataManager().save();
        getMessageManager().send(leader, "clan-promote-success", "{player}", target.getName());
        getMessageManager().send(target, "clan-promote-notify", "{clan}", clan.getName());
        return true;
    }

    // ─── Role ────────────────────────────────────────────────────────────────

    public boolean setRole(Player setter, Player target, ClanRole newRole) {
        if (!getDataManager().isInClan(setter.getUniqueId())) {
            getMessageManager().send(setter, "not-in-clan");
            return false;
        }
        ClanData clan = getDataManager().getClanByPlayer(setter.getUniqueId());
        if (clan.getMemberRole(setter.getUniqueId()) != ClanRole.LEADER) {
            getMessageManager().send(setter, "clan-role-no-permission");
            return false;
        }
        if (setter.getUniqueId().equals(target.getUniqueId())) {
            getMessageManager().send(setter, "clan-role-self");
            return false;
        }
        if (!clan.hasMember(target.getUniqueId())) {
            getMessageManager().send(setter, "target-not-in-clan", "{player}", target.getName());
            return false;
        }
        if (newRole == null) {
            getMessageManager().send(setter, "clan-role-invalid");
            return false;
        }
        clan.getMember(target.getUniqueId()).setRole(newRole);
        getDataManager().save();
        getMessageManager().send(setter, "clan-role-set",
                "{player}", target.getName(), "{role}", newRole.getDisplayName());
        getMessageManager().send(target, "clan-role-notify", "{role}", newRole.getDisplayName());
        return true;
    }

    // ─── Chat ────────────────────────────────────────────────────────────────

    public boolean toggleClanChat(Player player) {
        if (!getDataManager().isInClan(player.getUniqueId())) {
            getMessageManager().send(player, "not-in-clan");
            return false;
        }
        if (clanChatToggled.contains(player.getUniqueId())) {
            clanChatToggled.remove(player.getUniqueId());
            getMessageManager().send(player, "clan-chat-toggled-off");
            return false;
        } else {
            clanChatToggled.add(player.getUniqueId());
            getMessageManager().send(player, "clan-chat-toggled-on");
            return true;
        }
    }

    public boolean isClanChatToggled(UUID uuid) {
        return clanChatToggled.contains(uuid);
    }

    public void sendClanChat(Player player, String message) {
        ClanData clan = getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) return;
        String format = getMessageManager().getRaw("clan-chat-format",
                "{clan}", clan.getName(), "{player}", player.getName(), "{message}", message);
        for (UUID uuid : clan.getMembers().keySet()) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null) {
                getMessageManager().sendRaw(member, format);
            }
        }
    }

    // ─── PvP ─────────────────────────────────────────────────────────────────

    public void togglePvp(Player player) {
        if (!getDataManager().isInClan(player.getUniqueId())) {
            getMessageManager().send(player, "not-in-clan");
            return;
        }
        ClanData clan = getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan.getMemberRole(player.getUniqueId()) != ClanRole.LEADER) {
            getMessageManager().send(player, "clan-pvp-no-permission");
            return;
        }
        clan.togglePvp();
        getDataManager().save();
        if (clan.isPvpEnabled()) {
            getMessageManager().send(player, "clan-pvp-enabled");
        } else {
            getMessageManager().send(player, "clan-pvp-disabled");
        }
    }

    // ─── Storage / Economy ───────────────────────────────────────────────────

    public boolean depositToStorage(Player player, double amount) {
        if (!getDataManager().isInClan(player.getUniqueId())) {
            getMessageManager().send(player, "not-in-clan");
            return false;
        }
        if (amount <= 0) {
            getMessageManager().send(player, "clan-storage-invalid-amount");
            return false;
        }
        ClanData clan = getDataManager().getClanByPlayer(player.getUniqueId());
        if (economy != null && !economy.has(player, amount)) {
            getMessageManager().send(player, "clan-storage-no-money");
            return false;
        }
        if (economy != null) economy.withdrawPlayer(player, amount);
        clan.addBalance(amount);
        getDataManager().save();
        getMessageManager().send(player, "clan-storage-deposit-success",
                "{amount}", formatMoney(amount), "{balance}", formatMoney(clan.getBalance()));
        return true;
    }

    public boolean withdrawFromStorage(Player player, double amount) {
        if (!getDataManager().isInClan(player.getUniqueId())) {
            getMessageManager().send(player, "not-in-clan");
            return false;
        }
        if (amount <= 0) {
            getMessageManager().send(player, "clan-storage-invalid-amount");
            return false;
        }
        ClanData clan = getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan.getBalance() < amount) {
            getMessageManager().send(player, "clan-storage-not-enough",
                    "{balance}", formatMoney(clan.getBalance()));
            return false;
        }
        clan.addBalance(-amount);
        if (economy != null) economy.depositPlayer(player, amount);
        getDataManager().save();
        getMessageManager().send(player, "clan-storage-withdraw-success",
                "{amount}", formatMoney(amount), "{balance}", formatMoney(clan.getBalance()));
        return true;
    }

    // ─── Level / Points ──────────────────────────────────────────────────────

    public void addPoints(ClanData clan, long amount) {
        clan.addPoints(amount);
        checkLevelUp(clan);
        getDataManager().save();
    }

    private void checkLevelUp(ClanData clan) {
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (clan.getLevel() >= maxLevel) return;
        int nextLevel = clan.getLevel() + 1;
        long required = plugin.getConfig().getLong("levels." + nextLevel, Long.MAX_VALUE);
        if (clan.getPoints() >= required) {
            clan.setLevel(nextLevel);
            getMessageManager().broadcast("clan-levelup-broadcast",
                    "{clan}", clan.getName(),
                    "{level}", clan.getLevel(),
                    "{points}", clan.getPoints());
        }
    }

    public int getMaxMembersForLevel(int level) {
        return plugin.getConfig().getInt("max-members-by-level." + level + "-lvl",
                plugin.getConfig().getInt("clan-max-members", 30));
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    public String formatMoney(double amount) {
        if (amount == Math.floor(amount)) {
            return String.format("%,.0f", amount);
        }
        return String.format("%,.2f", amount);
    }

    public void notifyClan(ClanData clan, String messageKey, UUID except, Object... args) {
        for (UUID uuid : clan.getMembers().keySet()) {
            if (uuid.equals(except)) continue;
            Player member = Bukkit.getPlayer(uuid);
            if (member != null) {
                getMessageManager().send(member, messageKey, args);
            }
        }
    }

    public String getClanTag(ClanData clan) {
        return "&8[&e" + clan.getName() + "-" + clan.getLevel() + "&8] &r";
    }

    public Map<UUID, PendingInvite> getPendingInvites() { return pendingInvites; }

    // ─── PendingInvite ───────────────────────────────────────────────────────

    public static class PendingInvite {
        private final UUID inviterUUID;
        private final String clanName;

        public PendingInvite(UUID inviterUUID, String clanName) {
            this.inviterUUID = inviterUUID;
            this.clanName = clanName;
        }

        public UUID getInviterUUID() { return inviterUUID; }
        public String getClanName() { return clanName; }
    }
}
