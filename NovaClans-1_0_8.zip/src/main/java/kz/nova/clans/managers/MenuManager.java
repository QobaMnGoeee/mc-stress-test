package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

public class MenuManager {

    private final NovaClans plugin;
    private YamlConfiguration clanMenuConfig;
    private YamlConfiguration storageMenuConfig;
    private YamlConfiguration membersMenuConfig;
    private YamlConfiguration topMenuConfig;
    private YamlConfiguration questMenuConfig;

    // Track which players are in which storage vault: UUID -> clanName or "clanName:info"
    private final Map<UUID, String> openStorageMenu = new HashMap<>();

    public MenuManager(NovaClans plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File menuDir = new File(plugin.getDataFolder(), "menus");
        if (!menuDir.exists()) menuDir.mkdirs();

        // Save defaults if not present
        saveIfAbsent("menus/clan_menu.yml");
        saveIfAbsent("menus/storage.yml");
        saveIfAbsent("menus/members_menu.yml");
        saveIfAbsent("menus/top_menu.yml");
        saveIfAbsent("menus/quest_menu.yml");

        clanMenuConfig    = load("menus/clan_menu.yml");
        storageMenuConfig = load("menus/storage.yml");
        membersMenuConfig = load("menus/members_menu.yml");
        topMenuConfig     = load("menus/top_menu.yml");
        questMenuConfig   = load("menus/quest_menu.yml");
    }

    private void saveIfAbsent(String resource) {
        File f = new File(plugin.getDataFolder(), resource);
        if (!f.exists()) plugin.saveResource(resource, false);
    }

    private YamlConfiguration load(String resource) {
        return YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), resource));
    }

    // ─── Open Main Menu ──────────────────────────────────────────────────────

    public void openMainMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        if (dm.isInClan(player.getUniqueId())) {
            openClanMenu(player, dm.getClanByPlayer(player.getUniqueId()));
        } else {
            openNoClanMenu(player);
        }
    }

    private void openNoClanMenu(Player player) {
        ConfigurationSection sec = clanMenuConfig.getConfigurationSection("no-clan-menu");
        if (sec == null) return;
        int rows = sec.getInt("rows", 3);
        String titleRaw = sec.getString("title", "&8Клан Мәзірі");
        Inventory inv = Bukkit.createInventory(null, rows * 9, parse(titleRaw));
        ConfigurationSection items = sec.getConfigurationSection("items");
        if (items != null) fillItems(inv, items, player, null);
        player.openInventory(inv);
    }

    private void openClanMenu(Player player, ClanData clan) {
        ConfigurationSection sec = clanMenuConfig.getConfigurationSection("clan-menu");
        if (sec == null) return;
        int rows = sec.getInt("rows", 4);
        String titleRaw = applyPlaceholders(sec.getString("title", "&8Клан Мәзірі"), player, clan);
        Inventory inv = Bukkit.createInventory(null, rows * 9, parse(titleRaw));
        ConfigurationSection items = sec.getConfigurationSection("items");
        if (items != null) fillItems(inv, items, player, clan);
        player.openInventory(inv);
    }

    // ─── Storage Info Menu ───────────────────────────────────────────────────

    public void openStorageInfoMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        if (!dm.isInClan(player.getUniqueId())) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return;
        }
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        ConfigurationSection sec = storageMenuConfig.getConfigurationSection("storage-menu");
        if (sec == null) return;
        int rows = sec.getInt("rows", 4);
        String titleRaw = applyPlaceholders(sec.getString("title", "&8Клан Қоймасы"), player, clan);
        Inventory inv = Bukkit.createInventory(null, rows * 9, parse(titleRaw));
        ConfigurationSection items = sec.getConfigurationSection("items");
        if (items != null) fillItems(inv, items, player, clan);
        openStorageMenu.put(player.getUniqueId(), clan.getName() + ":info");
        player.openInventory(inv);
    }

    // ─── Vault (actual chest storage) ────────────────────────────────────────

    public void openClanVault(Player player) {
        DataManager dm = plugin.getDataManager();
        if (!dm.isInClan(player.getUniqueId())) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return;
        }
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        openVaultForClan(player, clan);
    }

    public void openVaultForClan(Player player, ClanData clan) {
        int level = clan.getLevel();
        int size = plugin.getConfig().getInt("storage.level-" + level, 27);
        size = Math.min(size, 54);
        size = (int) Math.ceil(size / 9.0) * 9;

        String title = plugin.getConfig().getString("storage.title-" + level,
                "&8Клан Қоймасы — " + clan.getName() + " &7(Lv." + level + ")");
        Inventory inv = Bukkit.createInventory(null, size, parse(title));
        ItemStack[] contents = clan.getStorageContents();
        if (contents != null) {
            for (int i = 0; i < Math.min(contents.length, size); i++) {
                inv.setItem(i, contents[i]);
            }
        }
        openStorageMenu.put(player.getUniqueId(), clan.getName() + ":vault");
        player.openInventory(inv);
    }

    public void openAdminVault(Player player, ClanData clan) {
        openVaultForClan(player, clan);
        openStorageMenu.put(player.getUniqueId(), clan.getName() + ":vault");
    }

    public void saveVaultAndClose(Player player, Inventory inv) {
        String tracking = openStorageMenu.remove(player.getUniqueId());
        if (tracking == null || !tracking.endsWith(":vault")) return;
        String clanName = tracking.replace(":vault", "");
        ClanData clan = plugin.getDataManager().getClan(clanName);
        if (clan != null) {
            clan.setStorageContents(inv.getContents());
            plugin.getDataManager().save();
        }
    }

    // ─── Members Menu ─────────────────────────────────────────────────────────

    public void openMembersMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        if (!dm.isInClan(player.getUniqueId())) return;
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        ConfigurationSection sec = membersMenuConfig.getConfigurationSection("members-menu");
        if (sec == null) return;
        int rows = sec.getInt("rows", 6);
        String titleRaw = applyPlaceholders(sec.getString("title", "&8Мүшелер"), player, clan);
        Inventory inv = Bukkit.createInventory(null, rows * 9, parse(titleRaw));

        // Add back button from config
        ConfigurationSection items = sec.getConfigurationSection("items");
        if (items != null) fillItems(inv, items, player, clan);

        // Dynamic member heads
        Material[] medals = {Material.GOLD_INGOT, Material.IRON_INGOT, Material.COPPER_INGOT,
                Material.EMERALD, Material.DIAMOND, Material.AMETHYST_SHARD,
                Material.LAPIS_LAZULI, Material.REDSTONE, Material.QUARTZ, Material.COAL};
        int slot = 10;
        for (Map.Entry<UUID, ClanMember> entry : clan.getMembers().entrySet()) {
            if (slot >= rows * 9 - 9) break;
            UUID uuid = entry.getKey();
            ClanMember member = entry.getValue();
            String roleColor = getRoleColorMM(member.getRole());
            String roleIcon = getRoleIcon(member.getRole());
            Player online = Bukkit.getPlayer(uuid);
            String status = online != null ? "<green>Онлайн" : "<red>Оффлайн";

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta skullMeta = (SkullMeta) head.getItemMeta();
            if (skullMeta != null) {
                skullMeta.setOwningPlayer(Bukkit.getOfflinePlayer(uuid));
                skullMeta.displayName(MiniMessage.miniMessage().deserialize(
                        "<gradient:#ffc800:#f2990a><bold> " + roleIcon + " " + member.getName() + "</bold></gradient>"));
                skullMeta.lore(List.of(
                        MiniMessage.miniMessage().deserialize(" "),
                        MiniMessage.miniMessage().deserialize(" <#ffc800>Рөл: " + roleColor + member.getRole().getDisplayName()),
                        MiniMessage.miniMessage().deserialize(" <#ffc800>Күй: " + status),
                        MiniMessage.miniMessage().deserialize(" ")
                ));
                head.setItemMeta(skullMeta);
            }
            inv.setItem(slot, head);
            slot++;
        }
        player.openInventory(inv);
    }

    // ─── Top Menu ─────────────────────────────────────────────────────────────

    public void openTopMenu(Player player) {
        ConfigurationSection sec = topMenuConfig.getConfigurationSection("top-menu");
        if (sec == null) return;
        int rows = sec.getInt("rows", 6);
        String titleRaw = sec.getString("title", "&8Клан Топ-10");
        Inventory inv = Bukkit.createInventory(null, rows * 9, parse(titleRaw));

        ConfigurationSection items = sec.getConfigurationSection("items");
        if (items != null) fillItems(inv, items, player, null);

        Material[] medals = {Material.GOLD_INGOT, Material.IRON_INGOT, Material.COPPER_INGOT,
                Material.EMERALD, Material.DIAMOND, Material.AMETHYST_SHARD,
                Material.LAPIS_LAZULI, Material.REDSTONE, Material.QUARTZ, Material.COAL};

        List<ClanData> topClans = plugin.getDataManager().getTopClans(10);
        int[] slots = {10, 12, 14, 16, 20, 22, 24, 28, 30, 32};
        for (int i = 0; i < topClans.size() && i < slots.length; i++) {
            ClanData clan = topClans.get(i);
            Material mat = i < medals.length ? medals[i] : Material.STONE;
            ItemStack item = buildItem(mat,
                    "<gradient:#ffc800:#f2990a><bold>#" + (i + 1) + " " + clan.getName() + "</bold></gradient>",
                    List.of(
                            " ",
                            " <#ffc800>Деңгей: <#f0e173>" + clan.getLevel(),
                            " <#ffc800>Ұпай: <#f0e173>" + clan.getPoints(),
                            " <#ffc800>Баланс: <#f0e173>" + plugin.getClanManager().formatMoney(clan.getBalance()) + "₸",
                            " <#ffc800>Мүшелер: <#f0e173>" + clan.getMemberCount(),
                            " "
                    ), false);
            inv.setItem(slots[i], item);
        }
        player.openInventory(inv);
    }

    // ─── Quest Menu ──────────────────────────────────────────────────────────

    public void openQuestMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        if (!dm.isInClan(player.getUniqueId())) return;
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        ConfigurationSection sec = questMenuConfig.getConfigurationSection("quest-menu");
        if (sec == null) return;
        int rows = sec.getInt("rows", 4);
        String titleRaw = applyPlaceholders(sec.getString("title", "&8Квесттер"), player, clan);
        Inventory inv = Bukkit.createInventory(null, rows * 9, parse(titleRaw));

        ConfigurationSection items = sec.getConfigurationSection("items");
        if (items != null) fillItems(inv, items, player, clan);

        // Dynamic quest items
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        long currentPoints = clan.getPoints();
        int currentLevel = clan.getLevel();

        for (int lvl = 1; lvl <= maxLevel; lvl++) {
            long required = plugin.getConfig().getLong("levels." + lvl, 0);
            boolean achieved = currentLevel >= lvl;
            Material mat = achieved ? Material.LIME_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE;
            String status = achieved ? "<green>✔ Орындалды" : "<red>✘ Орындалмады";
            String bar = buildProgressBar(currentPoints, required, 20);
            int slotIndex = 10 + (lvl - 1) * 2;
            ItemStack item = buildItem(mat,
                    "<gradient:#ffc800:#f2990a><bold>Деңгей " + lvl + "</bold></gradient>",
                    List.of(
                            " ",
                            " <#ffc800>Қажетті ұпай: <#f0e173>" + required,
                            " <#ffc800>Прогресс: " + bar,
                            " " + status,
                            " "
                    ), false);
            inv.setItem(slotIndex, item);
        }
        player.openInventory(inv);
    }

    // ─── Click handling ──────────────────────────────────────────────────────

    public void handleMainMenuSlotClick(Player player, int slot) {
        DataManager dm = plugin.getDataManager();
        boolean inClan = dm.isInClan(player.getUniqueId());
        String sectionKey = inClan ? "clan-menu" : "no-clan-menu";
        ConfigurationSection sec = clanMenuConfig.getConfigurationSection(sectionKey + ".items");
        if (sec == null) return;
        handleClickInConfig(player, slot, sec);
    }

    public void handleStorageInfoSlotClick(Player player, int slot) {
        ConfigurationSection sec = storageMenuConfig.getConfigurationSection("storage-menu.items");
        if (sec == null) return;
        handleClickInConfig(player, slot, sec);
    }

    public void handleSubMenuSlotClick(Player player, int slot, String menuKey) {
        YamlConfiguration cfg;
        String sectionKey;
        switch (menuKey) {
            case "members" -> { cfg = membersMenuConfig; sectionKey = "members-menu.items"; }
            case "top"     -> { cfg = topMenuConfig;     sectionKey = "top-menu.items"; }
            case "quest"   -> { cfg = questMenuConfig;   sectionKey = "quest-menu.items"; }
            default -> { return; }
        }
        ConfigurationSection sec = cfg.getConfigurationSection(sectionKey);
        if (sec == null) return;
        handleClickInConfig(player, slot, sec);
    }

    private void handleClickInConfig(Player player, int slot, ConfigurationSection items) {
        for (String key : items.getKeys(false)) {
            ConfigurationSection item = items.getConfigurationSection(key);
            if (item == null) continue;
            List<Integer> slots = resolveSlots(item);
            if (slots.contains(slot)) {
                String action = item.getString("action", "NONE");
                executeAction(player, action);
                return;
            }
        }
    }

    private void executeAction(Player player, String action) {
        switch (action.toUpperCase()) {
            case "OPEN_STORAGE"      -> openStorageInfoMenu(player);
            case "OPEN_STORAGE_INFO" -> openStorageInfoMenu(player);
            case "OPEN_VAULT"        -> openClanVault(player);
            case "OPEN_QUESTS"       -> openQuestMenu(player);
            case "OPEN_TOP"          -> openTopMenu(player);
            case "OPEN_MEMBERS"      -> openMembersMenu(player);
            case "OPEN_MAIN", "BACK" -> openMainMenu(player);
            case "OPEN_CREATE_CHAT"  -> {
                player.closeInventory();
                plugin.getMessageManager().sendRaw(player,
                        "&8[&eNovaClans&8] &r<#ffc800> <#f0e173>/clan create <атыңызды жазыңыз>");
            }
            case "NONE" -> {}
        }
    }

    // ─── Tracking helpers ────────────────────────────────────────────────────

    public boolean isInStorageVault(UUID uuid) {
        String v = openStorageMenu.get(uuid);
        return v != null && v.endsWith(":vault");
    }

    public boolean isInStorageInfo(UUID uuid) {
        String v = openStorageMenu.get(uuid);
        return v != null && v.endsWith(":info");
    }

    public void removeFromStorageTracking(UUID uuid) {
        openStorageMenu.remove(uuid);
    }

    public String getClanNameFromTracking(UUID uuid) {
        String v = openStorageMenu.get(uuid);
        if (v == null) return null;
        return v.replace(":vault", "").replace(":info", "");
    }

    // ─── Build helpers ────────────────────────────────────────────────────────

    private void fillItems(Inventory inv, ConfigurationSection items, Player player, ClanData clan) {
        for (String key : items.getKeys(false)) {
            ConfigurationSection itemSec = items.getConfigurationSection(key);
            if (itemSec == null) continue;
            List<Integer> slots = resolveSlots(itemSec);
            ItemStack item = buildItemFromSection(itemSec, player, clan);
            if (item == null) continue;
            for (int slot : slots) {
                if (slot >= 0 && slot < inv.getSize()) {
                    inv.setItem(slot, item);
                }
            }
        }
    }

    private List<Integer> resolveSlots(ConfigurationSection sec) {
        List<Integer> result = new ArrayList<>();
        if (sec.isList("slots")) {
            result.addAll(sec.getIntegerList("slots"));
        } else {
            int slot = sec.getInt("slot", -1);
            if (slot >= 0) result.add(slot);
        }
        return result;
    }

    private ItemStack buildItemFromSection(ConfigurationSection sec, Player player, ClanData clan) {
        String matName = sec.getString("material", "STONE");
        Material mat = parseMaterial(matName);
        String name = applyPlaceholders(sec.getString("name", " "), player, clan);
        List<String> loreRaw = sec.getStringList("lore");
        List<String> lore = loreRaw.stream()
                .map(l -> applyPlaceholders(l, player, clan))
                .collect(Collectors.toList());
        boolean enchanted = sec.getBoolean("enchanted", false);
        return buildItem(mat, name, lore, enchanted);
    }

    private ItemStack buildItem(Material mat, String name, List<String> lore, boolean enchanted) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(parseMM(ensureItemNameStyle(name)));
        List<Component> loreComponents = lore.stream()
                .map(l -> parseMM(ensureLoreStyle(l)))
                .collect(Collectors.toList());
        meta.lore(loreComponents);
        if (enchanted) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        item.setItemMeta(meta);
        return item;
    }

    private String ensureItemNameStyle(String name) {
        if (name.startsWith("<gradient") || name.startsWith("<bold")) return name;
        return name;
    }

    private String ensureLoreStyle(String line) {
        return line;
    }

    private Material parseMaterial(String name) {
        try { return Material.valueOf(name.toUpperCase()); }
        catch (Exception e) { return Material.STONE; }
    }

    // ─── Placeholders ─────────────────────────────────────────────────────────

    private String applyPlaceholders(String text, Player player, ClanData clan) {
        if (text == null) return "";
        if (clan != null) {
            text = text.replace("%nova_clan_name%", clan.getName());
            text = text.replace("%nova_clan_level%", String.valueOf(clan.getLevel()));
            text = text.replace("%nova_clan_points%", String.valueOf(clan.getPoints()));
            text = text.replace("%nova_clan_balance%", plugin.getClanManager().formatMoney(clan.getBalance()));
            if (player != null) {
                ClanRole role = clan.getMemberRole(player.getUniqueId());
                text = text.replace("%nova_clan_role%", role != null ? role.getDisplayName() : "—");
            }
        }
        return text;
    }

    // ─── Parse ────────────────────────────────────────────────────────────────

    private Component parse(String text) {
        if (text == null) return Component.empty();
        if (text.contains("&")) {
            return LegacyComponentSerializer.legacyAmpersand().deserialize(text);
        }
        return MiniMessage.miniMessage().deserialize(text);
    }

    private Component parseMM(String text) {
        if (text == null) return Component.empty();
        if (text.contains("&") && !text.contains("<")) {
            return LegacyComponentSerializer.legacyAmpersand().deserialize(text);
        }
        return MiniMessage.miniMessage().deserialize(text);
    }

    // ─── Progress bar ─────────────────────────────────────────────────────────

    private String buildProgressBar(long current, long max, int length) {
        if (max <= 0) return "<green>" + "█".repeat(length);
        double ratio = Math.min((double) current / max, 1.0);
        int filled = (int) Math.floor(ratio * length);
        return "<green>" + "█".repeat(filled) + "<dark_gray>" + "█".repeat(length - filled)
                + " <gray>(" + String.format("%.1f", ratio * 100) + "%)";
    }

    // ─── Role helpers ─────────────────────────────────────────────────────────

    private String getRoleColorMM(ClanRole role) {
        return switch (role) {
            case LEADER -> "<red>";
            case DEPUTY -> "<yellow>";
            case MEMBER -> "<gray>";
        };
    }

    private String getRoleIcon(ClanRole role) {
        return switch (role) {
            case LEADER -> "★";
            case DEPUTY -> "◆";
            case MEMBER -> "●";
        };
    }
}
