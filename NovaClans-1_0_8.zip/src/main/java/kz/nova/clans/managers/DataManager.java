package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.*;
import java.util.*;

public class DataManager {

    private final NovaClans plugin;
    private final Map<String, ClanData> clans = new LinkedHashMap<>();
    private final Map<UUID, String> playerClanMap = new HashMap<>();

    private File dataFile;
    private File storageFile;
    private YamlConfiguration dataConfig;
    private YamlConfiguration storageConfig;

    public DataManager(NovaClans plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        dataFile = new File(plugin.getDataFolder(), "novaClans.yml");
        storageFile = new File(plugin.getDataFolder(), "storage_data.yml");

        if (!dataFile.exists()) plugin.saveResource("novaClans.yml", false);
        if (!storageFile.exists()) {
            try { storageFile.createNewFile(); } catch (IOException ignored) {}
        }

        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        storageConfig = YamlConfiguration.loadConfiguration(storageFile);

        clans.clear();
        playerClanMap.clear();

        boolean pvpDefault = plugin.getConfig().getBoolean("pvp-enabled-by-default", true);

        ConfigurationSection clansSection = dataConfig.getConfigurationSection("clans");
        if (clansSection == null) {
            plugin.getLogger().info("Loaded 0 clans from novaClans.yml");
            return;
        }

        for (String clanName : clansSection.getKeys(false)) {
            String path = "clans." + clanName;
            String leaderStr = dataConfig.getString(path + ".leader", "");
            UUID leaderUUID;
            try { leaderUUID = UUID.fromString(leaderStr); }
            catch (Exception e) { continue; }

            ClanData clan = new ClanData(clanName, leaderUUID, pvpDefault);
            clan.setLevel(dataConfig.getInt(path + ".level", 1));
            clan.setPoints(dataConfig.getLong(path + ".points", 0));
            clan.setBalance(dataConfig.getDouble(path + ".balance", 0.0));
            clan.setPvpEnabled(dataConfig.getBoolean(path + ".pvp-enabled", pvpDefault));

            ConfigurationSection membersSection = dataConfig.getConfigurationSection(path + ".members");
            if (membersSection != null) {
                for (String uuidStr : membersSection.getKeys(false)) {
                    try {
                        UUID uuid = UUID.fromString(uuidStr);
                        String memberName = dataConfig.getString(path + ".members." + uuidStr + ".name", "Unknown");
                        String roleStr = dataConfig.getString(path + ".members." + uuidStr + ".role", "MEMBER");
                        ClanRole role = ClanRole.fromString(roleStr);
                        if (role == null) role = ClanRole.MEMBER;
                        long joined = dataConfig.getLong(path + ".members." + uuidStr + ".joined", System.currentTimeMillis());
                        clan.getMembers().put(uuid, new ClanMember(memberName, role, joined));
                        playerClanMap.put(uuid, clanName);
                    } catch (Exception ignored) {}
                }
            }

            // Load storage contents
            String storageKey = "storage." + clanName;
            String base64 = storageConfig.getString(storageKey, null);
            if (base64 != null) {
                try {
                    clan.setStorageContents(itemStackArrayFromBase64(base64));
                } catch (Exception e) {
                    plugin.getLogger().warning("Could not load storage for clan " + clanName);
                }
            }

            clans.put(clanName.toLowerCase(), clan);
        }

        plugin.getLogger().info("Loaded " + clans.size() + " clans from novaClans.yml");
    }

    public void save() {
        // Clear and rewrite
        for (String key : dataConfig.getKeys(false)) dataConfig.set(key, null);

        for (ClanData clan : clans.values()) {
            String path = "clans." + clan.getName();
            dataConfig.set(path + ".leader", clan.getLeader().toString());
            dataConfig.set(path + ".level", clan.getLevel());
            dataConfig.set(path + ".points", clan.getPoints());
            dataConfig.set(path + ".balance", clan.getBalance());
            dataConfig.set(path + ".created", clan.getCreatedAt());
            dataConfig.set(path + ".pvp-enabled", clan.isPvpEnabled());

            for (Map.Entry<UUID, ClanMember> entry : clan.getMembers().entrySet()) {
                String mPath = path + ".members." + entry.getKey().toString();
                dataConfig.set(mPath + ".name", entry.getValue().getName());
                dataConfig.set(mPath + ".role", entry.getValue().getRole().name());
                dataConfig.set(mPath + ".joined", entry.getValue().getJoined());
            }

            // Save storage
            if (clan.getStorageContents() != null) {
                try {
                    storageConfig.set("storage." + clan.getName(), itemStackArrayToBase64(clan.getStorageContents()));
                } catch (Exception e) {
                    plugin.getLogger().warning("Could not save storage_data.yml");
                }
            }
        }

        try {
            dataConfig.save(dataFile);
            storageConfig.save(storageFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- Clan queries ---

    public boolean clanExists(String name) {
        return clans.containsKey(name.toLowerCase());
    }

    public ClanData getClan(String name) {
        return clans.get(name.toLowerCase());
    }

    public ClanData getClanByPlayer(UUID uuid) {
        String name = playerClanMap.get(uuid);
        return name != null ? clans.get(name.toLowerCase()) : null;
    }

    public boolean isInClan(UUID uuid) {
        return playerClanMap.containsKey(uuid);
    }

    public Collection<ClanData> getAllClans() {
        return clans.values();
    }

    public List<ClanData> getTopClans(int limit) {
        return clans.values().stream()
                .sorted((a, b) -> Long.compare(b.getPoints(), a.getPoints()))
                .limit(limit)
                .toList();
    }

    public void createClan(ClanData clan) {
        clans.put(clan.getName().toLowerCase(), clan);
        for (UUID uuid : clan.getMembers().keySet()) {
            playerClanMap.put(uuid, clan.getName());
        }
    }

    public void deleteClan(String name) {
        ClanData clan = clans.remove(name.toLowerCase());
        if (clan != null) {
            for (UUID uuid : clan.getMembers().keySet()) {
                playerClanMap.remove(uuid);
            }
            storageConfig.set("storage." + name, null);
        }
    }

    public void renameClan(ClanData clan, String newName) {
        clans.remove(clan.getName().toLowerCase());
        storageConfig.set("storage." + newName, storageConfig.getString("storage." + clan.getName()));
        storageConfig.set("storage." + clan.getName(), null);
        clan.setName(newName);
        clans.put(newName.toLowerCase(), clan);
        for (UUID uuid : clan.getMembers().keySet()) {
            playerClanMap.put(uuid, newName);
        }
    }

    public void addPlayerToClan(UUID uuid, ClanData clan, ClanRole role, String playerName) {
        clan.getMembers().put(uuid, new ClanMember(playerName, role));
        playerClanMap.put(uuid, clan.getName());
    }

    public void removePlayerFromClan(UUID uuid, ClanData clan) {
        clan.getMembers().remove(uuid);
        playerClanMap.remove(uuid);
    }

    // --- Storage serialization ---

    private static String itemStackArrayToBase64(ItemStack[] items) throws Exception {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try (BukkitObjectOutputStream dataOutput = new BukkitObjectOutputStream(outputStream)) {
            dataOutput.writeInt(items.length);
            for (ItemStack item : items) {
                dataOutput.writeObject(item);
            }
        }
        return Base64.getEncoder().encodeToString(outputStream.toByteArray());
    }

    private static ItemStack[] itemStackArrayFromBase64(String data) throws Exception {
        byte[] bytes = Base64.getDecoder().decode(data);
        try (BukkitObjectInputStream dataInput = new BukkitObjectInputStream(new ByteArrayInputStream(bytes))) {
            int length = dataInput.readInt();
            ItemStack[] items = new ItemStack[length];
            for (int i = 0; i < length; i++) {
                items[i] = (ItemStack) dataInput.readObject();
            }
            return items;
        }
    }
}
