package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.managers.MenuManager;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.UUID;

public class MenuListener implements Listener {

    private final NovaClans plugin;
    private final MenuManager menuManager;

    public MenuListener(NovaClans plugin) {
        this.plugin = plugin;
        this.menuManager = plugin.getMenuManager();
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = PlainTextComponentSerializer.plainText().serialize(event.getView().title());
        UUID uuid = player.getUniqueId();

        if (menuManager.isInStorageVault(uuid)) {
            // Storage vault ішінде еркін шерте алады (өзгерту мүмкін)
            return;
        }

        if (!isNovaMenu(title)) return;
        event.setCancelled(true);
        if (event.getCurrentItem() == null) return;
        int slot = event.getSlot();

        if (menuManager.isInStorageInfo(uuid)) {
            menuManager.handleStorageInfoSlotClick(player, slot);
        } else if (isMembersMenu(title)) {
            menuManager.handleSubMenuSlotClick(player, slot, "members");
        } else if (isTopMenu(title)) {
            menuManager.handleSubMenuSlotClick(player, slot, "top");
        } else if (isQuestMenu(title)) {
            menuManager.handleSubMenuSlotClick(player, slot, "quest");
        } else {
            menuManager.handleMainMenuSlotClick(player, slot);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = PlainTextComponentSerializer.plainText().serialize(event.getView().title());
        UUID uuid = player.getUniqueId();
        if (menuManager.isInStorageVault(uuid)) return;
        if (isNovaMenu(title)) event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();
        if (menuManager.isInStorageVault(uuid)) {
            menuManager.saveVaultAndClose(player, event.getInventory());
        } else {
            menuManager.removeFromStorageTracking(uuid);
        }
    }

    private boolean isNovaMenu(String title) {
        return title.contains("NovaClans") || title.contains("Клан") || title.contains("Мүшелер")
                || title.contains("Топ-10") || title.contains("Квесттер") || title.contains("Қоймасы");
    }

    private boolean isMembersMenu(String title) { return title.contains("Мүшелер"); }
    private boolean isTopMenu(String title)     { return title.contains("Топ-10"); }
    private boolean isQuestMenu(String title)   { return title.contains("Квесттер"); }
}
