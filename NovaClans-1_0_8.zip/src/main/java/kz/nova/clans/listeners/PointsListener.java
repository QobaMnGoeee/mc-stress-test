package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

public class PointsListener implements Listener {

    private final NovaClans plugin;

    public PointsListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null) return;
        ClanData clan = plugin.getDataManager().getClanByPlayer(killer.getUniqueId());
        if (clan == null) return;

        if (event.getEntity() instanceof Player killed) {
            // Don't give points for killing clan mates
            ClanData killedClan = plugin.getDataManager().getClanByPlayer(killed.getUniqueId());
            if (killedClan != null && killedClan.getName().equalsIgnoreCase(clan.getName())) return;
            long points = plugin.getConfig().getLong("points.player-kill", 2);
            plugin.getClanManager().addPoints(clan, points);
        } else if (event.getEntity() instanceof Monster) {
            long points = plugin.getConfig().getLong("points.mob-kill", 1);
            plugin.getClanManager().addPoints(clan, points);
        }
    }
}
