package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class PvpListener implements Listener {

    private final NovaClans plugin;

    public PvpListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player victim)) return;

        ClanData attackerClan = plugin.getDataManager().getClanByPlayer(attacker.getUniqueId());
        ClanData victimClan   = plugin.getDataManager().getClanByPlayer(victim.getUniqueId());

        if (attackerClan == null || victimClan == null) return;
        if (!attackerClan.getName().equalsIgnoreCase(victimClan.getName())) return;

        if (!attackerClan.isPvpEnabled()) {
            event.setCancelled(true);
            plugin.getMessageManager().send(attacker, "clan-pvp-friendly-fire");
        }
    }
}
