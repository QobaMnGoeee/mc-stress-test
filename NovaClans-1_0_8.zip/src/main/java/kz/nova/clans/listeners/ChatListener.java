package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class ChatListener implements Listener {

    private final NovaClans plugin;

    public ChatListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (plugin.getClanManager().isClanChatToggled(player.getUniqueId())) {
            event.setCancelled(true);
            plugin.getClanManager().sendClanChat(player, event.getMessage());
            return;
        }
        // Add clan tag to chat format if in a clan
        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan != null) {
            String tag = plugin.getClanManager().getClanTag(clan);
            event.setFormat(tag + event.getFormat());
        }
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        // Optional: intercept /cc as clan chat shortcut handled by ClanChatCommand
    }
}
