package dev.bigshulker;

import org.bukkit.plugin.java.JavaPlugin;

public class BigShulkerPlugin extends JavaPlugin {

    private static BigShulkerPlugin instance;
    private ShulkerDataManager dataManager;

    @Override
    public void onEnable() {
        instance = this;
        dataManager = new ShulkerDataManager(this);

        getServer().getPluginManager().registerEvents(new ShulkerListener(this), this);

        GiveShulkerCommand cmd = new GiveShulkerCommand(this);
        getCommand("giveshulker").setExecutor(cmd);
        getCommand("giveshulker").setTabCompleter(cmd);

        getLogger().info("BigShulker v2.0 іске қосылды! Жерге қоятын 54 слоттық шалкер дайын.");
    }

    @Override
    public void onDisable() {
        getLogger().info("BigShulker өшірілді.");
    }

    public static BigShulkerPlugin getInstance() { return instance; }
    public ShulkerDataManager getDataManager() { return dataManager; }
}
