package dev.bigshulker;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ShulkerListener implements Listener {

    private final BigShulkerPlugin plugin;
    private final ShulkerDataManager dm;
    // UUID → ашылып тұрған шалкердің орналасқан жері
    private final Map<UUID, Location> openedShulkerLoc = new HashMap<>();

    public ShulkerListener(BigShulkerPlugin plugin) {
        this.plugin = plugin;
        this.dm = plugin.getDataManager();
    }

    // ─── 1. Жерге қою ─────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onBlockPlace(BlockPlaceEvent event) {
        ItemStack item = event.getItemInHand();
        if (!dm.isBigShulker(item)) return;

        Block placed = event.getBlockPlaced();
        Location loc = placed.getLocation();

        // Item-дегі заттарды блок деректеріне сақта
        ItemStack[] contents = dm.getContentsFromItem(item);
        dm.savePlacedShulker(loc, contents);
    }

    // ─── 2. Ашу (оң батырма) ──────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        // Тек блокты оң жақ батырмамен басқанда
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;

        Block block = event.getClickedBlock();
        if (block == null) return;

        Location loc = block.getLocation();
        if (!dm.isPlacedBigShulker(loc)) return;

        event.setCancelled(true);

        Player player = event.getPlayer();

        if (!player.hasPermission("bigshulker.use")) return;

        // Тек бір ойыншы аша алады бір уақытта
        if (openedShulkerLoc.containsValue(loc)) return;

        // GUI аш
        ItemStack[] contents = dm.getPlacedContents(loc);
        Inventory inv = plugin.getServer().createInventory(null, 54,
                net.kyori.adventure.text.Component.text("Премиум шалкер"));
        inv.setContents(contents);

        openedShulkerLoc.put(player.getUniqueId(), loc);
        player.openInventory(inv);
    }

    // ─── 3. Жабу — заттарды сақтау ────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClose(InventoryCloseEvent event) {
        HumanEntity human = event.getPlayer();
        if (!(human instanceof Player player)) return;

        UUID uuid = player.getUniqueId();
        if (!openedShulkerLoc.containsKey(uuid)) return;

        Location loc = openedShulkerLoc.get(uuid);
        Inventory inv = event.getInventory();

        // Заттарды блок деректеріне сақта
        dm.updatePlacedContents(loc, inv.getContents());

        openedShulkerLoc.remove(uuid);
    }

    // ─── 4. Сындыру — drop жасау ──────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        Location loc = block.getLocation();

        if (!dm.isPlacedBigShulker(loc)) return;

        event.setCancelled(true); // Vanilla drop болмасын

        Player player = event.getPlayer();

        // Егер кто-то ашып отырса — жаппай жабу
        for (Map.Entry<UUID, Location> entry : openedShulkerLoc.entrySet()) {
            if (entry.getValue().equals(loc)) {
                Player opener = plugin.getServer().getPlayer(entry.getKey());
                if (opener != null) opener.closeInventory();
            }
        }

        // Блоктағы заттарды алу
        ItemStack[] contents = dm.removePlacedShulker(loc);

        // Блокты өш
        block.setType(Material.AIR);

        // Item жасап жер бетіне тастау (заттарымен бірге)
        ItemStack shulkerItem = dm.createBigShulkerItem(contents);
        block.getWorld().dropItemNaturally(loc, shulkerItem);
    }

    // ─── 5. Шалкер ішіне шалкер салуға тыйым ─────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity human = event.getWhoClicked();
        if (!(human instanceof Player player)) return;
        if (!openedShulkerLoc.containsKey(player.getUniqueId())) return;

        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();

        if (cursor != null && cursor.getType() != Material.AIR && dm.isBigShulker(cursor)) {
            event.setCancelled(true);
            return;
        }

        if (current != null && current.getType() != Material.AIR && dm.isBigShulker(current)
                && event.getRawSlot() < event.getInventory().getSize()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryDrag(InventoryDragEvent event) {
        HumanEntity human = event.getWhoClicked();
        if (!(human instanceof Player player)) return;
        if (!openedShulkerLoc.containsKey(player.getUniqueId())) return;

        ItemStack oldCursor = event.getOldCursor();
        if (oldCursor != null && oldCursor.getType() != Material.AIR && dm.isBigShulker(oldCursor)) {
            event.setCancelled(true);
        }
    }
}
