package dev.bigshulker;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class ShulkerDataManager {

    private final BigShulkerPlugin plugin;

    // NBT кілттер — item-де сақтау үшін
    public final NamespacedKey KEY_IS_BIG_SHULKER;
    public final NamespacedKey KEY_SHULKER_CONTENTS;

    // Блок орналасқан жер → ішіндегі заттар (серверде тұрған кезде)
    private final Map<String, ItemStack[]> placedShulkers = new HashMap<>();

    public ShulkerDataManager(BigShulkerPlugin plugin) {
        this.plugin = plugin;
        this.KEY_IS_BIG_SHULKER = new NamespacedKey(plugin, "is_big_shulker");
        this.KEY_SHULKER_CONTENTS = new NamespacedKey(plugin, "shulker_contents");
    }

    // ─── Item жасау ───────────────────────────────────────────────

    public ItemStack createBigShulkerItem() {
        return createBigShulkerItem(null);
    }

    public ItemStack createBigShulkerItem(ItemStack[] contents) {
        ItemStack shulker = new ItemStack(Material.PURPLE_SHULKER_BOX);
        ItemMeta meta = shulker.getItemMeta();

        meta.displayName(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<bold><color:#AA00AA>✦ 54 Слоттық Шалкер ✦</color></bold>"));

        int count = 0;
        if (contents != null) {
            for (ItemStack item : contents) {
                if (item != null && item.getType() != Material.AIR) count++;
            }
        }

        java.util.List<net.kyori.adventure.text.Component> lore = new java.util.ArrayList<>();
        lore.add(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<gray>━━━━━━━━━━━━━━━━━━━━━━"));
        lore.add(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<light_purple>54 зат сыйдыратын арнайы шалкер"));
        lore.add(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<gray>Жерге қойып аша аласыз"));
        if (contents != null) {
            lore.add(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<yellow>Заттар: <white>" + count + " <gray>/ 54"));
        }
        lore.add(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<gray>━━━━━━━━━━━━━━━━━━━━━━"));
        lore.add(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<gold>✦ Донат шалкер <yellow>[PREMIUM]"));
        meta.lore(lore);

        // NBT: бұл шалкердің біздікі екенін белгіле
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(KEY_IS_BIG_SHULKER, PersistentDataType.BOOLEAN, true);

        // Заттарды item-ге жаз
        if (contents != null) {
            String serialized = serialize(contents);
            if (serialized != null) {
                pdc.set(KEY_SHULKER_CONTENTS, PersistentDataType.STRING, serialized);
            }
        }

        shulker.setItemMeta(meta);
        return shulker;
    }

    // ─── Item тексеру ─────────────────────────────────────────────

    public boolean isBigShulker(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        if (!item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer()
                .has(KEY_IS_BIG_SHULKER, PersistentDataType.BOOLEAN);
    }

    // ─── Item-дегі заттарды алу ───────────────────────────────────

    public ItemStack[] getContentsFromItem(ItemStack item) {
        if (!item.hasItemMeta()) return new ItemStack[54];
        String data = item.getItemMeta().getPersistentDataContainer()
                .get(KEY_SHULKER_CONTENTS, PersistentDataType.STRING);
        if (data == null) return new ItemStack[54];
        ItemStack[] result = deserialize(data);
        return result != null ? result : new ItemStack[54];
    }

    // ─── Блок деректері (жерде тұрған кезде) ─────────────────────

    public void savePlacedShulker(Location loc, ItemStack[] contents) {
        placedShulkers.put(locKey(loc), contents);
    }

    public ItemStack[] getPlacedContents(Location loc) {
        return placedShulkers.getOrDefault(locKey(loc), new ItemStack[54]);
    }

    public boolean isPlacedBigShulker(Location loc) {
        return placedShulkers.containsKey(locKey(loc));
    }

    public ItemStack[] removePlacedShulker(Location loc) {
        return placedShulkers.remove(locKey(loc));
    }

    public void updatePlacedContents(Location loc, ItemStack[] contents) {
        placedShulkers.put(locKey(loc), contents);
    }

    private String locKey(Location loc) {
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }

    // ─── Serialization ────────────────────────────────────────────

    public String serialize(ItemStack[] contents) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            BukkitObjectOutputStream dataOut = new BukkitObjectOutputStream(out);
            dataOut.writeInt(contents.length);
            for (ItemStack item : contents) dataOut.writeObject(item);
            dataOut.close();
            return Base64.getEncoder().encodeToString(out.toByteArray());
        } catch (Exception e) {
            plugin.getLogger().warning("Serialize қатесі: " + e.getMessage());
            return null;
        }
    }

    public ItemStack[] deserialize(String data) {
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(Base64.getDecoder().decode(data));
            BukkitObjectInputStream dataIn = new BukkitObjectInputStream(in);
            int length = dataIn.readInt();
            ItemStack[] items = new ItemStack[length];
            for (int i = 0; i < length; i++) items[i] = (ItemStack) dataIn.readObject();
            dataIn.close();
            return items;
        } catch (Exception e) {
            plugin.getLogger().warning("Deserialize қатесі: " + e.getMessage());
            return null;
        }
    }
}
