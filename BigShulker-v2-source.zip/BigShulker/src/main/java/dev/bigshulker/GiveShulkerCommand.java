package dev.bigshulker;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class GiveShulkerCommand implements CommandExecutor, TabCompleter {

    private final BigShulkerPlugin plugin;

    public GiveShulkerCommand(BigShulkerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("bigshulker.give")) {
            sender.sendMessage("§cСізде бұл команданы қолдануға рұқсат жоқ!");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("§cҚолдану: §f/giveshulker <ойыншы>");
            return true;
        }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage("§cОйыншы табылмады: §f" + args[0]);
            return true;
        }
        ItemStack shulker = plugin.getDataManager().createBigShulkerItem();
        target.getInventory().addItem(shulker);
        sender.sendMessage("§a" + target.getName() + " ойыншысына 54 слоттық шалкер берілді!");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[0].toLowerCase()))
                    list.add(p.getName());
            }
        }
        return list;
    }
}
