package dev.nova.novanoelytra;

import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockDispenseArmorEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.projectiles.ProjectileSource;

public final class ElytraListener implements Listener {

    /** Chestplate index inside PlayerInventory. */
    private static final int CHEST_SLOT = 38;
    /** Chestplate raw slot in the player's own (crafting) inventory view. */
    private static final int CHEST_RAW_SLOT = 6;

    private final CombatTracker tracker;

    public ElytraListener(CombatTracker tracker) {
        this.tracker = tracker;
    }

    // ---- Combat start -------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) {
            return;
        }
        Player attacker = resolveAttacker(event.getDamager());
        if (attacker == null || attacker.equals(victim)) {
            return;
        }
        tracker.tag(attacker);
        tracker.tag(victim);
    }

    private static Player resolveAttacker(org.bukkit.entity.Entity damager) {
        if (damager instanceof Player player) {
            return player;
        }
        if (damager instanceof Projectile projectile) {
            ProjectileSource shooter = projectile.getShooter();
            if (shooter instanceof Player player) {
                return player;
            }
        }
        return null;
    }

    // ---- Combat end ---------------------------------------------------------------------

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        tracker.clear(event.getEntity());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        tracker.clear(event.getPlayer());
    }

    // ---- Blocking every way to use an elytra --------------------------------------------

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGlide(EntityToggleGlideEvent event) {
        if (event.isGliding()
                && event.getEntity() instanceof Player player
                && tracker.isTagged(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !tracker.isTagged(player)) {
            return;
        }

        boolean playerInv = event.getClickedInventory() instanceof PlayerInventory;
        boolean chestSlot = playerInv && event.getSlot() == CHEST_SLOT;

        if (chestSlot) {
            switch (event.getAction()) {
                case PLACE_ALL, PLACE_ONE, PLACE_SOME, SWAP_WITH_CURSOR -> {
                    if (CombatTracker.isElytra(event.getCursor())) {
                        event.setCancelled(true);
                    }
                }
                case HOTBAR_SWAP -> {
                    int button = event.getHotbarButton();
                    ItemStack other = button >= 0
                            ? player.getInventory().getItem(button)
                            : player.getInventory().getItemInOffHand();
                    if (CombatTracker.isElytra(other)) {
                        event.setCancelled(true);
                    }
                }
                default -> { }
            }
            return;
        }

        // Shift-click auto-equips armor when the top inventory is the crafting/player view.
        if (event.isShiftClick()
                && playerInv
                && event.getView().getTopInventory().getType() == InventoryType.CRAFTING
                && CombatTracker.isElytra(event.getCurrentItem())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !tracker.isTagged(player)) {
            return;
        }
        if (CombatTracker.isElytra(event.getOldCursor())
                && event.getView().getTopInventory().getType() == InventoryType.CRAFTING
                && event.getRawSlots().contains(CHEST_RAW_SLOT)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (CombatTracker.isElytra(event.getItem()) && tracker.isTagged(event.getPlayer())) {
            // Only deny the item use (right-click equip); block interactions keep working.
            event.setUseItemInHand(Event.Result.DENY);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDispense(BlockDispenseArmorEvent event) {
        if (event.getTargetEntity() instanceof Player player
                && CombatTracker.isElytra(event.getItem())
                && tracker.isTagged(player)) {
            event.setCancelled(true);
        }
    }
}
