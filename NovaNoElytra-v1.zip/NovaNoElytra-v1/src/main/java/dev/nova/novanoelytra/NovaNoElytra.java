package dev.nova.novanoelytra;

import org.bukkit.plugin.java.JavaPlugin;

public final class NovaNoElytra extends JavaPlugin {

    private CombatTracker tracker;

    @Override
    public void onEnable() {
        tracker = new CombatTracker();
        getServer().getPluginManager().registerEvents(new ElytraListener(tracker), this);
        // Silent background enforcement + expiry cleanup (every tick, only touches tagged players).
        getServer().getScheduler().runTaskTimer(this, tracker::tick, 1L, 1L);
    }

    @Override
    public void onDisable() {
        if (tracker != null) {
            tracker.clearAll();
        }
    }
}
