package dev.nova.novanoelytra;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Hidden internal PvP timer. Everything runs on the main thread.
 * Nothing here ever sends a message, sound or effect to a player.
 */
public final class CombatTracker {

    private static final long DURATION_MILLIS = 30_000L; // 30 seconds
    private static final String BYPASS_PERMISSION = "novanoelytra.bypass";

    private final Map<UUID, Long> expiry = new HashMap<>();

    /** Starts / refreshes the hidden timer and immediately strips the elytra. */
    public void tag(Player player) {
        if (isBypassed(player)) {
            return;
        }
        expiry.put(player.getUniqueId(), System.currentTimeMillis() + DURATION_MILLIS);
        enforce(player);
    }

    /** Read-only check (never mutates the map, so it is safe inside event handlers). */
    public boolean isTagged(Player player) {
        Long until = expiry.get(player.getUniqueId());
        return until != null && until > System.currentTimeMillis() && !isBypassed(player);
    }

    public void clear(Player player) {
        expiry.remove(player.getUniqueId());
    }

    public void clearAll() {
        expiry.clear();
    }

    /** Runs every tick: drops expired entries and re-enforces the rule for active ones. */
    public void tick() {
        if (expiry.isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Long>> it = expiry.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Long> entry = it.next();
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player == null || !player.isOnline() || entry.getValue() <= now || isBypassed(player)) {
                it.remove();
                continue;
            }
            enforce(player);
        }
    }

    /** Removes a worn elytra into the inventory (drops it at the feet if full) and stops gliding. */
    public void enforce(Player player) {
        PlayerInventory inv = player.getInventory();
        ItemStack chest = inv.getChestplate();
        if (isElytra(chest)) {
            inv.setChestplate(null);
            Map<Integer, ItemStack> leftover = inv.addItem(chest);
            for (ItemStack item : leftover.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), item);
            }
        }
        if (player.isGliding()) {
            player.setGliding(false);
        }
    }

    public static boolean isElytra(ItemStack item) {
        return item != null && item.getType() == Material.ELYTRA;
    }

    private static boolean isBypassed(Player player) {
        return player.hasPermission(BYPASS_PERMISSION);
    }
}
