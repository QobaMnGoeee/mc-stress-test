package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.*;

public class MenuManager {

    private final NovaClans plugin;
    private YamlConfiguration clanMenuConfig;
    private YamlConfiguration storageMenuConfig;

    // Tracks which players are in vault (storage) view vs info view
    private final Map<UUID, String> openStorageMenu = new HashMap<>();
    // player UUID -> clan inventory
    private final Map<String, ItemStack[]> clanInventories = new HashMap<>();

    public MenuManager(NovaClans plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File menuDir = new File(plugin.getDataFolder(), "menus");
        if (!menuDir.exists()) menuDir.mkdirs();

        File clanMenuFile = new File(menuDir, "clan_menu.yml");
        File storageMenuFile = new File(menuDir, "storage_menu.yml");

        if (!clanMenuFile.exists()) plugin.saveResource("menus/clan_menu.yml", false);
        if (!storageMenuFile.exists()) plugin.saveResource("menus/storage_menu.yml", false);

        clanMenuConfig = YamlConfiguration.loadConfiguration(clanMenuFile);
        storageMenuConfig = YamlConfiguration.loadConfiguration(storageMenuFile);
    }

    // ─── /clan main menu ─────────────────────────────────────────────────────

    public void openMainMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        boolean inClan = dm.isInClan(player.getUniqueId());

        if (!inClan) {
            openNoClanMenu(player);
        } else {
            openClanMenu(player, dm.getClanByPlayer(player.getUniqueId()));
        }
    }

    private void openNoClanMenu(Player player) {
        ConfigurationSection cfg = clanMenuConfig.getConfigurationSection("no-clan-menu");
        if (cfg == null) return;

        int rows = cfg.getInt("rows", 3);
        String title = color(cfg.getString("title", "Клан Мәзірі"));
        Inventory inv = Bukkit.createInventory(null, rows * 9, component(title));

        if (cfg.getBoolean("fill-empty", true)) {
            Material fillMat = parseMaterial(cfg.getString("fill-material", "BLACK_STAINED_GLASS_PANE"));
            ItemStack filler = buildItem(fillMat, cfg.getString("fill-name", " "), null, false);
            for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
        }

        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items != null) {
            for (String key : items.getKeys(false)) {
                ConfigurationSection ic = items.getConfigurationSection(key);
                if (ic == null) continue;
                int slot = ic.getInt("slot", 0);
                ItemStack item = buildItemFromSection(ic, player, null);
                if (slot < inv.getSize()) inv.setItem(slot, item);
            }
        }
        player.openInventory(inv);
    }

    private void openClanMenu(Player player, ClanData clan) {
        ConfigurationSection cfg = clanMenuConfig.getConfigurationSection("clan-menu");
        if (cfg == null) return;

        int rows = cfg.getInt("rows", 4);
        String title = applyPlaceholders(color(cfg.getString("title", "Клан")), player, clan);
        Inventory inv = Bukkit.createInventory(null, rows * 9, component(title));

        if (cfg.getBoolean("fill-empty", true)) {
            Material fillMat = parseMaterial(cfg.getString("fill-material", "BLACK_STAINED_GLASS_PANE"));
            ItemStack filler = buildItem(fillMat, cfg.getString("fill-name", " "), null, false);
            for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
        }

        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items != null) {
            for (String key : items.getKeys(false)) {
                ConfigurationSection ic = items.getConfigurationSection(key);
                if (ic == null) continue;
                int slot = ic.getInt("slot", 0);
                ItemStack item = buildItemFromSection(ic, player, clan);
                if (slot < inv.getSize()) inv.setItem(slot, item);
            }
        }
        player.openInventory(inv);
    }

    // ─── /clan storage info menu ─────────────────────────────────────────────

    public void openStorageInfoMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        if (clan == null) { plugin.getMessageManager().send(player, "not-in-clan"); return; }

        ConfigurationSection cfg = storageMenuConfig.getConfigurationSection("storage-menu");
        if (cfg == null) return;

        String title = color(cfg.getString("title", "&8Клан Қоймасы"));
        // 5 rows: 4 rows storage area + 1 row info
        int size = 45;
        Inventory inv = Bukkit.createInventory(null, size, component(title));

        // Fill all with glass
        ItemStack glass = buildItem(Material.BLACK_STAINED_GLASS_PANE, " ", null, false);
        for (int i = 36; i < 45; i++) inv.setItem(i, glass);

        // 4 info slots in the bottom row: slots 37, 38, 40, 41 (centered)
        ConfigurationSection infoSlots = cfg.getConfigurationSection("info-slots");
        if (infoSlots != null) {
            int[] positions = {37, 38, 40, 41};
            String[] keys = {"info", "quests", "members", "open-storage"};
            for (int i = 0; i < keys.length; i++) {
                ConfigurationSection sc = infoSlots.getConfigurationSection(keys[i]);
                if (sc == null) continue;
                ItemStack item = buildInfoSlotItem(sc, player, clan, cfg);
                inv.setItem(positions[i], item);
            }
        }

        // Mark that this player is in storage info view
        openStorageMenu.put(player.getUniqueId(), clan.getName() + ":info");
        player.openInventory(inv);
    }

    // ─── Clan vault (actual storage) ─────────────────────────────────────────

    public void openClanVault(Player player) {
        DataManager dm = plugin.getDataManager();
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        if (clan == null) { plugin.getMessageManager().send(player, "not-in-clan"); return; }

        int slots = plugin.getConfig().getInt("storage.level-" + clan.getLevel(), 27);
        String title = color("&8[&bКлан Қоймасы&8] &e" + clan.getName() + " &7| &bLv." + clan.getLevel());
        Inventory inv = Bukkit.createInventory(null, slots, component(title));

        // Load saved contents
        ItemStack[] contents = clan.getStorageContents();
        if (contents != null) {
            for (int i = 0; i < Math.min(contents.length, slots); i++) {
                if (contents[i] != null) inv.setItem(i, contents[i]);
            }
        }

        openStorageMenu.put(player.getUniqueId(), clan.getName() + ":vault");
        player.openInventory(inv);
    }

    public void saveVaultAndClose(Player player, Inventory inv) {
        String entry = openStorageMenu.remove(player.getUniqueId());
        if (entry == null || !entry.endsWith(":vault")) return;
        String clanName = entry.replace(":vault", "");
        ClanData clan = plugin.getDataManager().getClan(clanName);
        if (clan == null) return;
        clan.setStorageContents(inv.getContents());
        plugin.getDataManager().save();
    }

    public boolean isInStorageVault(UUID uuid) {
        String e = openStorageMenu.get(uuid);
        return e != null && e.endsWith(":vault");
    }

    public boolean isInStorageInfo(UUID uuid) {
        String e = openStorageMenu.get(uuid);
        return e != null && e.endsWith(":info");
    }

    public void removeFromStorageTracking(UUID uuid) {
        openStorageMenu.remove(uuid);
    }

    // ─── Members menu ────────────────────────────────────────────────────────

    public void openMembersMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        if (clan == null) return;

        int size = 54;
        String title = color("&8[&bМүшелер&8] &e" + clan.getName());
        Inventory inv = Bukkit.createInventory(null, size, component(title));

        ItemStack glass = buildItem(Material.BLACK_STAINED_GLASS_PANE, " ", null, false);
        for (int i = 45; i < 54; i++) inv.setItem(i, glass);

        // Back button
        inv.setItem(49, buildItem(Material.ARROW, color("&cКері"), List.of(color("&7Артқа қайту")), false));

        int slot = 0;
        for (Map.Entry<UUID, ClanMember> entry : clan.getMembers().entrySet()) {
            if (slot >= 45) break;
            ClanMember member = entry.getValue();
            String roleColor = getRoleColor(member.getRole());
            String roleIcon = getRoleIcon(member.getRole());

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            ItemMeta meta = head.getItemMeta();
            if (meta instanceof org.bukkit.inventory.meta.SkullMeta skullMeta) {
                skullMeta.setOwningPlayer(Bukkit.getOfflinePlayer(entry.getKey()));
                meta = skullMeta;
            }
            meta.displayName(component(roleColor + roleIcon + " " + member.getName()));
            meta.lore(List.of(
                    component(color("&7━━━━━━━━━━━━━━━━━━━━")),
                    component(color("&7Рөл: " + roleColor + member.getRole().getDisplayName())),
                    component(color("&7Онлайн: " + (Bukkit.getPlayer(entry.getKey()) != null ? "&aИә" : "&cЖоқ"))),
                    component(color("&7━━━━━━━━━━━━━━━━━━━━"))
            ));
            head.setItemMeta(meta);
            inv.setItem(slot++, head);
        }

        player.openInventory(inv);
    }

    // ─── Top clans menu ──────────────────────────────────────────────────────

    public void openTopMenu(Player player) {
        List<ClanData> top = plugin.getDataManager().getTopClans(10);
        int size = 54;
        String title = color("&8[&bКлан Топ&8] &6Топ-10");
        Inventory inv = Bukkit.createInventory(null, size, component(title));

        ItemStack glass = buildItem(Material.BLACK_STAINED_GLASS_PANE, " ", null, false);
        for (int i = 0; i < 54; i++) inv.setItem(i, glass);

        int[] slots = {10, 11, 12, 13, 14, 15, 16, 28, 31, 34};
        Material[] medals = {
                Material.GOLD_INGOT, Material.IRON_INGOT, Material.COPPER_INGOT,
                Material.EMERALD, Material.DIAMOND, Material.AMETHYST_SHARD,
                Material.LAPIS_LAZULI, Material.REDSTONE, Material.QUARTZ, Material.COAL
        };

        for (int i = 0; i < Math.min(top.size(), 10); i++) {
            ClanData clan = top.get(i);
            String rankColor = i == 0 ? "&6" : i == 1 ? "&7" : i == 2 ? "&c" : "&f";
            ItemStack item = buildItem(medals[i],
                    color(rankColor + "#" + (i + 1) + " " + clan.getName()),
                    List.of(
                            color("&7━━━━━━━━━━━━━━━━━━━━"),
                            color("&7Деңгей: &b⭐ " + clan.getLevel()),
                            color("&7Ұпай: &a" + clan.getPoints()),
                            color("&7Баланс: &6" + plugin.getClanManager().formatMoney(clan.getBalance()) + "₸"),
                            color("&7Мүшелер: &e" + clan.getMemberCount()),
                            color("&7━━━━━━━━━━━━━━━━━━━━")
                    ), i < 3);
            if (i < slots.length) inv.setItem(slots[i], item);
        }
        player.openInventory(inv);
    }

    // ─── Quest info menu ─────────────────────────────────────────────────────

    public void openQuestMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        if (clan == null) { plugin.getMessageManager().send(player, "not-in-clan"); return; }

        int size = 36;
        String title = color("&8[&bКвесттер&8] &e" + clan.getName());
        Inventory inv = Bukkit.createInventory(null, size, component(title));

        ItemStack glass = buildItem(Material.BLACK_STAINED_GLASS_PANE, " ", null, false);
        for (int i = 0; i < 36; i++) inv.setItem(i, glass);

        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        long currentPoints = clan.getPoints();
        int currentLevel = clan.getLevel();

        // Progress info
        long nextRequired = currentLevel < maxLevel
                ? plugin.getConfig().getLong("levels." + (currentLevel + 1), 0)
                : plugin.getConfig().getLong("levels." + maxLevel, 0);
        long prevRequired = plugin.getConfig().getLong("levels." + currentLevel, 0);
        String progressBar = buildProgressBar(currentPoints - prevRequired,
                nextRequired - prevRequired, 20);

        inv.setItem(13, buildItem(Material.EXPERIENCE_BOTTLE,
                color("&b✦ Клан Прогресі"),
                List.of(
                        color("&7━━━━━━━━━━━━━━━━━━━━"),
                        color("&7Деңгей: &b" + currentLevel + " &7/ &b" + maxLevel),
                        color("&7Ұпай: &a" + currentPoints + " &7/ &e" + nextRequired),
                        color("&7" + progressBar),
                        color("&7━━━━━━━━━━━━━━━━━━━━"),
                        color("&eҰпай жинау жолдары:"),
                        color("&7⚔ Ойыншы өлтіру: &a+2 ұпай"),
                        color("&7☠ Моб өлтіру: &a+1 ұпай"),
                        color("&7⛏ Блок сындыру: &a+1 ұпай"),
                        color("&7━━━━━━━━━━━━━━━━━━━━")
                ), false));

        // Level roadmap
        int[] levelSlots = {19, 21, 23, 25, 27};
        for (int lv = 1; lv <= maxLevel; lv++) {
            long req = plugin.getConfig().getLong("levels." + lv, 0);
            boolean achieved = currentLevel >= lv;
            Material mat = achieved ? Material.LIME_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE;
            String status = achieved ? "&a✔ Жетілді" : "&c✘ Жетілмеді";
            if (lv - 1 < levelSlots.length) {
                inv.setItem(levelSlots[lv - 1], buildItem(mat,
                        color("&b⭐ Деңгей " + lv),
                        List.of(color("&7Керекті ұпай: &e" + req), color(status)), false));
            }
        }

        player.openInventory(inv);
    }

    // ─── Item builders ───────────────────────────────────────────────────────

    private ItemStack buildItemFromSection(ConfigurationSection sec, Player player, ClanData clan) {
        Material mat = parseMaterial(sec.getString("material", "STONE"));
        String name = applyPlaceholders(color(sec.getString("name", "")), player, clan);
        List<String> lore = sec.getStringList("lore").stream()
                .map(l -> applyPlaceholders(color(l), player, clan))
                .toList();
        boolean enchanted = sec.getBoolean("enchanted", false);
        return buildItem(mat, name, lore, enchanted);
    }

    private ItemStack buildInfoSlotItem(ConfigurationSection sec, Player player, ClanData clan,
                                        ConfigurationSection rootCfg) {
        Material mat = parseMaterial(sec.getString("material", "STONE"));
        String name = applyPlaceholders(color(sec.getString("name", "")), player, clan);

        // Special handling for quests slot - build dynamic progress bar
        if (sec.getName().equals("quests")) {
            return buildQuestItem(player, clan);
        }
        // Special handling for members slot
        if (sec.getName().equals("members")) {
            return buildMembersItem(player, clan, rootCfg);
        }

        List<String> lore = sec.getStringList("lore").stream()
                .map(l -> applyPlaceholders(color(l), player, clan))
                .toList();
        return buildItem(mat, name, lore, false);
    }

    private ItemStack buildQuestItem(Player player, ClanData clan) {
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        int currentLevel = clan.getLevel();
        long currentPoints = clan.getPoints();
        long prevRequired = plugin.getConfig().getLong("levels." + currentLevel, 0);
        long nextRequired;
        if (currentLevel >= maxLevel) {
            // Already at max level - show full bar
            nextRequired = prevRequired;
        } else {
            nextRequired = plugin.getConfig().getLong("levels." + (currentLevel + 1), 0);
        }
        String bar = currentLevel >= maxLevel
                ? "&a" + "█".repeat(15) + " &7(MAX)"
                : buildProgressBar(currentPoints - prevRequired, nextRequired - prevRequired, 15);

        return buildItem(Material.EXPERIENCE_BOTTLE,
                color("&b✦ Квест Прогресі"),
                List.of(
                        color("&7━━━━━━━━━━━━━━━━"),
                        color("&7Ұпай: &a" + currentPoints + "&7/&e" + (currentLevel >= maxLevel ? "MAX" : nextRequired)),
                        color("&7" + bar),
                        color("&7Деңгей: &b" + currentLevel + "&7/&b" + maxLevel),
                        color("&7━━━━━━━━━━━━━━━━")
                ), false);
    }

    private ItemStack buildMembersItem(Player player, ClanData clan, ConfigurationSection rootCfg) {
        List<String> lore = new ArrayList<>();
        lore.add(color("&7━━━━━━━━━━━━━━━━"));
        lore.add(color("&7Мүше саны: &e" + clan.getMemberCount()));
        lore.add(color("&7━━━━━━━━━━━━━━━━"));
        int shown = 0;
        for (ClanMember m : clan.getMembers().values()) {
            if (shown++ >= 10) { lore.add(color("&7... және тағы басқалар")); break; }
            String rc = getRoleColor(m.getRole());
            String ri = getRoleIcon(m.getRole());
            boolean online = Bukkit.getPlayer(m.getUuid()) != null;
            lore.add(color(rc + ri + " " + m.getName() + " &7(" + (online ? "&aОнлайн" : "&cОффлайн") + "&7)"));
        }
        lore.add(color("&7━━━━━━━━━━━━━━━━"));
        return buildItem(Material.PLAYER_HEAD, color("&d✦ Мүшелер"), lore, false);
    }

    private ItemStack buildItem(Material mat, String name, List<String> lore, boolean enchanted) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        if (name != null && !name.isEmpty()) meta.displayName(component(name));
        if (lore != null && !lore.isEmpty()) {
            meta.lore(lore.stream().map(this::component).toList());
        }
        if (enchanted) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
        }
        item.setItemMeta(meta);
        return item;
    }

    // ─── Progress bar ────────────────────────────────────────────────────────

    private String buildProgressBar(long current, long max, int length) {
        if (max <= 0) return "&a" + "█".repeat(length);
        double ratio = Math.min(1.0, (double) current / max);
        int filled = (int) (ratio * length);
        return "&a" + "█".repeat(filled) + "&8" + "█".repeat(length - filled)
                + " &7(" + String.format("%.1f", ratio * 100) + "%)";
    }

    // ─── Placeholders ────────────────────────────────────────────────────────

    private String applyPlaceholders(String text, Player player, ClanData clan) {
        if (text == null) return "";
        if (clan != null) {
            ClanRole role = clan.getMemberRole(player.getUniqueId());
            text = text
                    .replace("%nova_clan_name%", clan.getName())
                    .replace("%nova_clan_level%", String.valueOf(clan.getLevel()))
                    .replace("%nova_clan_points%", String.valueOf(clan.getPoints()))
                    .replace("%nova_clan_balance%", plugin.getClanManager().formatMoney(clan.getBalance()))
                    .replace("%nova_clan_role%", role != null ? role.getDisplayName() : "Жоқ");
        } else {
            text = text
                    .replace("%nova_clan_name%", "Жоқ")
                    .replace("%nova_clan_level%", "0")
                    .replace("%nova_clan_points%", "0")
                    .replace("%nova_clan_balance%", "0")
                    .replace("%nova_clan_role%", "Жоқ");
        }
        return text;
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private String getRoleColor(ClanRole role) {
        return switch (role) {
            case LEADER -> "&c";
            case DEPUTY -> "&e";
            case MEMBER -> "&7";
        };
    }

    private String getRoleIcon(ClanRole role) {
        return switch (role) {
            case LEADER -> "★";
            case DEPUTY -> "✦";
            case MEMBER -> "•";
        };
    }

    private Material parseMaterial(String name) {
        if (name == null) return Material.STONE;
        try { return Material.valueOf(name.toUpperCase()); }
        catch (IllegalArgumentException e) { return Material.STONE; }
    }

    private static String color(String s) { return MessageManager.color(s); }

    private net.kyori.adventure.text.Component component(String s) {
        return MessageManager.component(s);
    }
}
