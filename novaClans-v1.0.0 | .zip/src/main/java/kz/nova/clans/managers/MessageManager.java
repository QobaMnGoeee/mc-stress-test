package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.List;

public class MessageManager {

    private final NovaClans plugin;
    private YamlConfiguration messages;
    private String prefix;

    private static final MiniMessage MM = MiniMessage.miniMessage();

    public MessageManager(NovaClans plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) plugin.saveResource("messages.yml", false);
        messages = YamlConfiguration.loadConfiguration(file);
        // prefix is always the fixed clan prefix
        prefix = "&8[&eᴄʟᴀɴ&8] &r";
    }

    public String getPrefix() { return prefix; }

    public String getRaw(String key) {
        String val = messages.getString(key);
        if (val == null) return "&c[NovaClans] Missing message: " + key;
        return val;
    }

    public String get(String key, Object... replacements) {
        String msg = getRaw(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace(String.valueOf(replacements[i]), String.valueOf(replacements[i + 1]));
        }
        return prefix + msg;
    }

    public List<String> getList(String key) {
        return messages.getStringList(key);
    }

    public void send(CommandSender sender, String key, Object... replacements) {
        String msg = get(key, replacements);
        sender.sendMessage(parse(msg));
    }

    public void sendRaw(CommandSender sender, String msg) {
        sender.sendMessage(parse(msg));
    }

    public void sendList(CommandSender sender, String key) {
        List<String> lines = getList(key);
        if (lines.isEmpty()) {
            // fallback - try as single string
            String single = getRaw(key);
            sender.sendMessage(parse(single));
            return;
        }
        for (String line : lines) {
            sender.sendMessage(parse(line));
        }
    }

    public void broadcast(String key, Object... replacements) {
        List<String> lines = messages.getStringList(key);
        for (String line : lines) {
            for (int i = 0; i + 1 < replacements.length; i += 2) {
                line = line.replace(String.valueOf(replacements[i]), String.valueOf(replacements[i + 1]));
            }
            String finalLine = line;
            Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(parse(finalLine)));
            Bukkit.getConsoleSender().sendMessage(parse(finalLine));
        }
    }

    /**
     * Parse a string that may contain:
     *  - Legacy & codes (&a, &e, etc.)
     *  - MiniMessage tags (<gradient:#ffc800:#f2990a>text</gradient>, <#hex> etc.)
     */
    public static Component parse(String text) {
        if (text == null) return Component.empty();
        // Convert legacy & codes to § so MiniMessage doesn't interfere with them
        // But we want MiniMessage gradients to work too — use legacy_serializer approach:
        // First translate & -> § for legacy color support, then parse MiniMessage.
        // We wrap legacy-colored text with <legacy> by converting & codes to MiniMessage hex/named colors.
        // Best approach: treat & codes as-is with section sign, then use legacy serializer final step.
        // 
        // Strategy: convert &x codes -> MiniMessage named colors, keep <tag> intact, then MM.deserialize
        String converted = legacyToMiniMessage(text);
        try {
            return MM.deserialize(converted);
        } catch (Exception e) {
            // fallback to legacy
            return LegacyComponentSerializer.legacySection().deserialize(text.replace("&", "§"));
        }
    }

    /**
     * Convert legacy & color codes to MiniMessage equivalents while preserving
     * existing MiniMessage tags (<gradient:...>, <#hex>, etc.)
     */
    private static String legacyToMiniMessage(String text) {
        if (text == null) return "";
        StringBuilder sb = new StringBuilder();
        int len = text.length();
        int i = 0;
        while (i < len) {
            char c = text.charAt(i);
            // Check for MiniMessage tag - preserve as-is
            if (c == '<') {
                int end = text.indexOf('>', i);
                if (end != -1) {
                    sb.append(text, i, end + 1);
                    i = end + 1;
                    continue;
                }
            }
            // Check for & color code
            if ((c == '&' || c == '§') && i + 1 < len) {
                char code = Character.toLowerCase(text.charAt(i + 1));
                String mm = legacyCodeToMM(code);
                if (mm != null) {
                    sb.append(mm);
                    i += 2;
                    continue;
                }
            }
            sb.append(c);
            i++;
        }
        return sb.toString();
    }

    private static String legacyCodeToMM(char code) {
        return switch (code) {
            case '0' -> "<black>";
            case '1' -> "<dark_blue>";
            case '2' -> "<dark_green>";
            case '3' -> "<dark_aqua>";
            case '4' -> "<dark_red>";
            case '5' -> "<dark_purple>";
            case '6' -> "<gold>";
            case '7' -> "<gray>";
            case '8' -> "<dark_gray>";
            case '9' -> "<blue>";
            case 'a' -> "<green>";
            case 'b' -> "<aqua>";
            case 'c' -> "<red>";
            case 'd' -> "<light_purple>";
            case 'e' -> "<yellow>";
            case 'f' -> "<white>";
            case 'l' -> "<bold>";
            case 'm' -> "<strikethrough>";
            case 'n' -> "<underlined>";
            case 'o' -> "<italic>";
            case 'r' -> "<reset>";
            default -> null;
        };
    }

    public static String color(String msg) {
        if (msg == null) return "";
        return msg.replace("&", "§");
    }

    public static Component component(String legacyText) {
        return parse(legacyText);
    }
}
