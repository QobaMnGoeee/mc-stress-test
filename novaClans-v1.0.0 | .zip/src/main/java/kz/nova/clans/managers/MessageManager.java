package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.List;

public class MessageManager {

    private final NovaClans plugin;
    private YamlConfiguration messages;
    private String prefix;

    public MessageManager(NovaClans plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) plugin.saveResource("messages.yml", false);
        messages = YamlConfiguration.loadConfiguration(file);
        prefix = color(plugin.getConfig().getString("prefix", "&8[&bNovaClan&8] &r"));
    }

    public String getPrefix() { return prefix; }

    public String getRaw(String key) {
        String val = messages.getString(key);
        if (val == null) return "&c[NovaClans] Missing message: " + key;
        return color(val);
    }

    public String get(String key, Object... replacements) {
        String msg = getRaw(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace(String.valueOf(replacements[i]), String.valueOf(replacements[i + 1]));
        }
        return prefix + msg;
    }

    public List<String> getList(String key) {
        return messages.getStringList(key).stream()
                .map(MessageManager::color)
                .toList();
    }

    public void send(CommandSender sender, String key, Object... replacements) {
        String msg = get(key, replacements);
        sender.sendMessage(component(msg));
    }

    public void sendRaw(CommandSender sender, String msg) {
        sender.sendMessage(component(color(msg)));
    }

    public void sendList(CommandSender sender, String key) {
        getList(key).forEach(line -> sender.sendMessage(component(line)));
    }

    public void broadcast(String key, Object... replacements) {
        List<String> lines = messages.getStringList(key);
        for (String line : lines) {
            String formatted = color(line);
            for (int i = 0; i + 1 < replacements.length; i += 2) {
                formatted = formatted.replace(String.valueOf(replacements[i]), String.valueOf(replacements[i + 1]));
            }
            String finalLine = formatted;
            Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(component(finalLine)));
            Bukkit.getConsoleSender().sendMessage(component(finalLine));
        }
    }

    public static String color(String msg) {
        if (msg == null) return "";
        return msg.replace("&", "§");
    }

    public static Component component(String legacyText) {
        return LegacyComponentSerializer.legacySection().deserialize(legacyText);
    }
}
