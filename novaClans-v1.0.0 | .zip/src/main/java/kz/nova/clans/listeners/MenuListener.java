package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.managers.MenuManager;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.entity.Player;

public class MenuListener implements Listener {

    private final NovaClans plugin;
    private final MenuManager menuManager;

    public MenuListener(NovaClans plugin) {
        this.plugin = plugin;
        this.menuManager = plugin.getMenuManager();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        Inventory inv = event.getInventory();
        String title = LegacyComponentSerializer.legacySection()
                .serialize(inv.getType().defaultTitle());
        try {
            title = LegacyComponentSerializer.legacySection()
                    .serialize(event.getView().title());
        } catch (Exception ignored) {}

        boolean inVault = menuManager.isInStorageVault(player.getUniqueId());
        boolean inInfo = menuManager.isInStorageInfo(player.getUniqueId());

        // Allow item movement in vault
        if (inVault) {
            // Only block clicks on null slots outside the vault size
            return;
        }

        // Block all clicks in GUI menus
        if (inInfo || isNovaMenu(title)) {
            event.setCancelled(true);
            if (event.getCurrentItem() == null) return;

            handleMenuClick(player, event, title);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        boolean inVault = menuManager.isInStorageVault(player.getUniqueId());
        if (!inVault) {
            String title = "";
            try {
                title = LegacyComponentSerializer.legacySection()
                        .serialize(event.getView().title());
            } catch (Exception ignored) {}
            if (isNovaMenu(title)) event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (menuManager.isInStorageVault(player.getUniqueId())) {
            menuManager.saveVaultAndClose(player, event.getInventory());
        } else {
            menuManager.removeFromStorageTracking(player.getUniqueId());
        }
    }

    private void handleMenuClick(Player player, InventoryClickEvent event, String title) {
        if (event.getCurrentItem() == null) return;

        String itemName = "";
        if (event.getCurrentItem().hasItemMeta() && event.getCurrentItem().getItemMeta().hasDisplayName()) {
            itemName = LegacyComponentSerializer.legacySection()
                    .serialize(event.getCurrentItem().getItemMeta().displayName());
        }

        // Storage info menu — 4 info slots
        if (menuManager.isInStorageInfo(player.getUniqueId())) {
            int slot = event.getSlot();
            switch (slot) {
                case 37 -> { /* Info — no action */ }
                case 38 -> { /* Quest — no action */ }
                case 40 -> {
                    player.closeInventory();
                    plugin.getMenuManager().openMembersMenu(player);
                }
                case 41 -> {
                    player.closeInventory();
                    plugin.getMenuManager().openClanVault(player);
                }
            }
            return;
        }

        // Main menu - no clan
        if (itemName.contains("Клан Құру")) {
            player.closeInventory();
            plugin.getMessageManager().sendRaw(player,
                    "&eКлан атын чатқа теріңіз немесе &b/clan create <ат> &eколданыңыз.");
        }

        // Main menu - with clan
        if (itemName.contains("Клан Қоймасы") && !itemName.contains("Ашу")) {
            player.closeInventory();
            plugin.getMenuManager().openStorageInfoMenu(player);
        }
        if (itemName.contains("Квесттер")) {
            player.closeInventory();
            plugin.getMenuManager().openQuestMenu(player);
        }
        if (itemName.contains("Клан Топ")) {
            player.closeInventory();
            plugin.getMenuManager().openTopMenu(player);
        }
        if (itemName.contains("Мүшелер")) {
            player.closeInventory();
            plugin.getMenuManager().openMembersMenu(player);
        }
        if (itemName.contains("Кері")) {
            player.closeInventory();
            plugin.getMenuManager().openMainMenu(player);
        }
    }

    private boolean isNovaMenu(String title) {
        return title.contains("NovaClans") || title.contains("Клан Қоймасы")
                || title.contains("Клан Топ") || title.contains("Мүшелер")
                || title.contains("Квесттер") || title.contains("Клан Мәзірі")
                || title.contains("NovaClans");
    }
}
