package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {

    private final NovaClans plugin;

    public ChatListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (plugin.getClanManager().isClanChatToggled(player.getUniqueId())) {
            event.setCancelled(true);
            plugin.getClanManager().sendClanChat(player, event.getMessage());
        }
    }
}
