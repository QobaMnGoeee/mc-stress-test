package kz.nova.clans;

import kz.nova.clans.commands.ClanChatCommand;
import kz.nova.clans.commands.ClanCommand;
import kz.nova.clans.listeners.ChatListener;
import kz.nova.clans.listeners.MenuListener;
import kz.nova.clans.listeners.PointsListener;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.DataManager;
import kz.nova.clans.managers.MenuManager;
import kz.nova.clans.managers.MessageManager;
import kz.nova.clans.placeholders.NovaPlaceholders;
import org.bukkit.plugin.java.JavaPlugin;

public class NovaClans extends JavaPlugin {

    private static NovaClans instance;

    private DataManager dataManager;
    private MessageManager messageManager;
    private ClanManager clanManager;
    private MenuManager menuManager;

    @Override
    public void onEnable() {
        instance = this;

        // Save default configs
        saveDefaultConfig();

        getLogger().info("╔═══════════════════════════════╗");
        getLogger().info("║     NovaClans v1.0.0          ║");
        getLogger().info("║     Initializing...           ║");
        getLogger().info("╚═══════════════════════════════╝");

        // Init managers
        this.dataManager = new DataManager(this);
        this.messageManager = new MessageManager(this);
        this.clanManager = new ClanManager(this);
        this.menuManager = new MenuManager(this);

        // Register commands
        ClanCommand clanCommand = new ClanCommand(this);
        getCommand("clan").setExecutor(clanCommand);
        getCommand("clan").setTabCompleter(clanCommand);
        getCommand("cc").setExecutor(new ClanChatCommand(this));

        // Register listeners
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new PointsListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);

        // PlaceholderAPI
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new NovaPlaceholders(this).register();
            getLogger().info("[NovaClans] PlaceholderAPI подключен!");
        } else {
            getLogger().warning("[NovaClans] PlaceholderAPI табылмады!");
        }

        // Auto-save every 5 minutes
        getServer().getScheduler().runTaskTimerAsynchronously(this,
                () -> dataManager.save(), 20L * 60 * 5, 20L * 60 * 5);

        getLogger().info("[NovaClans] Плагин сәтті іске қосылды!");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) dataManager.save();
        getLogger().info("[NovaClans] Деректер сақталды. Плагин өшірілді.");
    }

    // ─── Getters ─────────────────────────────────────────────────────────────

    public static NovaClans getInstance() { return instance; }
    public DataManager getDataManager() { return dataManager; }
    public MessageManager getMessageManager() { return messageManager; }
    public ClanManager getClanManager() { return clanManager; }
    public MenuManager getMenuManager() { return menuManager; }
}
