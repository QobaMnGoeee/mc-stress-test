package kz.nova.clans.data;

public enum ClanRole {
    MEMBER,
    DEPUTY,
    LEADER;

    public boolean isAtLeast(ClanRole other) {
        return this.ordinal() >= other.ordinal();
    }
}
