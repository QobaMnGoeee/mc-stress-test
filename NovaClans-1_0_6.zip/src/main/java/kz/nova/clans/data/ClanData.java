package kz.nova.clans.data;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class ClanData {

    private final String name;
    private UUID leader;
    private int level;
    private int points;
    private double balance;
    private final long created;
    private boolean pvpEnabled;
    private final Map<UUID, ClanMember> members = new LinkedHashMap<>();

    public ClanData(String name, UUID leader, int level, int points, double balance, long created, boolean pvpEnabled) {
        this.name = name;
        this.leader = leader;
        this.level = level;
        this.points = points;
        this.balance = balance;
        this.created = created;
        this.pvpEnabled = pvpEnabled;
    }

    public String getName() {
        return name;
    }

    public UUID getLeader() {
        return leader;
    }

    public void setLeader(UUID leader) {
        this.leader = leader;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public void addPoints(int amount) {
        this.points += amount;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public long getCreated() {
        return created;
    }

    public boolean isPvpEnabled() {
        return pvpEnabled;
    }

    public void setPvpEnabled(boolean pvpEnabled) {
        this.pvpEnabled = pvpEnabled;
    }

    public Map<UUID, ClanMember> getMembers() {
        return members;
    }

    public void addMember(ClanMember member) {
        members.put(member.getUuid(), member);
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }

    public ClanMember getMember(UUID uuid) {
        return members.get(uuid);
    }

    public boolean hasMember(UUID uuid) {
        return members.containsKey(uuid);
    }

    public int getMemberCount() {
        return members.size();
    }
}
