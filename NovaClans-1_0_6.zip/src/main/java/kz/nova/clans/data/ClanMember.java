package kz.nova.clans.data;

import java.util.UUID;

public class ClanMember {

    private final UUID uuid;
    private String name;
    private ClanRole role;
    private final long joined;

    public ClanMember(UUID uuid, String name, ClanRole role, long joined) {
        this.uuid = uuid;
        this.name = name;
        this.role = role;
        this.joined = joined;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ClanRole getRole() {
        return role;
    }

    public void setRole(ClanRole role) {
        this.role = role;
    }

    public long getJoined() {
        return joined;
    }
}
