package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

public class PointsListener implements Listener {

    private final NovaClans plugin;

    public PointsListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player victim)) return;
        if (attacker.getUniqueId().equals(victim.getUniqueId())) return;
        if (!plugin.getClanManager().isFriendlyFireAllowed(attacker.getUniqueId(), victim.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Entity killerEntity = victim.getKiller();
        if (!(killerEntity instanceof Player killer)) return;
        ClanData killerClan = plugin.getClanManager().getClanByPlayer(killer.getUniqueId());
        if (killerClan == null) return;
        if (plugin.getClanManager().areClanmates(killer.getUniqueId(), victim.getUniqueId())) return;
        int reward = plugin.getConfig().getInt("points.player-kill", 2);
        plugin.getClanManager().addPoints(killerClan, reward);
    }

    @EventHandler
    public void onMobKill(PlayerDeathEvent event) {
    }

    @EventHandler
    public void onEntityKillByPlayer(org.bukkit.event.entity.EntityDeathEvent event) {
        if (!(event.getEntity() instanceof Monster)) return;
        if (!(event.getEntity().getKiller() instanceof Player killer)) return;
        ClanData clan = plugin.getClanManager().getClanByPlayer(killer.getUniqueId());
        if (clan == null) return;
        int reward = plugin.getConfig().getInt("points.mob-kill", 1);
        plugin.getClanManager().addPoints(clan, reward);
    }
}
