package kz.nova.clans.listeners;

import io.papermc.paper.event.player.AsyncChatEvent;
import kz.nova.clans.NovaClans;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class ChatListener implements Listener {

    private final NovaClans plugin;

    public ChatListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getChatManager().isClanChatEnabled(player.getUniqueId())) return;
        if (plugin.getClanManager().getClanByPlayer(player.getUniqueId()) == null) {
            plugin.getChatManager().removePlayer(player.getUniqueId());
            return;
        }
        event.setCancelled(true);
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());
        plugin.getChatManager().sendClanMessage(player, message);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getChatManager().removePlayer(event.getPlayer().getUniqueId());
    }
}
