package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;

public class MenuListener implements Listener {

    private final NovaClans plugin;

    public MenuListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Inventory inv = event.getInventory();
        if (inv.getHolder() != null) return;

        String title = PlainTextComponentSerializer.plainText()
                .serialize(event.getView().title());

        if (title.contains("Клан Мәзірі") || title.contains(" — Клан")) {
            event.setCancelled(true);
            handleClanMenuClick(player, event.getRawSlot(), title);
            return;
        }
        if (title.contains("Клан Топ")) {
            event.setCancelled(true);
            if (event.getRawSlot() == 49) player.closeInventory();
            return;
        }
        if (title.contains("Мүшелер —")) {
            event.setCancelled(true);
            if (event.getRawSlot() == 49) plugin.getMenuManager().openMainMenu(player);
            return;
        }
        if (title.contains("Қойма") || title.contains("— Қойма")) {
            handleStorageClick(player, event, inv);
        }
    }

    private void handleClanMenuClick(Player player, int slot, String title) {
        ClanData clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());

        if (title.contains("Клан Мәзірі") && clan == null) {
            if (slot == 11) {
                player.closeInventory();
                player.sendMessage(MiniMessage.miniMessage().deserialize(
                        "<#ffc800>Клан атын жазыңыз: <#f0e173>/clan create <ат>"));
            } else if (slot == 15) {
                plugin.getMenuManager().openTopMenu(player);
            }
            return;
        }

        if (clan == null) return;

        if (slot == 10) {
            plugin.getMenuManager().openStorageMenu(player, clan);
        } else if (slot == 12) {
            plugin.getMenuManager().openMainMenu(player);
        } else if (slot == 14) {
            plugin.getMenuManager().openTopMenu(player);
        } else if (slot == 16) {
            plugin.getMenuManager().openMembersMenu(player, clan);
        }
    }

    private void handleStorageClick(Player player, InventoryClickEvent event, Inventory inv) {
        if (event.getClickedInventory() == null) return;
        if (!event.getClickedInventory().equals(inv)) return;
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        Inventory inv = event.getInventory();
        if (inv.getHolder() != null) return;

        String title = PlainTextComponentSerializer.plainText()
                .serialize(event.getView().title());

        if (title.contains("Қойма") || title.contains("— Қойма")) {
            ClanData clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
            if (clan == null) {
                for (ClanData c : plugin.getClanManager().getClans().values()) {
                    if (title.contains(c.getName())) {
                        clan = c;
                        break;
                    }
                }
            }
            if (clan != null) {
                plugin.getStorageManager().saveInventory(clan, inv);
            }
        }
    }
}
