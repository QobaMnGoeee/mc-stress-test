package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class NovaClanAdminCommand implements CommandExecutor, TabCompleter {

    private final NovaClans plugin;

    public NovaClanAdminCommand(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) {
            plugin.getMessageManager().send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            sendAdminHelp(sender);
            return true;
        }
        String sub = args[0].toLowerCase();
        switch (sub) {
            case "reload" -> {
                plugin.reloadPlugin();
                sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                        .deserialize("<green>NovaClans перезагружен."));
            }
            case "delete" -> {
                if (args.length < 2) { sender.sendMessage("Usage: /novaclans delete <clan>"); return true; }
                ClanData clan = plugin.getClanManager().getClan(args[1]);
                if (clan == null) { sender.sendMessage("Clan not found."); return true; }
                for (java.util.UUID uuid : clan.getMembers().keySet()) {
                    plugin.getClanManager().getClans();
                }
                plugin.getClanManager().getClans().remove(args[1].toLowerCase());
                plugin.getClanManager().save();
                sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                        .deserialize("<green>Клан <yellow>" + args[1] + " <green>жойылды."));
            }
            case "levelup" -> {
                if (args.length < 2) { sender.sendMessage("Usage: /novaclans levelup <clan>"); return true; }
                ClanData clan = plugin.getClanManager().getClan(args[1]);
                if (clan == null) { sender.sendMessage("Clan not found."); return true; }
                int maxLevel = plugin.getConfig().getInt("max-level", 5);
                if (clan.getLevel() >= maxLevel) {
                    sender.sendMessage("Clan is already at max level.");
                    return true;
                }
                clan.setLevel(clan.getLevel() + 1);
                plugin.getClanManager().save();
                sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                        .deserialize("<green>Клан <yellow>" + clan.getName()
                                + " <green>деңгейі <yellow>" + clan.getLevel() + " <green>болды."));
            }
            case "storage" -> {
                if (args.length < 2) { sender.sendMessage("Usage: /novaclans storage <clan>"); return true; }
                if (!(sender instanceof Player player)) {
                    plugin.getMessageManager().send(sender, "player-only");
                    return true;
                }
                ClanData clan = plugin.getClanManager().getClan(args[1]);
                if (clan == null) { sender.sendMessage("Clan not found."); return true; }
                plugin.getStorageManager().openStorage(player, clan);
            }
            case "addpoints" -> {
                if (args.length < 3) { sender.sendMessage("Usage: /novaclans addpoints <clan> <amount>"); return true; }
                ClanData clan = plugin.getClanManager().getClan(args[1]);
                if (clan == null) { sender.sendMessage("Clan not found."); return true; }
                try {
                    int amount = Integer.parseInt(args[2]);
                    plugin.getClanManager().addPoints(clan, amount);
                    sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                            .deserialize("<green>Added <yellow>" + amount + " <green>points to <yellow>" + clan.getName()));
                } catch (NumberFormatException e) {
                    sender.sendMessage("Invalid amount.");
                }
            }
            default -> sendAdminHelp(sender);
        }
        return true;
    }

    private void sendAdminHelp(CommandSender sender) {
        sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                "<gradient:#ffc800:#f2990a>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</gradient>"));
        sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                "   <gradient:#ffc800:#f2990a>✦ NovaClans Admin v1.0.4 ✦</gradient>"));
        sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                " <#ffc800>/novaclans reload <gray>— Конфигты қайта жүктеу"));
        sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                " <#ffc800>/novaclans delete <#f0e173><клан> <gray>— Кланды жою"));
        sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                " <#ffc800>/novaclans levelup <#f0e173><клан> <gray>— Клан деңгейін көтеру"));
        sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                " <#ffc800>/novaclans storage <#f0e173><клан> <gray>— Клан қоймасын ашу"));
        sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                " <#ffc800>/novaclans addpoints <#f0e173><клан> <сумма> <gray>— Ұпай қосу"));
        sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                "<gradient:#ffc800:#f2990a>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</gradient>"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            List.of("reload", "delete", "levelup", "storage", "addpoints").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .forEach(completions::add);
        } else if (args.length == 2 && !args[0].equalsIgnoreCase("reload")) {
            plugin.getClanManager().getClans().keySet().stream()
                    .filter(n -> n.startsWith(args[1].toLowerCase()))
                    .forEach(completions::add);
        }
        return completions;
    }
}
