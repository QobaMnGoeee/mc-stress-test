package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanRole;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ClanCommand implements CommandExecutor, TabCompleter {

    private final NovaClans plugin;

    public ClanCommand(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().send(sender, "player-only");
            return true;
        }
        if (args.length == 0) {
            plugin.getMenuManager().openMainMenu(player);
            return true;
        }
        String sub = args[0].toLowerCase();
        switch (sub) {
            case "create" -> handleCreate(player, args);
            case "delete" -> handleDelete(player);
            case "invite" -> handleInvite(player, args);
            case "accept" -> plugin.getClanManager().acceptInvite(player);
            case "deny" -> plugin.getClanManager().denyInvite(player);
            case "kick" -> handleKick(player, args);
            case "leave" -> plugin.getClanManager().leavePlayer(player);
            case "role" -> handleRole(player, args);
            case "promote" -> handlePromote(player, args);
            case "chat" -> handleChat(player);
            case "storage" -> handleStorage(player, args);
            case "top" -> plugin.getMenuManager().openTopMenu(player);
            case "pvp" -> plugin.getClanManager().togglePvp(player);
            case "help" -> sendHelp(player);
            default -> plugin.getMessageManager().send(player, "invalid-usage");
        }
        return true;
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            plugin.getMessageManager().send(player, "invalid-usage");
            return;
        }
        plugin.getClanManager().createClan(player, args[1]);
    }

    private void handleDelete(Player player) {
        plugin.getClanManager().deleteClan(player);
    }

    private void handleInvite(Player player, String[] args) {
        if (args.length < 2) {
            plugin.getMessageManager().send(player, "invalid-usage");
            return;
        }
        Player target = plugin.getServer().getPlayer(args[1]);
        if (target == null) {
            plugin.getMessageManager().send(player, "player-not-found", Map.of("player", args[1]));
            return;
        }
        plugin.getClanManager().invitePlayer(player, target);
    }

    private void handleKick(Player player, String[] args) {
        if (args.length < 2) {
            plugin.getMessageManager().send(player, "invalid-usage");
            return;
        }
        Player target = plugin.getServer().getPlayer(args[1]);
        if (target == null) {
            plugin.getMessageManager().send(player, "player-not-found", Map.of("player", args[1]));
            return;
        }
        plugin.getClanManager().kickPlayer(player, target);
    }

    private void handleRole(Player player, String[] args) {
        if (args.length < 3) {
            plugin.getMessageManager().send(player, "invalid-usage");
            return;
        }
        Player target = plugin.getServer().getPlayer(args[1]);
        if (target == null) {
            plugin.getMessageManager().send(player, "player-not-found", Map.of("player", args[1]));
            return;
        }
        ClanRole role;
        try {
            role = ClanRole.valueOf(args[2].toUpperCase());
        } catch (IllegalArgumentException e) {
            plugin.getMessageManager().send(player, "clan-role-invalid");
            return;
        }
        plugin.getClanManager().setRole(player, target, role);
    }

    private void handlePromote(Player player, String[] args) {
        if (args.length < 2) {
            plugin.getMessageManager().send(player, "invalid-usage");
            return;
        }
        Player target = plugin.getServer().getPlayer(args[1]);
        if (target == null) {
            plugin.getMessageManager().send(player, "player-not-found", Map.of("player", args[1]));
            return;
        }
        plugin.getClanManager().promoteLeader(player, target);
    }

    private void handleChat(Player player) {
        plugin.getChatManager().toggleClanChat(player);
    }

    private void handleStorage(Player player, String[] args) {
        ClanData clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return;
        }
        if (args.length == 1) {
            plugin.getMenuManager().openStorageMenu(player, clan);
            return;
        }
        String action = args[1].toLowerCase();
        if (action.equals("add") || action.equals("take")) {
            if (args.length < 3) {
                plugin.getMessageManager().send(player, "invalid-usage");
                return;
            }
            double amount;
            try {
                amount = Double.parseDouble(args[2]);
                if (amount <= 0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                plugin.getMessageManager().send(player, "clan-storage-invalid-amount");
                return;
            }
            Economy eco = plugin.getEconomy();
            if (eco == null) return;
            if (action.equals("add")) {
                if (!eco.has(player, amount)) {
                    plugin.getMessageManager().send(player, "clan-storage-no-money");
                    return;
                }
                eco.withdrawPlayer(player, amount);
                clan.setBalance(clan.getBalance() + amount);
                plugin.getClanManager().save();
                plugin.getMessageManager().send(player, "clan-storage-deposit-success",
                        Map.of("amount", String.format("%.0f", amount),
                                "balance", String.format("%.0f", clan.getBalance())));
            } else {
                if (clan.getBalance() < amount) {
                    plugin.getMessageManager().send(player, "clan-storage-not-enough",
                            Map.of("balance", String.format("%.0f", clan.getBalance())));
                    return;
                }
                clan.setBalance(clan.getBalance() - amount);
                eco.depositPlayer(player, amount);
                plugin.getClanManager().save();
                plugin.getMessageManager().send(player, "clan-storage-withdraw-success",
                        Map.of("amount", String.format("%.0f", amount),
                                "balance", String.format("%.0f", clan.getBalance())));
            }
        }
    }

    private void sendHelp(Player player) {
        plugin.getMessageManager().getList("clan-help", Map.of())
                .forEach(player::sendMessage);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            List<String> subs = List.of("create", "delete", "invite", "accept", "deny",
                    "kick", "leave", "role", "promote", "chat", "storage", "top", "pvp", "help");
            String partial = args[0].toLowerCase();
            subs.stream().filter(s -> s.startsWith(partial)).forEach(completions::add);
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (List.of("invite", "kick", "role", "promote").contains(sub)) {
                plugin.getServer().getOnlinePlayers().stream()
                        .map(Player::getName)
                        .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                        .forEach(completions::add);
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("role")) {
            List.of("MEMBER", "DEPUTY").stream()
                    .filter(r -> r.toLowerCase().startsWith(args[2].toLowerCase()))
                    .forEach(completions::add);
        }
        return completions;
    }
}
