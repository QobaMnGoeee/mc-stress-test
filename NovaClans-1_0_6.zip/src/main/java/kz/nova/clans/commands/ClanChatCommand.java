package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ClanChatCommand implements CommandExecutor {

    private final NovaClans plugin;

    public ClanChatCommand(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().send(sender, "player-only");
            return true;
        }
        if (args.length == 0) {
            plugin.getChatManager().toggleClanChat(player);
            return true;
        }
        String message = String.join(" ", args);
        plugin.getChatManager().sendClanMessage(player, message);
        return true;
    }
}
