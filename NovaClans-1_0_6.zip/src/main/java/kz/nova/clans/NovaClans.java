package kz.nova.clans;

import kz.nova.clans.commands.*;
import kz.nova.clans.listeners.ChatListener;
import kz.nova.clans.listeners.MenuListener;
import kz.nova.clans.listeners.PointsListener;
import kz.nova.clans.managers.*;
import kz.nova.clans.placeholders.NovaPlaceholders;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class NovaClans extends JavaPlugin {

    private Economy economy;
    private ClanManager clanManager;
    private DataManager dataManager;
    private MessageManager messageManager;
    private MenuManager menuManager;
    private StorageManager storageManager;
    private ChatManager chatManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataManager = new DataManager(this);
        messageManager = new MessageManager(this);
        clanManager = new ClanManager(this);
        storageManager = new StorageManager(this);
        menuManager = new MenuManager(this);
        chatManager = new ChatManager(this);

        setupEconomy();
        clanManager.load();
        storageManager.load();

        registerCommands();
        registerListeners();

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new NovaPlaceholders(this).register();
        }

        getLogger().info("NovaClans v" + getDescription().getVersion() + " іске қосылды!");
    }

    @Override
    public void onDisable() {
        if (clanManager != null) clanManager.save();
        if (storageManager != null) storageManager.save();
        getLogger().info("NovaClans сақталды және өшірілді.");
    }

    private void setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) economy = rsp.getProvider();
    }

    private void registerCommands() {
        getCommand("clan").setExecutor(new ClanCommand(this));
        getCommand("clan").setTabCompleter(new ClanCommand(this));
        getCommand("cc").setExecutor(new ClanChatCommand(this));
        getCommand("novaclans").setExecutor(new NovaClanAdminCommand(this));
        getCommand("novaclans").setTabCompleter(new NovaClanAdminCommand(this));
        getCommand("xerecome").setExecutor(new XereComeCommand(this));
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getPluginManager().registerEvents(new PointsListener(this), this);
    }

    public void reloadPlugin() {
        reloadConfig();
        messageManager.reload();
        clanManager.save();
        clanManager.load();
    }

    public Economy getEconomy() {
        return economy;
    }

    public ClanManager getClanManager() {
        return clanManager;
    }

    public DataManager getDataManager() {
        return dataManager;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }

    public MenuManager getMenuManager() {
        return menuManager;
    }

    public StorageManager getStorageManager() {
        return storageManager;
    }

    public ChatManager getChatManager() {
        return chatManager;
    }
}
