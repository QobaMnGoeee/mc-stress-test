package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MenuManager {

    private final NovaClans plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public MenuManager(NovaClans plugin) {
        this.plugin = plugin;
    }

    private Component parse(String text, Map<String, String> placeholders) {
        String processed = text;
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            processed = processed.replace("%" + entry.getKey() + "%", entry.getValue());
            processed = processed.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return mm.deserialize(processed);
    }

    private List<Component> parseList(List<String> lines, Map<String, String> placeholders) {
        return lines.stream().map(line -> parse(line, placeholders)).collect(Collectors.toList());
    }

    private ItemStack buildItem(Material material, String name, List<String> lore,
                                boolean enchanted, Map<String, String> placeholders) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(parse(name, placeholders));
        meta.lore(parseList(lore, placeholders));
        if (enchanted) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
        }
        item.setItemMeta(meta);
        return item;
    }

    public void openMainMenu(Player player) {
        ClanData clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            openNoClanMenu(player);
        } else {
            openClanMenu(player, clan);
        }
    }

    private void openNoClanMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, mm.deserialize("<dark_gray>Клан Мәзірі"));
        ItemStack create = buildItem(Material.EMERALD,
                "<gradient:#ffc800:#f2990a><bold> Клан Құру</bold></gradient>",
                List.of(" ", " <#ffc800>Өз кланыңызды ашып,",
                        " <#ffc800>достарыңызбен бірге күш жинаңыз!",
                        "",
                        " <#ffc800>Баға: <#f0e173>50,000₸",
                        " <#ffc800>Немесе: <#f0e173>/clan create <ат>",
                        " "),
                true, Map.of());
        ItemStack top = buildItem(Material.GOLD_INGOT,
                "<gradient:#ffc800:#f2990a><bold> Клан Топ</bold></gradient>",
                List.of(" ", " <#ffc800>Ең күшті кландарды",
                        " <#ffc800>осы жерден тексеріңіз!",
                        "", " <#ffc800>Басу үшін шертіңіз →", " "),
                false, Map.of());
        inv.setItem(11, create);
        inv.setItem(15, top);
        fillBorder(inv);
        player.openInventory(inv);
    }

    private void openClanMenu(Player player, ClanData clan) {
        Map<String, String> ph = buildClanPlaceholders(player, clan);
        Inventory inv = Bukkit.createInventory(null, 36,
                parse("<dark_gray>" + clan.getName() + " — Клан", ph));

        ItemStack storage = buildItem(Material.CHEST,
                "<gradient:#ffc800:#f2990a><bold> Менің кланым..</bold></gradient>",
                List.of(" ", " <#ffc800>Клан туралы жалпы ақпарат",
                        " <#ffc800>Басу үшін шертіңіз →", " "),
                false, ph);
        ItemStack quests = buildItem(Material.BOOK,
                "<gradient:#ffc800:#f2990a><bold> Квесттер</bold></gradient>",
                List.of(" ", " <#ffc800>Клан квесттерін орындап",
                        " <#ffc800>ұпай жинаңыз!", "",
                        " <#ffc800>Ұпай: <#f0e173>" + clan.getPoints(),
                        " <#ffc800>Басу үшін шертіңіз →", " "),
                false, ph);
        ItemStack topItem = buildItem(Material.GOLD_INGOT,
                "<gradient:#ffc800:#f2990a><bold> Клан Топ</bold></gradient>",
                List.of(" ", " <#ffc800>Ең күшті кландарды",
                        " <#ffc800>осы жерден тексеріңіз!", "",
                        " <#ffc800>Басу үшін шертіңіз →", " "),
                false, ph);
        ItemStack members = buildItem(Material.PLAYER_HEAD,
                "<gradient:#ffc800:#f2990a><bold> Мүшелер</bold></gradient>",
                List.of(" ", " <#ffc800>Клан мүшелерін осы жерден қараңыз.", "",
                        " <#ffc800>Басу үшін шертіңіз →", " "),
                false, ph);

        String pvpStatus = clan.isPvpEnabled()
                ? "<green>ҚОСУЛЫ</green>"
                : "<red>ӨШІРУЛІ</red>";
        ItemStack pvpItem = buildItem(Material.IRON_SWORD,
                "<gradient:#ffc800:#f2990a><bold> Ішкі PvP</bold></gradient>",
                List.of(" ", " <#ffc800>Күй: " + pvpStatus, "",
                        " <#ffc800>Тек LEADER өзгерте алады.",
                        " <#ffc800>Команда: <#f0e173>/clan pvp", " "),
                false, ph);

        ItemStack info = buildItem(Material.NETHER_STAR,
                " <gradient:#ffc800:#f2990a><bold>Клан Ақпараты</bold></gradient>",
                List.of(" ",
                        " <#ffc800>Клан аты: <#f0e173>" + clan.getName(),
                        " <#ffc800>Деңгей: <#f0e173>" + clan.getLevel(),
                        " <#ffc800>Ұпай: <#f0e173>" + clan.getPoints(),
                        " <#ffc800>Баланс: <#f0e173>" + String.format("%.0f", clan.getBalance()) + "₸",
                        " <#ffc800>Мүшелер: <#f0e173>" + clan.getMemberCount() + "/"
                                + plugin.getClanManager().getMaxMembersByLevel(clan.getLevel()),
                        " "),
                false, ph);

        inv.setItem(10, storage);
        inv.setItem(12, quests);
        inv.setItem(14, topItem);
        inv.setItem(16, members);
        inv.setItem(19, pvpItem);
        inv.setItem(31, info);
        fillBorder(inv);
        player.openInventory(inv);
    }

    public void openTopMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54,
                mm.deserialize("<dark_gray>Клан Топ-10"));
        List<ClanData> sorted = plugin.getClanManager().getClans().values().stream()
                .sorted(Comparator.comparingInt(ClanData::getPoints).reversed())
                .limit(10)
                .collect(Collectors.toList());
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};
        for (int i = 0; i < sorted.size() && i < slots.length; i++) {
            ClanData clan = sorted.get(i);
            ItemStack item = buildItem(Material.PLAYER_HEAD,
                    "<gradient:#ffc800:#f2990a><bold> " + (i + 1) + ". " + clan.getName() + "</bold></gradient>",
                    List.of(" ",
                            " <#ffc800>Деңгей: <#f0e173>" + clan.getLevel(),
                            " <#ffc800>Ұпай: <#f0e173>" + clan.getPoints(),
                            " <#ffc800>Мүшелер: <#f0e173>" + clan.getMemberCount(),
                            " "),
                    false, Map.of());
            inv.setItem(slots[i], item);
        }
        ItemStack back = buildBackItem();
        inv.setItem(49, back);
        fillBorder(inv);
        player.openInventory(inv);
    }

    public void openMembersMenu(Player player, ClanData clan) {
        Inventory inv = Bukkit.createInventory(null, 54,
                mm.deserialize("<dark_gray>Мүшелер — " + clan.getName()));
        List<ClanMember> memberList = new ArrayList<>(clan.getMembers().values());
        memberList.sort(Comparator.comparingInt((ClanMember m) -> m.getRole().ordinal()).reversed());
        int slot = 10;
        for (ClanMember member : memberList) {
            if (slot >= 44) break;
            String roleColor = switch (member.getRole()) {
                case LEADER -> "<gold>";
                case DEPUTY -> "<yellow>";
                case MEMBER -> "<white>";
            };
            ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) skull.getItemMeta();
            meta.displayName(mm.deserialize(roleColor + member.getName()));
            meta.lore(List.of(
                    mm.deserialize(" <#ffc800>Рөл: <#f0e173>" + member.getRole().name()),
                    mm.deserialize(" <#ffc800>Қосылды: <#f0e173>" + formatDate(member.getJoined()))
            ));
            skull.setItemMeta(meta);
            inv.setItem(slot++, skull);
            if (slot == 17 || slot == 26 || slot == 35) slot += 2;
        }
        inv.setItem(49, buildBackItem());
        fillBorder(inv);
        player.openInventory(inv);
    }

    public void openStorageMenu(Player player, ClanData clan) {
        plugin.getStorageManager().openStorage(player, clan);
    }

    private ItemStack buildBackItem() {
        return buildItem(Material.ARROW,
                "<gradient:#ffc800:#f2990a><bold> ← Кері</bold></gradient>",
                List.of(" ", " <#ffc800>Негізгі мәзірге оралу",
                        " <#ffc800>Басу үшін шертіңіз →", " "),
                false, Map.of());
    }

    private void fillBorder(Inventory inv) {
        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = glass.getItemMeta();
        meta.displayName(Component.empty());
        glass.setItemMeta(meta);
        int size = inv.getSize();
        int rows = size / 9;
        for (int i = 0; i < 9; i++) inv.setItem(i, glass);
        for (int i = size - 9; i < size; i++) inv.setItem(i, glass);
        for (int r = 1; r < rows - 1; r++) {
            inv.setItem(r * 9, glass);
            inv.setItem(r * 9 + 8, glass);
        }
    }

    private Map<String, String> buildClanPlaceholders(Player player, ClanData clan) {
        ClanMember member = clan.getMember(player.getUniqueId());
        return Map.of(
                "nova_clan_name", clan.getName(),
                "nova_clan_level", String.valueOf(clan.getLevel()),
                "nova_clan_points", String.valueOf(clan.getPoints()),
                "nova_clan_balance", String.format("%.0f", clan.getBalance()),
                "nova_clan_role", member != null ? member.getRole().name() : "NONE"
        );
    }

    private String formatDate(long millis) {
        java.time.LocalDate date = java.time.Instant.ofEpochMilli(millis)
                .atZone(java.time.ZoneId.systemDefault()).toLocalDate();
        return date.toString();
    }

    public String identifyMenu(Inventory inv, Player player) {
        Component title = inv.getViewers().isEmpty() ? Component.empty()
                : player.getOpenInventory().title();
        String titleStr = MiniMessage.miniMessage().serialize(title);
        if (titleStr.contains("Клан Топ")) return "TOP";
        if (titleStr.contains("Мүшелер")) return "MEMBERS";
        if (titleStr.contains("Қойма") || titleStr.contains("storage")) return "STORAGE";
        if (titleStr.contains("Клан Мәзірі") || titleStr.contains("Клан")) return "CLAN";
        return "UNKNOWN";
    }
}
