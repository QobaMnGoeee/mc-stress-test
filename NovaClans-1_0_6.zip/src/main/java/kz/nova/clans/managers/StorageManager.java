package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

public class StorageManager {

    private final NovaClans plugin;
    private final Map<String, byte[]> storageData = new HashMap<>();

    public StorageManager(NovaClans plugin) {
        this.plugin = plugin;
    }

    public void load() {
        storageData.putAll(plugin.getDataManager().loadStorages());
    }

    public void save() {
        plugin.getDataManager().saveStorages(storageData);
    }

    public void openStorage(Player player, ClanData clan) {
        int level = clan.getLevel();
        int slots = plugin.getConfig().getInt("storage.level-" + level, 27);
        Component title = MiniMessage.miniMessage().deserialize(
                "<gradient:#ffc800:#f2990a>" + clan.getName() + " — Қойма</gradient>");
        Inventory inv = Bukkit.createInventory(null, slots, title);
        byte[] data = storageData.get(clan.getName().toLowerCase());
        if (data != null) {
            loadInventory(inv, data);
        }
        player.openInventory(inv);
    }

    public void saveInventory(ClanData clan, Inventory inventory) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            BukkitObjectOutputStream oos = new BukkitObjectOutputStream(baos);
            oos.writeInt(inventory.getSize());
            for (int i = 0; i < inventory.getSize(); i++) {
                oos.writeObject(inventory.getItem(i));
            }
            oos.flush();
            oos.close();
            storageData.put(clan.getName().toLowerCase(), baos.toByteArray());
            save();
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save storage for clan " + clan.getName() + ": " + e.getMessage());
        }
    }

    private void loadInventory(Inventory inv, byte[] data) {
        try {
            BukkitObjectInputStream ois = new BukkitObjectInputStream(new ByteArrayInputStream(data));
            int size = ois.readInt();
            for (int i = 0; i < size && i < inv.getSize(); i++) {
                inv.setItem(i, (org.bukkit.inventory.ItemStack) ois.readObject());
            }
            ois.close();
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to load storage: " + e.getMessage());
        }
    }

    public void deleteStorage(String clanName) {
        storageData.remove(clanName.toLowerCase());
        save();
    }

    public boolean isStorageInventory(Inventory inventory, ClanData clan) {
        int slots = plugin.getConfig().getInt("storage.level-" + clan.getLevel(), 27);
        return inventory.getSize() == slots;
    }
}
