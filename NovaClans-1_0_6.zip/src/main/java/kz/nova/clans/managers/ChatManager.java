package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class ChatManager {

    private final NovaClans plugin;
    private final Set<UUID> clanChatEnabled = new HashSet<>();
    private final MiniMessage mm = MiniMessage.miniMessage();

    public ChatManager(NovaClans plugin) {
        this.plugin = plugin;
    }

    public void toggleClanChat(Player player) {
        if (plugin.getClanManager().getClanByPlayer(player.getUniqueId()) == null) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return;
        }
        if (clanChatEnabled.contains(player.getUniqueId())) {
            clanChatEnabled.remove(player.getUniqueId());
            plugin.getMessageManager().send(player, "clan-chat-toggled-off");
        } else {
            clanChatEnabled.add(player.getUniqueId());
            plugin.getMessageManager().send(player, "clan-chat-toggled-on");
        }
    }

    public boolean isClanChatEnabled(UUID uuid) {
        return clanChatEnabled.contains(uuid);
    }

    public void sendClanMessage(Player player, String message) {
        ClanData clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return;
        }
        String format = plugin.getMessageManager().getRaw("clan-chat-format",
                Map.of("clan", clan.getName(), "player", player.getName(), "message", message));
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (clan.hasMember(online.getUniqueId())) {
                online.sendMessage(mm.deserialize(format));
            }
        }
    }

    public void removePlayer(UUID uuid) {
        clanChatEnabled.remove(uuid);
    }
}
