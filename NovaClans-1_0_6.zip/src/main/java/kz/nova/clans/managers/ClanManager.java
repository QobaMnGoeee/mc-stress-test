package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ClanManager {

    private final NovaClans plugin;
    private final Map<String, ClanData> clans = new HashMap<>();
    private final Map<UUID, String> playerClanIndex = new HashMap<>();
    private final Map<UUID, PendingInvite> pendingInvites = new HashMap<>();

    public static class PendingInvite {
        public final String clanName;
        public final UUID invitedBy;
        public final long expiresAt;

        public PendingInvite(String clanName, UUID invitedBy, long expiresAt) {
            this.clanName = clanName;
            this.invitedBy = invitedBy;
            this.expiresAt = expiresAt;
        }

        public boolean isExpired() {
            return System.currentTimeMillis() > expiresAt;
        }
    }

    public ClanManager(NovaClans plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.getDataManager().loadClans(clans);
        for (ClanData clan : clans.values()) {
            for (UUID uuid : clan.getMembers().keySet()) {
                playerClanIndex.put(uuid, clan.getName());
            }
        }
    }

    public void save() {
        plugin.getDataManager().saveClans(clans);
    }

    public boolean createClan(Player player, String name) {
        Economy eco = plugin.getEconomy();
        double price = plugin.getConfig().getDouble("clan-create-price", 50000);
        int minLen = plugin.getConfig().getInt("clan-name-min-length", 3);
        int maxLen = plugin.getConfig().getInt("clan-name-max-length", 16);

        if (getClanByPlayer(player.getUniqueId()) != null) {
            plugin.getMessageManager().send(player, "already-in-clan",
                    Map.of("clan", getClanByPlayer(player.getUniqueId()).getName()));
            return false;
        }
        if (name.length() < minLen || name.length() > maxLen || !name.matches("[a-zA-Z0-9_]+")) {
            plugin.getMessageManager().send(player, "clan-create-invalid-name",
                    Map.of("min", String.valueOf(minLen), "max", String.valueOf(maxLen)));
            return false;
        }
        if (clans.containsKey(name.toLowerCase())) {
            plugin.getMessageManager().send(player, "clan-create-name-taken");
            return false;
        }
        if (eco != null && !eco.has(player, price)) {
            plugin.getMessageManager().send(player, "clan-create-no-money",
                    Map.of("amount", String.format("%.0f", price)));
            return false;
        }
        if (eco != null) {
            eco.withdrawPlayer(player, price);
        }
        boolean defaultPvp = plugin.getConfig().getBoolean("pvp-enabled-by-default", true);
        ClanData clan = new ClanData(name, player.getUniqueId(), 1, 0, 0.0,
                System.currentTimeMillis(), defaultPvp);
        ClanMember leaderMember = new ClanMember(player.getUniqueId(), player.getName(),
                ClanRole.LEADER, System.currentTimeMillis());
        clan.addMember(leaderMember);
        clans.put(name.toLowerCase(), clan);
        playerClanIndex.put(player.getUniqueId(), name);
        save();
        plugin.getMessageManager().send(player, "clan-create-success",
                Map.of("clan", name, "amount", String.format("%.0f", price)));
        return true;
    }

    public boolean deleteClan(Player player) {
        ClanData clan = getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return false;
        }
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member == null || member.getRole() != ClanRole.LEADER) {
            plugin.getMessageManager().send(player, "clan-delete-no-permission");
            return false;
        }
        String clanName = clan.getName();
        for (UUID uuid : clan.getMembers().keySet()) {
            playerClanIndex.remove(uuid);
        }
        clans.remove(clanName.toLowerCase());
        plugin.getStorageManager().deleteStorage(clanName);
        save();
        plugin.getMessageManager().send(player, "clan-delete-success", Map.of("clan", clanName));
        return true;
    }

    public boolean invitePlayer(Player inviter, Player target) {
        ClanData clan = getClanByPlayer(inviter.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send(inviter, "not-in-clan");
            return false;
        }
        ClanMember inviterMember = clan.getMember(inviter.getUniqueId());
        if (inviterMember == null || !inviterMember.getRole().isAtLeast(ClanRole.DEPUTY)) {
            plugin.getMessageManager().send(inviter, "clan-invite-no-permission");
            return false;
        }
        if (getClanByPlayer(target.getUniqueId()) != null) {
            plugin.getMessageManager().send(inviter, "target-already-in-clan",
                    Map.of("player", target.getName()));
            return false;
        }
        int maxMembers = getMaxMembersByLevel(clan.getLevel());
        if (clan.getMemberCount() >= maxMembers) {
            plugin.getMessageManager().send(inviter, "clan-max-members-reached",
                    Map.of("max", String.valueOf(maxMembers)));
            return false;
        }
        long expiry = System.currentTimeMillis() + 60_000L;
        pendingInvites.put(target.getUniqueId(), new PendingInvite(clan.getName(), inviter.getUniqueId(), expiry));
        plugin.getMessageManager().send(inviter, "clan-invite-sent", Map.of("player", target.getName()));
        plugin.getMessageManager().send(target, "clan-invite-received",
                Map.of("player", inviter.getName(), "clan", clan.getName()));
        return true;
    }

    public boolean acceptInvite(Player player) {
        PendingInvite invite = pendingInvites.get(player.getUniqueId());
        if (invite == null || invite.isExpired()) {
            pendingInvites.remove(player.getUniqueId());
            plugin.getMessageManager().send(player, "clan-invite-no-pending");
            return false;
        }
        ClanData clan = clans.get(invite.clanName.toLowerCase());
        if (clan == null) {
            pendingInvites.remove(player.getUniqueId());
            plugin.getMessageManager().send(player, "clan-invite-no-pending");
            return false;
        }
        int maxMembers = getMaxMembersByLevel(clan.getLevel());
        if (clan.getMemberCount() >= maxMembers) {
            pendingInvites.remove(player.getUniqueId());
            plugin.getMessageManager().send(player, "clan-max-members-reached",
                    Map.of("max", String.valueOf(maxMembers)));
            return false;
        }
        if (getClanByPlayer(player.getUniqueId()) != null) {
            pendingInvites.remove(player.getUniqueId());
            plugin.getMessageManager().send(player, "already-in-clan",
                    Map.of("clan", getClanByPlayer(player.getUniqueId()).getName()));
            return false;
        }
        ClanMember newMember = new ClanMember(player.getUniqueId(), player.getName(),
                ClanRole.MEMBER, System.currentTimeMillis());
        clan.addMember(newMember);
        playerClanIndex.put(player.getUniqueId(), clan.getName());
        pendingInvites.remove(player.getUniqueId());
        save();
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (clan.hasMember(online.getUniqueId())) {
                plugin.getMessageManager().send(online, "clan-invite-accepted",
                        Map.of("player", player.getName()));
            }
        }
        return true;
    }

    public boolean denyInvite(Player player) {
        PendingInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            plugin.getMessageManager().send(player, "clan-invite-no-pending");
            return false;
        }
        Player inviter = plugin.getServer().getPlayer(invite.invitedBy);
        if (inviter != null) {
            plugin.getMessageManager().send(inviter, "clan-invite-denied",
                    Map.of("player", player.getName()));
        }
        return true;
    }

    public boolean kickPlayer(Player kicker, Player target) {
        ClanData clan = getClanByPlayer(kicker.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send(kicker, "not-in-clan");
            return false;
        }
        ClanMember kickerMember = clan.getMember(kicker.getUniqueId());
        if (kickerMember == null || !kickerMember.getRole().isAtLeast(ClanRole.DEPUTY)) {
            plugin.getMessageManager().send(kicker, "clan-kick-no-permission");
            return false;
        }
        if (kicker.getUniqueId().equals(target.getUniqueId())) {
            plugin.getMessageManager().send(kicker, "clan-kick-yourself");
            return false;
        }
        ClanMember targetMember = clan.getMember(target.getUniqueId());
        if (targetMember == null) {
            plugin.getMessageManager().send(kicker, "target-not-in-clan",
                    Map.of("player", target.getName()));
            return false;
        }
        if (targetMember.getRole() == ClanRole.LEADER) {
            plugin.getMessageManager().send(kicker, "clan-kick-leader");
            return false;
        }
        clan.removeMember(target.getUniqueId());
        playerClanIndex.remove(target.getUniqueId());
        save();
        plugin.getMessageManager().send(kicker, "clan-kick-success",
                Map.of("player", target.getName()));
        plugin.getMessageManager().send(target, "clan-kick-notify",
                Map.of("clan", clan.getName()));
        return true;
    }

    public boolean leavePlayer(Player player) {
        ClanData clan = getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return false;
        }
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member != null && member.getRole() == ClanRole.LEADER) {
            plugin.getMessageManager().send(player, "clan-leave-leader");
            return false;
        }
        clan.removeMember(player.getUniqueId());
        playerClanIndex.remove(player.getUniqueId());
        save();
        plugin.getMessageManager().send(player, "clan-leave-success",
                Map.of("clan", clan.getName()));
        return true;
    }

    public boolean setRole(Player setter, Player target, ClanRole newRole) {
        ClanData clan = getClanByPlayer(setter.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send(setter, "not-in-clan");
            return false;
        }
        ClanMember setterMember = clan.getMember(setter.getUniqueId());
        if (setterMember == null || setterMember.getRole() != ClanRole.LEADER) {
            plugin.getMessageManager().send(setter, "clan-role-no-permission");
            return false;
        }
        if (setter.getUniqueId().equals(target.getUniqueId())) {
            plugin.getMessageManager().send(setter, "clan-role-self");
            return false;
        }
        ClanMember targetMember = clan.getMember(target.getUniqueId());
        if (targetMember == null) {
            plugin.getMessageManager().send(setter, "target-not-in-clan",
                    Map.of("player", target.getName()));
            return false;
        }
        if (newRole == ClanRole.LEADER) {
            plugin.getMessageManager().send(setter, "clan-role-invalid");
            return false;
        }
        targetMember.setRole(newRole);
        save();
        plugin.getMessageManager().send(setter, "clan-role-set",
                Map.of("player", target.getName(), "role", newRole.name()));
        plugin.getMessageManager().send(target, "clan-role-notify",
                Map.of("role", newRole.name()));
        return true;
    }

    public boolean promoteLeader(Player leader, Player newLeader) {
        ClanData clan = getClanByPlayer(leader.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send(leader, "not-in-clan");
            return false;
        }
        ClanMember leaderMember = clan.getMember(leader.getUniqueId());
        if (leaderMember == null || leaderMember.getRole() != ClanRole.LEADER) {
            plugin.getMessageManager().send(leader, "clan-promote-no-permission");
            return false;
        }
        ClanMember targetMember = clan.getMember(newLeader.getUniqueId());
        if (targetMember == null) {
            plugin.getMessageManager().send(leader, "target-not-in-clan",
                    Map.of("player", newLeader.getName()));
            return false;
        }
        leaderMember.setRole(ClanRole.MEMBER);
        targetMember.setRole(ClanRole.LEADER);
        clan.setLeader(newLeader.getUniqueId());
        save();
        plugin.getMessageManager().send(leader, "clan-promote-success",
                Map.of("player", newLeader.getName()));
        plugin.getMessageManager().send(newLeader, "clan-promote-notify",
                Map.of("clan", clan.getName()));
        return true;
    }

    public boolean togglePvp(Player player) {
        ClanData clan = getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return false;
        }
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member == null || member.getRole() != ClanRole.LEADER) {
            plugin.getMessageManager().send(player, "clan-pvp-no-permission");
            return false;
        }
        boolean newState = !clan.isPvpEnabled();
        clan.setPvpEnabled(newState);
        save();
        String key = newState ? "clan-pvp-enabled" : "clan-pvp-disabled";
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (clan.hasMember(online.getUniqueId())) {
                plugin.getMessageManager().send(online, key);
            }
        }
        return true;
    }

    public boolean areClanmates(UUID a, UUID b) {
        String clanA = playerClanIndex.get(a);
        if (clanA == null) return false;
        return clanA.equalsIgnoreCase(playerClanIndex.get(b));
    }

    public boolean isFriendlyFireAllowed(UUID attacker, UUID victim) {
        if (!areClanmates(attacker, victim)) return true;
        ClanData clan = getClanByPlayer(attacker);
        if (clan == null) return true;
        return clan.isPvpEnabled();
    }

    public void addPoints(ClanData clan, int amount) {
        clan.addPoints(amount);
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (clan.getLevel() < maxLevel) {
            int nextLevelPoints = plugin.getConfig().getInt("levels." + (clan.getLevel() + 1), Integer.MAX_VALUE);
            if (clan.getPoints() >= nextLevelPoints) {
                clan.setLevel(clan.getLevel() + 1);
                plugin.getMessageManager().broadcast("clan-levelup-broadcast",
                        Map.of("clan", clan.getName(),
                                "level", String.valueOf(clan.getLevel()),
                                "points", String.valueOf(clan.getPoints())));
            }
        }
        save();
    }

    public int getMaxMembersByLevel(int level) {
        int configured = plugin.getConfig().getInt("max-members-by-level." + level, -1);
        if (configured > 0) return configured;
        return plugin.getConfig().getInt("clan-max-members", 30);
    }

    public ClanData getClan(String name) {
        return clans.get(name.toLowerCase());
    }

    public ClanData getClanByPlayer(UUID uuid) {
        String name = playerClanIndex.get(uuid);
        if (name == null) return null;
        return clans.get(name.toLowerCase());
    }

    public Map<String, ClanData> getClans() {
        return clans;
    }

    public PendingInvite getPendingInvite(UUID uuid) {
        return pendingInvites.get(uuid);
    }

    public void removePendingInvite(UUID uuid) {
        pendingInvites.remove(uuid);
    }
}
