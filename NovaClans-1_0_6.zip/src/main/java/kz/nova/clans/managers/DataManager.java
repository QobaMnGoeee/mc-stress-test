package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DataManager {

    private final NovaClans plugin;
    private final File dataFile;
    private FileConfiguration dataConfig;

    public DataManager(NovaClans plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "novaClans.yml");
        if (!dataFile.exists()) {
            plugin.saveResource("novaClans.yml", false);
        }
    }

    public void loadClans(Map<String, ClanData> clansMap) {
        if (!dataFile.exists()) {
            return;
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection clansSection = dataConfig.getConfigurationSection("clans");
        if (clansSection == null) {
            return;
        }
        boolean defaultPvp = plugin.getConfig().getBoolean("pvp-enabled-by-default", true);
        for (String clanName : clansSection.getKeys(false)) {
            ConfigurationSection cs = clansSection.getConfigurationSection(clanName);
            if (cs == null) continue;
            UUID leader = UUID.fromString(cs.getString("leader"));
            int level = cs.getInt("level", 1);
            int points = cs.getInt("points", 0);
            double balance = cs.getDouble("balance", 0.0);
            long created = cs.getLong("created", System.currentTimeMillis());
            boolean pvpEnabled = cs.getBoolean("pvp-enabled", defaultPvp);
            ClanData clan = new ClanData(clanName, leader, level, points, balance, created, pvpEnabled);
            ConfigurationSection membersSection = cs.getConfigurationSection("members");
            if (membersSection != null) {
                for (String uuidStr : membersSection.getKeys(false)) {
                    ConfigurationSection ms = membersSection.getConfigurationSection(uuidStr);
                    if (ms == null) continue;
                    UUID uuid = UUID.fromString(uuidStr);
                    String name = ms.getString("name", "Unknown");
                    ClanRole role = ClanRole.valueOf(ms.getString("role", "MEMBER"));
                    long joined = ms.getLong("joined", System.currentTimeMillis());
                    clan.addMember(new ClanMember(uuid, name, role, joined));
                }
            }
            clansMap.put(clanName.toLowerCase(), clan);
        }
    }

    public void saveClans(Map<String, ClanData> clansMap) {
        dataConfig = new YamlConfiguration();
        for (ClanData clan : clansMap.values()) {
            String base = "clans." + clan.getName();
            dataConfig.set(base + ".leader", clan.getLeader().toString());
            dataConfig.set(base + ".level", clan.getLevel());
            dataConfig.set(base + ".points", clan.getPoints());
            dataConfig.set(base + ".balance", clan.getBalance());
            dataConfig.set(base + ".created", clan.getCreated());
            dataConfig.set(base + ".pvp-enabled", clan.isPvpEnabled());
            for (ClanMember member : clan.getMembers().values()) {
                String mBase = base + ".members." + member.getUuid().toString();
                dataConfig.set(mBase + ".name", member.getName());
                dataConfig.set(mBase + ".role", member.getRole().name());
                dataConfig.set(mBase + ".joined", member.getJoined());
            }
        }
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save novaClans.yml: " + e.getMessage());
        }
    }

    public Map<String, byte[]> loadStorages() {
        Map<String, byte[]> result = new HashMap<>();
        File storageFile = new File(plugin.getDataFolder(), "storage.yml");
        if (!storageFile.exists()) return result;
        FileConfiguration sc = YamlConfiguration.loadConfiguration(storageFile);
        ConfigurationSection section = sc.getConfigurationSection("storages");
        if (section == null) return result;
        for (String clanName : section.getKeys(false)) {
            String data = sc.getString("storages." + clanName);
            if (data != null && !data.isEmpty()) {
                result.put(clanName.toLowerCase(), java.util.Base64.getDecoder().decode(data));
            }
        }
        return result;
    }

    public void saveStorages(Map<String, byte[]> storages) {
        File storageFile = new File(plugin.getDataFolder(), "storage.yml");
        YamlConfiguration sc = new YamlConfiguration();
        for (Map.Entry<String, byte[]> entry : storages.entrySet()) {
            sc.set("storages." + entry.getKey(), java.util.Base64.getEncoder().encodeToString(entry.getValue()));
        }
        try {
            sc.save(storageFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save storage.yml: " + e.getMessage());
        }
    }
}
