package kz.nova.clans.placeholders;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

public class NovaPlaceholders extends PlaceholderExpansion {

    private final NovaClans plugin;

    public NovaPlaceholders(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "nova";
    }

    @Override
    public @NotNull String getAuthor() {
        return "NovaNetwork";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        ClanData clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        return switch (params) {
            case "clan_name" -> clan != null ? clan.getName() : "—";
            case "clan_level" -> clan != null ? String.valueOf(clan.getLevel()) : "0";
            case "clan_points" -> clan != null ? String.valueOf(clan.getPoints()) : "0";
            case "clan_balance" -> clan != null ? String.format("%.0f", clan.getBalance()) : "0";
            case "clan_role" -> {
                if (clan == null) yield "—";
                ClanMember member = clan.getMember(player.getUniqueId());
                yield member != null ? member.getRole().name() : "—";
            }
            case "clan_members" -> clan != null ? String.valueOf(clan.getMemberCount()) : "0";
            case "clan_max_members" -> clan != null
                    ? String.valueOf(plugin.getClanManager().getMaxMembersByLevel(clan.getLevel()))
                    : "0";
            case "clan_pvp" -> clan != null ? (clan.isPvpEnabled() ? "ON" : "OFF") : "—";
            default -> null;
        };
    }
}
