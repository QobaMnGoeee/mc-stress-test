package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

/**
 * Handles clan point gains.
 * Block-breaking points have been removed entirely — only kills award points.
 */
public class PointsListener implements Listener {

    private final NovaClans plugin;

    public PointsListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        Entity entity = event.getEntity();
        Player killer = event.getEntity().getKiller();
        if (killer == null) return;

        ClanData clan = plugin.getDataManager().getClanByPlayer(killer.getUniqueId());
        if (clan == null) return;

        if (entity instanceof Player) {
            // Do not award points for killing own clan members
            ClanData victimClan = plugin.getDataManager().getClanByPlayer(entity.getUniqueId());
            if (victimClan != null && victimClan.getName().equalsIgnoreCase(clan.getName())) return;
            long pts = plugin.getConfig().getLong("points.player-kill", 2);
            plugin.getClanManager().addPoints(clan, pts);
        } else if (entity instanceof Monster) {
            long pts = plugin.getConfig().getLong("points.mob-kill", 1);
            plugin.getClanManager().addPoints(clan, pts);
        }
    }
    // BlockBreakEvent listener intentionally absent — block-breaking no longer awards points.
}
