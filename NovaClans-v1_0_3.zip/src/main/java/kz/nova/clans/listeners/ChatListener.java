package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {

    private final NovaClans plugin;

    public ChatListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();

        // Redirect to clan chat if player has toggled it on
        if (plugin.getClanManager().isClanChatToggled(player.getUniqueId())) {
            event.setCancelled(true);
            plugin.getClanManager().sendClanChat(player, event.getMessage());
            return;
        }

        // Inject clan tag into the chat format
        // Tag format: §8[§6CLANNAME§8]  (§6 is the closest legacy code to #ffc800 gold)
        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan != null) {
            String clanTag = "\u00a78[\u00a76" + clan.getName() + "\u00a78] ";
            event.setFormat(clanTag + event.getFormat());
        }
    }
}
