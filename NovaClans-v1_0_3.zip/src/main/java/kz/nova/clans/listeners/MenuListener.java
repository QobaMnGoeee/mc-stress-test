package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.managers.MenuManager;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.entity.Player;

public class MenuListener implements Listener {

    private final NovaClans plugin;
    private final MenuManager menuManager;

    public MenuListener(NovaClans plugin) {
        this.plugin = plugin;
        this.menuManager = plugin.getMenuManager();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        String title = plainTitle(event.getView().title());
        boolean inVault = menuManager.isInStorageVault(player.getUniqueId());
        boolean inStorageInfo = menuManager.isInStorageInfo(player.getUniqueId());

        // Vault — allow item movement
        if (inVault) return;

        if (!isNovaMenu(title)) return;

        event.setCancelled(true);
        if (event.getCurrentItem() == null) return;

        if (inStorageInfo) {
            menuManager.handleStorageInfoSlotClick(player, event.getSlot());
            return;
        }

        // Members, Top, Quest menus — back button is slot 49 or 31
        if (isMembersMenu(title) || isTopMenu(title) || isQuestMenu(title)) {
            menuManager.handleSubMenuSlotClick(player, event.getSlot(), title);
            return;
        }

        // Main clan menus
        menuManager.handleMainMenuSlotClick(player, event.getSlot(), title);
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!menuManager.isInStorageVault(player.getUniqueId())) {
            String title = plainTitle(event.getView().title());
            if (isNovaMenu(title)) event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (menuManager.isInStorageVault(player.getUniqueId())) {
            menuManager.saveVaultAndClose(player, event.getInventory());
        } else {
            menuManager.removeFromStorageTracking(player.getUniqueId());
        }
    }

    private boolean isNovaMenu(String title) {
        return title.contains("NovaClans") || title.contains("Клан Қоймасы")
                || title.contains("Клан Топ") || title.contains("Мүшелер")
                || title.contains("Квесттер") || title.contains("Мәзір")
                || title.contains("Топ-10") || title.contains("Клан");
    }

    private boolean isMembersMenu(String title) {
        return title.contains("Мүшелер");
    }

    private boolean isTopMenu(String title) {
        return title.contains("Топ-10") || (title.contains("Клан Топ") && !title.contains("Клан —") && !title.contains("Клан Қоймасы"));
    }

    private boolean isQuestMenu(String title) {
        return title.contains("Квесттер");
    }

    private String plainTitle(net.kyori.adventure.text.Component comp) {
        try { return PlainTextComponentSerializer.plainText().serialize(comp); }
        catch (Exception e) { return ""; }
    }
}
