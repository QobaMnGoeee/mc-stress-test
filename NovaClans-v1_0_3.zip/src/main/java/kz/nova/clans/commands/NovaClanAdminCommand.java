package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.DataManager;
import kz.nova.clans.managers.MessageManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /novaclans admin command.
 * Permission: novaclans.admin (default: op)
 *
 * Sub-commands:
 *   reload                        — reload all configs
 *   storage <clan>                — open a clan's vault (player only)
 *   rename  <old name> <new name> — rename a clan
 *   delete  <clan>                — force-delete a clan
 *   levelup <1-5> <clan>          — set a clan's level
 */
public class NovaClanAdminCommand implements CommandExecutor, TabCompleter {

    private static final String PREFIX = "&8[&eᴄʟᴀɴ&8] &r";

    private final NovaClans plugin;
    private final MessageManager msg;
    private final ClanManager cm;
    private final DataManager dm;

    public NovaClanAdminCommand(NovaClans plugin) {
        this.plugin = plugin;
        this.msg = plugin.getMessageManager();
        this.cm = plugin.getClanManager();
        this.dm = plugin.getDataManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) {
            msg.send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            sendAdminHelp(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload"  -> handleReload(sender);
            case "storage" -> handleStorage(sender, args);
            case "rename"  -> handleRename(sender, args);
            case "delete"  -> handleDelete(sender, args);
            case "levelup" -> handleLevelUp(sender, args);
            default        -> sendAdminHelp(sender);
        }
        return true;
    }

    // ─── Sub-commands ─────────────────────────────────────────────────────────

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        plugin.getMessageManager().reload();
        plugin.getMenuManager().reload();
        raw(sender, "&aКонфигурация қайта жүктелді!");
    }

    private void handleStorage(CommandSender sender, String[] args) {
        if (args.length < 2) {
            raw(sender, "&cҚолдану: &e/novaclans storage <клан аты>");
            return;
        }
        if (!(sender instanceof Player player)) {
            raw(sender, "&cБұл команданы тек ойыншы орындай алады.");
            return;
        }
        ClanData clan = dm.getClan(args[1]);
        if (clan == null) {
            raw(sender, "&cКлан табылмады: &e" + args[1]);
            return;
        }
        plugin.getMenuManager().openAdminVault(player, clan);
    }

    private void handleRename(CommandSender sender, String[] args) {
        if (args.length < 3) {
            raw(sender, "&cҚолдану: &e/novaclans rename <ескі ат> <жаңа ат>");
            return;
        }
        String oldName = args[1];
        String newName = args[2];
        ClanData clan = dm.getClan(oldName);
        if (clan == null) {
            raw(sender, "&cКлан табылмады: &e" + oldName);
            return;
        }
        if (dm.clanExists(newName)) {
            raw(sender, "&cБұл атаумен клан бар: &e" + newName);
            return;
        }
        dm.renameClan(clan, newName);
        raw(sender, "&aКлан &e" + oldName + " &a→ &e" + newName + " &aболып өзгертілді.");
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            raw(sender, "&cҚолдану: &e/novaclans delete <клан аты>");
            return;
        }
        ClanData clan = dm.getClan(args[1]);
        if (clan == null) {
            raw(sender, "&cКлан табылмады: &e" + args[1]);
            return;
        }
        dm.deleteClan(args[1]);
        raw(sender, "&aКлан &e" + args[1] + " &aөшірілді.");
    }

    private void handleLevelUp(CommandSender sender, String[] args) {
        if (args.length < 3) {
            raw(sender, "&cҚолдану: &e/novaclans levelup <1-5> <клан аты>");
            return;
        }
        int level;
        try {
            level = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            raw(sender, "&cДеңгей 1-5 аралығында болуы керек.");
            return;
        }
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (level < 1 || level > maxLevel) {
            raw(sender, "&cДеңгей 1-" + maxLevel + " аралығында болуы керек.");
            return;
        }
        ClanData clan = dm.getClan(args[2]);
        if (clan == null) {
            raw(sender, "&cКлан табылмады: &e" + args[2]);
            return;
        }
        clan.setLevel(level);
        dm.save();
        raw(sender, "&aКлан &e" + args[2] + " &aдеңгейі &b" + level + " &aболып өзгерді.");
    }

    private void sendAdminHelp(CommandSender sender) {
        msg.sendRaw(sender, PREFIX + "&eAdmin командалары:");
        msg.sendRaw(sender, PREFIX + "&e/novaclans reload &7— Конфигурацияны қайта жүктеу");
        msg.sendRaw(sender, PREFIX + "&e/novaclans storage &b<клан> &7— Клан қоймасын ашу");
        msg.sendRaw(sender, PREFIX + "&e/novaclans rename &b<ескі> <жаңа> &7— Клан атын өзгерту");
        msg.sendRaw(sender, PREFIX + "&e/novaclans delete &b<клан> &7— Кланды өшіру");
        msg.sendRaw(sender, PREFIX + "&e/novaclans levelup &b<1-5> <клан> &7— Клан деңгейін орнату");
    }

    // Shortcut: send a raw message with the plugin prefix
    private void raw(CommandSender sender, String text) {
        msg.sendRaw(sender, PREFIX + text);
    }

    // ─── Tab completion ───────────────────────────────────────────────────────

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) return List.of();

        if (args.length == 1) {
            return Arrays.asList("reload", "storage", "rename", "delete", "levelup");
        }

        // Arg 2 position
        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "storage", "rename", "delete" ->
                        dm.getAllClans().stream().map(ClanData::getName).collect(Collectors.toList());
                case "levelup" ->
                        Arrays.asList("1", "2", "3", "4", "5");
                default -> List.of();
            };
        }

        // Arg 3 position
        if (args.length == 3) {
            return switch (args[0].toLowerCase()) {
                case "rename", "levelup" ->
                        dm.getAllClans().stream().map(ClanData::getName).collect(Collectors.toList());
                default -> List.of();
            };
        }

        return List.of();
    }
}
