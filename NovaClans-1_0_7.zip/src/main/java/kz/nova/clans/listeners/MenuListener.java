package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.managers.MenuManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public class MenuListener implements Listener {
    private final NovaClans plugin;
    private final MenuManager menuManager;

    public MenuListener(NovaClans plugin) {
        this.plugin = plugin;
        this.menuManager = plugin.getMenuManager();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity whoClicked = event.getWhoClicked();
        if (!(whoClicked instanceof Player player)) return;
        String title = plainTitle(event.getView().title());
        boolean inVault = menuManager.isInStorageVault(player.getUniqueId());
        boolean inStorageInfo = menuManager.isInStorageInfo(player.getUniqueId());
        if (inVault) return;
        if (!isNovaMenu(title)) return;
        event.setCancelled(true);
        if (event.getCurrentItem() == null) return;
        if (inStorageInfo) {
            menuManager.handleStorageInfoSlotClick(player, event.getSlot());
            return;
        }
        if (isMembersMenu(title) || isTopMenu(title) || isQuestMenu(title)) {
            menuManager.handleSubMenuSlotClick(player, event.getSlot(), title);
            return;
        }
        menuManager.handleMainMenuSlotClick(player, event.getSlot(), title);
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        HumanEntity whoClicked = event.getWhoClicked();
        if (whoClicked instanceof Player player) {
            if (!menuManager.isInStorageVault(player.getUniqueId())) {
                String title = plainTitle(event.getView().title());
                if (isNovaMenu(title)) {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        HumanEntity humanEntity = event.getPlayer();
        if (humanEntity instanceof Player player) {
            if (menuManager.isInStorageVault(player.getUniqueId())) {
                menuManager.saveVaultAndClose(player, event.getInventory());
            } else {
                menuManager.removeFromStorageTracking(player.getUniqueId());
            }
        }
    }

    private boolean isNovaMenu(String title) {
        return title.contains("NovaClans")
                || title.contains("\u041a\u043b\u0430\u043d \u049a\u043e\u0439\u043c\u0430\u0441\u044b")
                || title.contains("\u041a\u043b\u0430\u043d \u0422\u043e\u043f")
                || title.contains("\u041c\u04af\u0448\u0435\u043b\u0435\u0440")
                || title.contains("\u041a\u0432\u0435\u0441\u0442\u0442\u0435\u0440")
                || title.contains("\u041c\u04d9\u0437\u0456\u0440")
                || title.contains("\u0422\u043e\u043f-10")
                || title.contains("\u041a\u043b\u0430\u043d");
    }

    private boolean isMembersMenu(String title) {
        return title.contains("\u041c\u04af\u0448\u0435\u043b\u0435\u0440");
    }

    private boolean isTopMenu(String title) {
        return title.contains("\u0422\u043e\u043f-10")
                || (title.contains("\u041a\u043b\u0430\u043d \u0422\u043e\u043f")
                && !title.contains("\u041a\u043b\u0430\u043d \u2014")
                && !title.contains("\u041a\u043b\u0430\u043d \u049a\u043e\u0439\u043c\u0430\u0441\u044b"));
    }

    private boolean isQuestMenu(String title) {
        return title.contains("\u041a\u0432\u0435\u0441\u0442\u0442\u0435\u0440");
    }

    private String plainTitle(Component comp) {
        try {
            return PlainTextComponentSerializer.plainText().serialize(comp);
        } catch (Exception e) {
            return "";
        }
    }
}
