package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.List;

public class MessageManager {
    private final NovaClans plugin;
    private YamlConfiguration messages;
    private static final String PREFIX = "&8[&e\u1d04\u029f\u1d00\u0274&8] &r";
    private static final MiniMessage MM = MiniMessage.miniMessage();

    public MessageManager(NovaClans plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(file);
    }

    public String getPrefix() {
        return PREFIX;
    }

    public String getRaw(String key) {
        String val = messages.getString(key);
        if (val == null) {
            return "&c[NovaClans] Missing message: " + key;
        }
        return val;
    }

    public String get(String key, Object... replacements) {
        String msg = getRaw(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace(String.valueOf(replacements[i]), String.valueOf(replacements[i + 1]));
        }
        return PREFIX + msg;
    }

    public List<String> getList(String key) {
        return messages.getStringList(key);
    }

    public void send(CommandSender sender, String key, Object... replacements) {
        sender.sendMessage(parse(get(key, replacements)));
    }

    public void sendRaw(CommandSender sender, String msg) {
        sender.sendMessage(parse(msg));
    }

    public void sendList(CommandSender sender, String key) {
        List<String> lines = getList(key);
        if (lines.isEmpty()) {
            String single = getRaw(key);
            if (!single.startsWith("&c[NovaClans]")) {
                sender.sendMessage(parse(PREFIX + single));
            }
            return;
        }
        for (String line : lines) {
            try {
                sender.sendMessage(parse(line));
            } catch (Exception e) {
                sender.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(line));
            }
        }
    }

    public void broadcast(String key, Object... replacements) {
        List<String> lines = messages.getStringList(key);
        for (String line : lines) {
            for (int i = 0; i + 1 < replacements.length; i += 2) {
                line = line.replace(String.valueOf(replacements[i]), String.valueOf(replacements[i + 1]));
            }
            String finalLine = line;
            Bukkit.getOnlinePlayers().forEach(p -> {
                try {
                    p.sendMessage(parse(finalLine));
                } catch (Exception ignored) {}
            });
            try {
                Bukkit.getConsoleSender().sendMessage(parse(finalLine));
            } catch (Exception ignored) {}
        }
    }

    public static Component parse(String text) {
        if (text == null || text.isEmpty()) {
            return Component.empty();
        }
        String converted = legacyToMiniMessage(text);
        try {
            return MM.deserialize(converted);
        } catch (Exception e) {
            try {
                return LegacyComponentSerializer.legacyAmpersand().deserialize(text);
            } catch (Exception e2) {
                return Component.text(text);
            }
        }
    }

    private static String legacyToMiniMessage(String text) {
        if (text == null) return "";
        StringBuilder sb = new StringBuilder();
        int len = text.length();
        int i = 0;
        while (i < len) {
            char c = text.charAt(i);
            if (c == '<') {
                int end = text.indexOf('>', i);
                if (end != -1) {
                    String tag = text.substring(i, end + 1);
                    if (!tag.contains(" ") || tag.startsWith("<gradient") || tag.startsWith("</#") || tag.startsWith("<#")) {
                        sb.append(tag);
                        i = end + 1;
                        continue;
                    }
                }
            }
            if ((c == '&' || c == '\u00a7') && i + 1 < len) {
                char code = Character.toLowerCase(text.charAt(i + 1));
                if (code == 'x' && i + 13 < len) {
                    StringBuilder hex = new StringBuilder("<#");
                    boolean validHex = true;
                    for (int j = 0; j < 6; j++) {
                        int pos = i + 2 + j * 2;
                        if (pos + 1 >= len) { validHex = false; break; }
                        char amp = text.charAt(pos);
                        char digit = text.charAt(pos + 1);
                        if (amp != '&' && amp != '\u00a7') { validHex = false; break; }
                        if (!isHexDigit(digit)) { validHex = false; break; }
                        hex.append(digit);
                    }
                    if (validHex) {
                        hex.append('>');
                        sb.append(hex);
                        i += 14;
                        continue;
                    }
                }
                String mm = legacyCodeToMM(code);
                if (mm != null) {
                    sb.append(mm);
                    i += 2;
                    continue;
                }
            }
            sb.append(c);
            i++;
        }
        return sb.toString();
    }

    private static boolean isHexDigit(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }

    private static String legacyCodeToMM(char code) {
        return switch (code) {
            case '0' -> "<black>";
            case '1' -> "<dark_blue>";
            case '2' -> "<dark_green>";
            case '3' -> "<dark_aqua>";
            case '4' -> "<dark_red>";
            case '5' -> "<dark_purple>";
            case '6' -> "<gold>";
            case '7' -> "<gray>";
            case '8' -> "<dark_gray>";
            case '9' -> "<blue>";
            case 'a' -> "<green>";
            case 'b' -> "<aqua>";
            case 'c' -> "<red>";
            case 'd' -> "<light_purple>";
            case 'e' -> "<yellow>";
            case 'f' -> "<white>";
            case 'l' -> "<bold>";
            case 'm' -> "<strikethrough>";
            case 'n' -> "<underlined>";
            case 'o' -> "<italic>";
            case 'r' -> "<reset>";
            default -> null;
        };
    }

    public static Component component(String text) {
        return parse(text);
    }
}
