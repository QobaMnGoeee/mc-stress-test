package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;

import java.io.*;
import java.util.*;
import java.util.logging.Level;

public class DataManager {
    private final NovaClans plugin;
    private File dataFile;
    private YamlConfiguration dataConfig;
    private final Map<String, ClanData> clans;
    private final Map<UUID, String> playerClanMap;
    private File storageFile;
    private YamlConfiguration storageConfig;

    public DataManager(NovaClans plugin) {
        this.clans = new LinkedHashMap<>();
        this.playerClanMap = new HashMap<>();
        this.plugin = plugin;
        load();
    }

    public void load() {
        dataFile = new File(plugin.getDataFolder(), "novaClans.yml");
        storageFile = new File(plugin.getDataFolder(), "storage_data.yml");

        if (!dataFile.exists()) {
            plugin.saveResource("novaClans.yml", false);
        }

        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        if (!storageFile.exists()) {
            storageConfig = new YamlConfiguration();
        } else {
            storageConfig = YamlConfiguration.loadConfiguration(storageFile);
        }

        clans.clear();
        playerClanMap.clear();

        boolean pvpDefault = plugin.getConfig().getBoolean("pvp-enabled-by-default", true);

        ConfigurationSection clansSection = dataConfig.getConfigurationSection("clans");
        if (clansSection == null) {
            plugin.getLogger().info("Loaded 0 clans from novaClans.yml");
            return;
        }

        for (String clanName : clansSection.getKeys(false)) {
            ConfigurationSection cs = clansSection.getConfigurationSection(clanName);
            if (cs == null) continue;

            String leaderStr = cs.getString("leader", "");
            UUID leaderUUID;
            try {
                leaderUUID = UUID.fromString(leaderStr);
            } catch (IllegalArgumentException e) {
                continue;
            }

            ClanData clan = new ClanData(clanName, leaderUUID, pvpDefault);
            clan.setLevel(cs.getInt("level", 1));
            clan.setPoints(cs.getLong("points", 0L));
            clan.setBalance(cs.getDouble("balance", 0.0));
            clan.setCreatedAt(cs.getLong("created", System.currentTimeMillis()));
            clan.setPvpEnabled(cs.getBoolean("pvp-enabled", pvpDefault));

            ConfigurationSection membersSection = cs.getConfigurationSection("members");
            if (membersSection != null) {
                for (String uuidStr : membersSection.getKeys(false)) {
                    try {
                        UUID uuid = UUID.fromString(uuidStr);
                        ConfigurationSection ms = membersSection.getConfigurationSection(uuidStr);
                        if (ms == null) continue;
                        String memberName = ms.getString("name", "Unknown");
                        ClanRole role = ClanRole.fromString(ms.getString("role", "MEMBER"));
                        if (role == null) role = ClanRole.MEMBER;
                        ClanMember member = new ClanMember(uuid, memberName, role);
                        member.setJoinedAt(ms.getLong("joined", System.currentTimeMillis()));
                        clan.getMembers().put(uuid, member);
                        playerClanMap.put(uuid, clanName);
                    } catch (IllegalArgumentException ignored) {}
                }
            }

            String storageData = storageConfig.getString("storage." + clanName, null);
            if (storageData != null && !storageData.isEmpty()) {
                try {
                    clan.setStorageContents(itemStackArrayFromBase64(storageData));
                } catch (IOException e) {
                    plugin.getLogger().log(Level.WARNING, "Could not load storage for clan " + clanName, e);
                }
            }

            clans.put(clanName.toLowerCase(), clan);
        }

        plugin.getLogger().info("Loaded " + clans.size() + " clans from novaClans.yml");
    }

    public void save() {
        dataConfig.set("clans", null);
        for (Map.Entry<String, ClanData> entry : clans.entrySet()) {
            ClanData clan = entry.getValue();
            String path = "clans." + clan.getName();
            dataConfig.set(path + ".leader", clan.getLeader().toString());
            dataConfig.set(path + ".level", clan.getLevel());
            dataConfig.set(path + ".points", clan.getPoints());
            dataConfig.set(path + ".balance", clan.getBalance());
            dataConfig.set(path + ".created", clan.getCreatedAt());
            dataConfig.set(path + ".pvp-enabled", clan.isPvpEnabled());
            for (Map.Entry<UUID, ClanMember> mEntry : clan.getMembers().entrySet()) {
                ClanMember m = mEntry.getValue();
                String mp = path + ".members." + mEntry.getKey().toString();
                dataConfig.set(mp + ".name", m.getName());
                dataConfig.set(mp + ".role", m.getRole().name());
                dataConfig.set(mp + ".joined", m.getJoinedAt());
            }
        }
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save novaClans.yml", e);
        }

        storageConfig.set("storage", null);
        for (Map.Entry<String, ClanData> entry : clans.entrySet()) {
            ClanData clan = entry.getValue();
            if (clan.getStorageContents() != null) {
                try {
                    storageConfig.set("storage." + clan.getName(), itemStackArrayToBase64(clan.getStorageContents()));
                } catch (IllegalStateException e) {
                    plugin.getLogger().log(Level.WARNING, "Could not save storage for clan " + clan.getName(), e);
                }
            }
        }
        try {
            storageConfig.save(storageFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save storage_data.yml", e);
        }
    }

    public boolean clanExists(String name) {
        return clans.containsKey(name.toLowerCase());
    }

    public ClanData getClan(String name) {
        return clans.get(name.toLowerCase());
    }

    public ClanData getClanByPlayer(UUID uuid) {
        String clanName = playerClanMap.get(uuid);
        if (clanName == null) return null;
        return clans.get(clanName.toLowerCase());
    }

    public boolean isInClan(UUID uuid) {
        return playerClanMap.containsKey(uuid);
    }

    public void createClan(ClanData clan) {
        clans.put(clan.getName().toLowerCase(), clan);
        playerClanMap.put(clan.getLeader(), clan.getName());
        save();
    }

    public void deleteClan(String name) {
        ClanData clan = clans.remove(name.toLowerCase());
        if (clan != null) {
            for (UUID uuid : clan.getMembers().keySet()) {
                playerClanMap.remove(uuid);
            }
        }
        save();
    }

    public void renameClan(ClanData clan, String newName) {
        String oldName = clan.getName().toLowerCase();
        clans.remove(oldName);
        for (UUID uuid : clan.getMembers().keySet()) {
            playerClanMap.put(uuid, newName);
        }
        clan.setName(newName);
        clans.put(newName.toLowerCase(), clan);
        save();
    }

    public void addPlayerToClan(UUID uuid, ClanData clan, ClanRole role, String playerName) {
        clan.addMember(uuid, playerName, role);
        playerClanMap.put(uuid, clan.getName());
        save();
    }

    public void removePlayerFromClan(UUID uuid, ClanData clan) {
        clan.removeMember(uuid);
        playerClanMap.remove(uuid);
        save();
    }

    public Collection<ClanData> getAllClans() {
        return clans.values();
    }

    public List<ClanData> getTopClans(int limit) {
        return clans.values().stream()
                .sorted(Comparator.comparingLong(ClanData::getPoints).reversed())
                .limit(limit)
                .toList();
    }

    public static String itemStackArrayToBase64(ItemStack[] items) {
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            BukkitObjectOutputStream dataOutput = new BukkitObjectOutputStream(outputStream);
            dataOutput.writeInt(items.length);
            for (ItemStack item : items) {
                dataOutput.writeObject(item);
            }
            dataOutput.close();
            return Base64Coder.encodeLines(outputStream.toByteArray());
        } catch (Exception e) {
            throw new IllegalStateException("Unable to save item stacks.", e);
        }
    }

    public static ItemStack[] itemStackArrayFromBase64(String data) throws IOException {
        try {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(Base64Coder.decodeLines(data));
            BukkitObjectInputStream dataInput = new BukkitObjectInputStream(inputStream);
            ItemStack[] items = new ItemStack[dataInput.readInt()];
            for (int i = 0; i < items.length; i++) {
                items[i] = (ItemStack) dataInput.readObject();
            }
            dataInput.close();
            return items;
        } catch (ClassNotFoundException e) {
            throw new IOException("Unable to decode class type.", e);
        }
    }
}
