package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.managers.DataManager;
import kz.nova.clans.managers.MenuManager;
import kz.nova.clans.managers.MessageManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NovaClanAdminCommand implements CommandExecutor, TabCompleter {

    private static final String PREFIX = "&8[&eNovaClans&8] &r";
    private final NovaClans plugin;
    private final MessageManager messageManager;
    private final DataManager dataManager;
    private final MenuManager menuManager;

    public NovaClanAdminCommand(NovaClans plugin) {
        this.plugin = plugin;
        this.messageManager = plugin.getMessageManager();
        this.dataManager = plugin.getDataManager();
        this.menuManager = plugin.getMenuManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) {
            messageManager.send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            sendAdminHelp(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> handleReload(sender);
            case "storage" -> handleStorage(sender, args);
            case "rename" -> handleRename(sender, args);
            case "delete" -> handleDelete(sender, args);
            case "levelup" -> handleLevelUp(sender, args);
            default -> sendAdminHelp(sender);
        }
        return true;
    }

    private void sendAdminHelp(CommandSender sender) {
        messageManager.sendRaw(sender, PREFIX + "Admin Commands:");
        messageManager.sendRaw(sender, PREFIX + "/novaclans reload");
        messageManager.sendRaw(sender, PREFIX + "/novaclans storage <clan>");
        messageManager.sendRaw(sender, PREFIX + "/novaclans rename <clan> <newname>");
        messageManager.sendRaw(sender, PREFIX + "/novaclans delete <clan>");
        messageManager.sendRaw(sender, PREFIX + "/novaclans levelup <1-5> <clan>");
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        plugin.getMessageManager().reload();
        plugin.getMenuManager().reload();
        messageManager.sendRaw(sender, PREFIX + "Config reloaded.");
    }

    private void handleStorage(CommandSender sender, String[] args) {
        if (args.length < 2) {
            messageManager.sendRaw(sender, ": &e/novaclans storage <clan>");
            return;
        }
        if (!(sender instanceof Player player)) {
            messageManager.send(sender, "player-only");
            return;
        }
        ClanData clan = dataManager.getClan(args[1]);
        if (clan == null) {
            messageManager.sendRaw(player, PREFIX + "Clan not found: " + args[1]);
            return;
        }
        menuManager.openAdminVault(player, clan);
    }

    private void handleRename(CommandSender sender, String[] args) {
        if (args.length < 3) {
            messageManager.sendRaw(sender, ": &e/novaclans rename <clan> <newname>");
            return;
        }
        ClanData clan = dataManager.getClan(args[1]);
        if (clan == null) {
            messageManager.sendRaw(sender, PREFIX + "Clan not found: " + args[1]);
            return;
        }
        String oldName = clan.getName();
        String newName = args[2];
        if (dataManager.clanExists(newName)) {
            messageManager.sendRaw(sender, PREFIX + "Clan already exists: " + newName);
            return;
        }
        dataManager.renameClan(clan, newName);
        dataManager.save();
        messageManager.sendRaw(sender, PREFIX + "Renamed " + oldName + " to " + newName);
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            messageManager.sendRaw(sender, ": &e/novaclans delete <clan>");
            return;
        }
        if (!dataManager.clanExists(args[1])) {
            messageManager.sendRaw(sender, PREFIX + "Clan not found: " + args[1]);
            return;
        }
        dataManager.deleteClan(args[1]);
        dataManager.save();
        messageManager.sendRaw(sender, PREFIX + "Deleted clan: " + args[1]);
    }

    private void handleLevelUp(CommandSender sender, String[] args) {
        if (args.length < 3) {
            messageManager.sendRaw(sender, ": &e/novaclans levelup <1-5> <clan>");
            return;
        }
        int level;
        try {
            level = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            messageManager.sendRaw(sender, PREFIX + "Invalid level. Use 1-5.");
            return;
        }
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (level < 1 || level > maxLevel) {
            messageManager.sendRaw(sender, PREFIX + "Level must be 1-" + maxLevel);
            return;
        }
        ClanData clan = dataManager.getClan(args[2]);
        if (clan == null) {
            messageManager.sendRaw(sender, PREFIX + "Clan not found: " + args[2]);
            return;
        }
        clan.setLevel(level);
        dataManager.save();
        messageManager.sendRaw(sender, PREFIX + "Set " + clan.getName() + " level to " + level);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) return List.of();
        if (args.length == 1) {
            return Arrays.asList("reload", "storage", "rename", "delete", "levelup")
                    .stream().filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("storage")
                || args[0].equalsIgnoreCase("rename")
                || args[0].equalsIgnoreCase("delete"))) {
            return dataManager.getAllClans().stream()
                    .map(ClanData::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("levelup")) {
            return Arrays.asList("1", "2", "3", "4", "5");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("levelup")) {
            return dataManager.getAllClans().stream()
                    .map(ClanData::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[2].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("rename")) {
            return List.of("<newname>");
        }
        return List.of();
    }
}
