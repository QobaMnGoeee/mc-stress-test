package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanRole;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.MessageManager;
import kz.nova.clans.managers.MenuManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ClanCommand implements CommandExecutor, TabCompleter {

    private final NovaClans plugin;
    private final ClanManager clanManager;
    private final MessageManager messageManager;
    private final MenuManager menuManager;

    public ClanCommand(NovaClans plugin) {
        this.plugin = plugin;
        this.clanManager = plugin.getClanManager();
        this.messageManager = plugin.getMessageManager();
        this.menuManager = plugin.getMenuManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            messageManager.send(sender, "player-only");
            return true;
        }

        if (args.length == 0) {
            menuManager.openMainMenu(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "help" -> handleHelp(player);
            case "create" -> handleCreate(player, args);
            case "delete" -> clanManager.deleteClan(player);
            case "invite" -> handleInvite(player, args);
            case "accept" -> clanManager.acceptInvite(player);
            case "deny" -> clanManager.denyInvite(player);
            case "kick" -> handleKick(player, args);
            case "promote" -> handlePromote(player, args);
            case "role" -> handleRole(player, args);
            case "chat" -> clanManager.toggleClanChat(player);
            case "pvp" -> clanManager.togglePvp(player);
            case "storage" -> handleStorage(player, args);
            case "quest" -> menuManager.openQuestMenu(player);
            case "top" -> menuManager.openTopMenu(player);
            default -> messageManager.send(player, "invalid-usage");
        }
        return true;
    }

    private void handleHelp(Player player) {
        messageManager.sendList(player, "clan-help");
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            messageManager.sendRaw(player, ": &e/clan create <name>");
            return;
        }
        clanManager.createClan(player, args[1]);
    }

    private void handleInvite(Player player, String[] args) {
        if (args.length < 2) {
            messageManager.sendRaw(player, ": &e/clan invite <player>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            messageManager.send(player, "player-not-found", "{player}", args[1]);
            return;
        }
        clanManager.invitePlayer(player, target);
    }

    private void handleKick(Player player, String[] args) {
        if (args.length < 2) {
            messageManager.sendRaw(player, ": &e/clan kick <player>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            messageManager.send(player, "player-not-found", "{player}", args[1]);
            return;
        }
        clanManager.kickPlayer(player, target);
    }

    private void handlePromote(Player player, String[] args) {
        if (args.length < 2) {
            messageManager.sendRaw(player, ": &e/clan promote <player>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            messageManager.send(player, "player-not-found", "{player}", args[1]);
            return;
        }
        clanManager.promoteMember(player, target);
    }

    private void handleRole(Player player, String[] args) {
        if (args.length < 3) {
            messageManager.sendRaw(player, ": &e/clan role <player> <MEMBER|DEPUTY>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            messageManager.send(player, "player-not-found", "{player}", args[1]);
            return;
        }
        ClanRole role = ClanRole.fromString(args[2]);
        if (role == ClanRole.LEADER) {
            messageManager.send(player, "clan-role-invalid");
            return;
        }
        clanManager.setRole(player, target, role);
    }

    private void handleStorage(Player player, String[] args) {
        if (args.length < 2) {
            menuManager.openStorageInfoMenu(player);
            return;
        }
        switch (args[1].toLowerCase()) {
            case "add" -> {
                if (args.length < 3) {
                    messageManager.sendRaw(player, ": &e/clan storage add <amount>");
                    return;
                }
                try {
                    double amount = Double.parseDouble(args[2]);
                    clanManager.depositToStorage(player, amount);
                } catch (NumberFormatException e) {
                    messageManager.send(player, "clan-storage-invalid-amount");
                }
            }
            case "take" -> {
                if (args.length < 3) {
                    messageManager.sendRaw(player, ": &e/clan storage take <amount>");
                    return;
                }
                try {
                    double amount = Double.parseDouble(args[2]);
                    clanManager.withdrawFromStorage(player, amount);
                } catch (NumberFormatException e) {
                    messageManager.send(player, "clan-storage-invalid-amount");
                }
            }
            default -> menuManager.openStorageInfoMenu(player);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player)) return List.of();
        if (args.length == 1) {
            return Arrays.asList("help", "create", "delete", "invite", "accept", "deny",
                    "kick", "promote", "role", "chat", "pvp", "storage", "quest", "top")
                    .stream().filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("invite")
                || args[0].equalsIgnoreCase("kick")
                || args[0].equalsIgnoreCase("promote")
                || args[0].equalsIgnoreCase("role"))) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("role")) {
            return Arrays.asList("MEMBER", "DEPUTY").stream()
                    .filter(s -> s.startsWith(args[2].toUpperCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("storage")) {
            return Arrays.asList("add", "take").stream()
                    .filter(s -> s.startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return List.of();
    }
}
