package kz.nova.clans.data;

public enum ClanRole {

    MEMBER("MEMBER", 0),
    DEPUTY("DEPUTY", 1),
    LEADER("LEADER", 2);

    private final String displayName;
    private final int level;

    ClanRole(String displayName, int level) {
        this.displayName = displayName;
        this.level = level;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean isAtLeast(ClanRole role) {
        return this.level >= role.level;
    }

    public static ClanRole fromString(String str) {
        if (str == null) return MEMBER;
        switch (str.toUpperCase()) {
            case "DEPUTY": return DEPUTY;
            case "LEADER": return LEADER;
            default: return MEMBER;
        }
    }
}
