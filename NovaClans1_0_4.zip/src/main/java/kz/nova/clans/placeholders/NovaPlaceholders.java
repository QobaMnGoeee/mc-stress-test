package kz.nova.clans.placeholders;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanRole;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class NovaPlaceholders extends PlaceholderExpansion {

    private final NovaClans plugin;

    public NovaPlaceholders(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() { return "nova"; }

    @Override
    public @NotNull String getAuthor() { return "NovaNetwork"; }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() { return true; }

    @Override
    public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";
        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) return "";
        switch (params) {
            case "clan_name" -> { return clan.getName(); }
            case "clan_level" -> { return String.valueOf(clan.getLevel()); }
            case "clan_points" -> { return String.valueOf(clan.getPoints()); }
            case "clan_balance" -> { return plugin.getClanManager().formatMoney(clan.getBalance()); }
            case "clan_role" -> {
                ClanRole role = clan.getMemberRole(player.getUniqueId());
                return role != null ? role.getDisplayName() : "";
            }
            case "clan_members" -> { return String.valueOf(clan.getMemberCount()); }
            default -> { return null; }
        }
    }
}
