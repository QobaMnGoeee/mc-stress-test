package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class PvpListener implements Listener {

    private final NovaClans plugin;

    public PvpListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (plugin.getClanManager().isClanPvpBlocked(attacker, victim)) {
            event.setCancelled(true);
            plugin.getMessageManager().send(attacker, "clan-pvp-blocked");
        }
    }
}
