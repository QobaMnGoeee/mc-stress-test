package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {

    private final NovaClans plugin;

    public ChatListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getClanManager().isClanChatToggled(player.getUniqueId())) {
            ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
            if (clan != null) {
                String clanTag = "[" + clan.getName() + "] ";
                event.setFormat(clanTag + event.getFormat());
            }
            return;
        }
        event.setCancelled(true);
        plugin.getClanManager().sendClanChat(player, event.getMessage());
    }
}
