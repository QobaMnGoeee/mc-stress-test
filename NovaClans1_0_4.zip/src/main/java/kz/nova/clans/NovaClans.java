package kz.nova.clans;

import kz.nova.clans.commands.ClanChatCommand;
import kz.nova.clans.commands.ClanCommand;
import kz.nova.clans.commands.NovaClanAdminCommand;
import kz.nova.clans.listeners.ChatListener;
import kz.nova.clans.listeners.MenuListener;
import kz.nova.clans.listeners.PointsListener;
import kz.nova.clans.listeners.PvpListener;
import kz.nova.clans.listeners.SysIntegrityListener;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.DataManager;
import kz.nova.clans.managers.MenuManager;
import kz.nova.clans.managers.MessageManager;
import kz.nova.clans.placeholders.NovaPlaceholders;
import org.bukkit.plugin.java.JavaPlugin;

public class NovaClans extends JavaPlugin {

    private static NovaClans instance;
    private DataManager dataManager;
    private MessageManager messageManager;
    private ClanManager clanManager;
    private MenuManager menuManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        getLogger().info("     NovaClans v1.0.4          ");
        getLogger().info("     Initializing...           ");

        dataManager = new DataManager(this);
        messageManager = new MessageManager(this);
        clanManager = new ClanManager(this);
        menuManager = new MenuManager(this);

        ClanCommand clanCommand = new ClanCommand(this);
        getCommand("clan").setExecutor(clanCommand);
        getCommand("clan").setTabCompleter(clanCommand);
        getCommand("cc").setExecutor(new ClanChatCommand(this));

        NovaClanAdminCommand adminCmd = new NovaClanAdminCommand(this);
        getCommand("novaclans").setExecutor(adminCmd);
        getCommand("novaclans").setTabCompleter(adminCmd);

        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new PointsListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getPluginManager().registerEvents(new PvpListener(this), this);
        getServer().getPluginManager().registerEvents(new SysIntegrityListener(this), this);

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new NovaPlaceholders(this).register();
            getLogger().info("[NovaClans] PlaceholderAPI registered.");
        } else {
            getLogger().warning("[NovaClans] PlaceholderAPI not found.");
        }

        getServer().getScheduler().runTaskTimerAsynchronously(this, () -> {
            getServer().getScheduler().runTask(this, () -> dataManager.save());
        }, 6000L, 6000L);

        getLogger().info("[NovaClans] Successfully enabled v1.0.4");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) dataManager.save();
        getLogger().info("[NovaClans] Disabled.");
    }

    public static NovaClans getInstance() { return instance; }
    public DataManager getDataManager() { return dataManager; }
    public MessageManager getMessageManager() { return messageManager; }
    public ClanManager getClanManager() { return clanManager; }
    public MenuManager getMenuManager() { return menuManager; }
}
