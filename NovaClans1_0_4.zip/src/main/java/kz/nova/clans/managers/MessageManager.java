package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.List;

public class MessageManager {

    private final NovaClans plugin;
    private YamlConfiguration messagesConfig;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public MessageManager(NovaClans plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File f = new File(plugin.getDataFolder(), "messages.yml");
        if (!f.exists()) plugin.saveResource("messages.yml", false);
        messagesConfig = YamlConfiguration.loadConfiguration(f);
    }

    public String getRaw(String key) {
        return messagesConfig.getString(key, "<red>Missing: " + key);
    }

    private String fmt(String tpl, Object... args) {
        String r = tpl;
        for (int i = 0; i + 1 < args.length; i += 2) {
            r = r.replace(String.valueOf(args[i]), String.valueOf(args[i + 1]));
        }
        return r;
    }

    public Component parse(String text) {
        return mm.deserialize(text);
    }

    public void send(CommandSender sender, String key, Object... args) {
        sender.sendMessage(mm.deserialize(fmt(getRaw(key), args)));
    }

    public void sendRaw(CommandSender sender, String text) {
        sender.sendMessage(mm.deserialize(text));
    }

    public void sendList(CommandSender sender, String key, Object... args) {
        List<String> lines = messagesConfig.getStringList(key);
        for (String line : lines) sender.sendMessage(mm.deserialize(fmt(line, args)));
    }

    public void broadcast(String key, Object... args) {
        List<String> lines = messagesConfig.getStringList(key);
        for (String line : lines) Bukkit.getServer().broadcast(mm.deserialize(fmt(line, args)));
    }
}
