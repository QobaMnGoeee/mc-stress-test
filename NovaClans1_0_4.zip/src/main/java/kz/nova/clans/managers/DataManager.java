package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;

import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.stream.Collectors;

public class DataManager {

    private final Map<String, ClanData> clans;
    private final Map<UUID, String> playerClanMap;
    private final NovaClans plugin;

    public DataManager(NovaClans plugin) {
        this.plugin = plugin;
        this.clans = new LinkedHashMap<>();
        this.playerClanMap = new HashMap<>();
        load();
    }

    public void load() {
        File dataFile = new File(plugin.getDataFolder(), "novaClans.yml");
        File storageFile = new File(plugin.getDataFolder(), "storage_data.yml");
        if (!dataFile.exists()) plugin.saveResource("novaClans.yml", false);

        YamlConfiguration dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        YamlConfiguration storageConfig = YamlConfiguration.loadConfiguration(storageFile);

        clans.clear();
        playerClanMap.clear();

        ConfigurationSection clansSection = dataConfig.getConfigurationSection("clans");
        if (clansSection == null) return;

        for (String clanName : clansSection.getKeys(false)) {
            String path = "clans." + clanName;
            String leaderStr = dataConfig.getString(path + ".leader", "");
            UUID leaderUUID;
            try {
                leaderUUID = UUID.fromString(leaderStr);
            } catch (IllegalArgumentException e) {
                continue;
            }

            ClanData clan = new ClanData(clanName, leaderUUID);
            clan.setLevel(dataConfig.getInt(path + ".level", 1));
            clan.setPoints(dataConfig.getLong(path + ".points", 0));
            clan.setBalance(dataConfig.getDouble(path + ".balance", 0));
            clan.setCreatedAt(dataConfig.getLong(path + ".created", System.currentTimeMillis()));
            clan.setPvpEnabled(dataConfig.getBoolean(path + ".pvp-enabled",
                    plugin.getConfig().getBoolean("pvp-enabled-by-default", true)));

            ConfigurationSection membersSection = dataConfig.getConfigurationSection(path + ".members");
            if (membersSection != null) {
                for (String uuidStr : membersSection.getKeys(false)) {
                    try {
                        UUID uuid = UUID.fromString(uuidStr);
                        String mName = dataConfig.getString(path + ".members." + uuidStr + ".name", "Unknown");
                        String roleStr = dataConfig.getString(path + ".members." + uuidStr + ".role", "MEMBER");
                        ClanRole role = ClanRole.fromString(roleStr);
                        ClanMember member = new ClanMember(uuid, mName, role);
                        long joined = dataConfig.getLong(path + ".members." + uuidStr + ".joined", System.currentTimeMillis());
                        member.setJoinedAt(joined);
                        clan.getMembers().put(uuid, member);
                        playerClanMap.put(uuid, clanName.toLowerCase());
                    } catch (IllegalArgumentException ignored) {}
                }
            }

            clans.put(clanName.toLowerCase(), clan);

            String storageData = storageConfig.getString("storage." + clanName, null);
            if (storageData != null && !storageData.isEmpty()) {
                try {
                    clan.setStorageContents(itemStackArrayFromBase64(storageData));
                } catch (IOException e) {
                    plugin.getLogger().log(Level.WARNING, "Could not load storage for clan " + clanName, e);
                }
            }
        }

        plugin.getLogger().info("Loaded " + clans.size() + " clans from novaClans.yml");
    }

    public void save() {
        File dataFile = new File(plugin.getDataFolder(), "novaClans.yml");
        File storageFile = new File(plugin.getDataFolder(), "storage_data.yml");

        YamlConfiguration dataConfig = new YamlConfiguration();
        YamlConfiguration storageConfig = new YamlConfiguration();

        for (Map.Entry<String, ClanData> entry : clans.entrySet()) {
            ClanData clan = entry.getValue();
            String path = "clans." + clan.getName();

            dataConfig.set(path + ".leader", clan.getLeader().toString());
            dataConfig.set(path + ".level", clan.getLevel());
            dataConfig.set(path + ".points", clan.getPoints());
            dataConfig.set(path + ".balance", clan.getBalance());
            dataConfig.set(path + ".created", clan.getCreatedAt());
            dataConfig.set(path + ".pvp-enabled", clan.isPvpEnabled());

            for (Map.Entry<UUID, ClanMember> mEntry : clan.getMembers().entrySet()) {
                ClanMember member = mEntry.getValue();
                String mPath = path + ".members." + mEntry.getKey().toString();
                dataConfig.set(mPath + ".name", member.getName());
                dataConfig.set(mPath + ".role", member.getRole().name());
                dataConfig.set(mPath + ".joined", member.getJoinedAt());
            }

            ItemStack[] contents = clan.getStorageContents();
            if (contents != null) {
                try {
                    storageConfig.set("storage." + clan.getName(), itemStackArrayToBase64(contents));
                } catch (IllegalStateException e) {
                    plugin.getLogger().log(Level.SEVERE, "Could not save storage for clan " + clan.getName(), e);
                }
            }
        }

        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save novaClans.yml", e);
        }
        try {
            storageConfig.save(storageFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save storage_data.yml", e);
        }
    }

    public boolean clanExists(String name) { return clans.containsKey(name.toLowerCase()); }
    public ClanData getClan(String name) { return clans.get(name.toLowerCase()); }

    public ClanData getClanByPlayer(UUID uuid) {
        String clanName = playerClanMap.get(uuid);
        return clanName != null ? clans.get(clanName) : null;
    }

    public boolean isInClan(UUID uuid) { return playerClanMap.containsKey(uuid); }

    public void createClan(ClanData clan) {
        clans.put(clan.getName().toLowerCase(), clan);
        playerClanMap.put(clan.getLeader(), clan.getName().toLowerCase());
    }

    public void deleteClan(String name) {
        ClanData clan = clans.remove(name.toLowerCase());
        if (clan != null) new HashSet<>(clan.getMembers().keySet()).forEach(playerClanMap::remove);
    }

    public void renameClan(ClanData clan, String newName) {
        clans.remove(clan.getName().toLowerCase());
        clan.setName(newName);
        clans.put(newName.toLowerCase(), clan);
        for (UUID uuid : clan.getMembers().keySet()) {
            playerClanMap.put(uuid, newName.toLowerCase());
        }
    }

    public void addPlayerToClan(UUID uuid, ClanData clan, ClanRole role, String playerName) {
        clan.addMember(uuid, playerName, role);
        playerClanMap.put(uuid, clan.getName().toLowerCase());
    }

    public void removePlayerFromClan(UUID uuid, ClanData clan) {
        clan.removeMember(uuid);
        playerClanMap.remove(uuid);
    }

    public Collection<ClanData> getAllClans() { return clans.values(); }

    public List<ClanData> getTopClans(int limit) {
        return clans.values().stream()
                .sorted(Comparator.comparingLong(ClanData::getPoints).reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }

    public static String itemStackArrayToBase64(ItemStack[] items) throws IllegalStateException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            BukkitObjectOutputStream data = new BukkitObjectOutputStream(out);
            data.writeInt(items.length);
            for (ItemStack item : items) data.writeObject(item);
            data.close();
            return Base64Coder.encodeLines(out.toByteArray());
        } catch (Exception e) {
            throw new IllegalStateException("Unable to save item stacks.", e);
        }
    }

    public static ItemStack[] itemStackArrayFromBase64(String data) throws IOException {
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(Base64Coder.decodeLines(data));
            BukkitObjectInputStream dataIn = new BukkitObjectInputStream(in);
            ItemStack[] items = new ItemStack[dataIn.readInt()];
            for (int i = 0; i < items.length; i++) items[i] = (ItemStack) dataIn.readObject();
            dataIn.close();
            return items;
        } catch (ClassNotFoundException e) {
            throw new IOException("Unable to decode class type.", e);
        }
    }
}
