package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

public class MenuManager {

    private final Map<UUID, String> openStorageMenu;
    private final NovaClans plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();

    private YamlConfiguration clanMenuConfig;
    private YamlConfiguration storageMenuConfig;
    private YamlConfiguration membersMenuConfig;
    private YamlConfiguration topMenuConfig;
    private YamlConfiguration questMenuConfig;

    public MenuManager(NovaClans plugin) {
        this.plugin = plugin;
        this.openStorageMenu = new HashMap<>();
        reload();
    }

    public void reload() {
        File menuDir = new File(plugin.getDataFolder(), "menus");
        if (!menuDir.exists()) menuDir.mkdirs();

        File clanMenuFile = new File(menuDir, "clan_menu.yml");
        File storageMenuFile = new File(menuDir, "storage_menu.yml");
        File membersMenuFile = new File(menuDir, "members_menu.yml");
        File topMenuFile = new File(menuDir, "top_menu.yml");
        File questMenuFile = new File(menuDir, "quest_menu.yml");

        if (!clanMenuFile.exists()) plugin.saveResource("menus/clan_menu.yml", false);
        if (!storageMenuFile.exists()) plugin.saveResource("menus/storage_menu.yml", false);
        if (!membersMenuFile.exists()) plugin.saveResource("menus/members_menu.yml", false);
        if (!topMenuFile.exists()) plugin.saveResource("menus/top_menu.yml", false);
        if (!questMenuFile.exists()) plugin.saveResource("menus/quest_menu.yml", false);

        clanMenuConfig = YamlConfiguration.loadConfiguration(clanMenuFile);
        storageMenuConfig = YamlConfiguration.loadConfiguration(storageMenuFile);
        membersMenuConfig = YamlConfiguration.loadConfiguration(membersMenuFile);
        topMenuConfig = YamlConfiguration.loadConfiguration(topMenuFile);
        questMenuConfig = YamlConfiguration.loadConfiguration(questMenuFile);
    }

    public void openMainMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        if (!dm.isInClan(player.getUniqueId())) {
            openNoClanMenu(player);
            return;
        }
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        openClanMenu(player, clan);
    }

    private void openNoClanMenu(Player player) {
        ConfigurationSection cfg = clanMenuConfig.getConfigurationSection("no-clan-menu");
        if (cfg == null) return;
        int rows = cfg.getInt("rows", 3);
        String titleRaw = cfg.getString("title", "Clan Menu");
        Component title = parseTitle(titleRaw);
        Inventory inv = Bukkit.createInventory(null, rows * 9, title);
        fillItems(inv, cfg, player, null);
        player.openInventory(inv);
    }

    private void openClanMenu(Player player, ClanData clan) {
        ConfigurationSection cfg = clanMenuConfig.getConfigurationSection("clan-menu");
        if (cfg == null) return;
        int rows = cfg.getInt("rows", 4);
        String titleRaw = cfg.getString("title", "Clan Menu");
        Component title = parseTitle(applyPlaceholders(titleRaw, player, clan));
        Inventory inv = Bukkit.createInventory(null, rows * 9, title);
        fillItems(inv, cfg, player, clan);
        player.openInventory(inv);
    }

    public void openStorageInfoMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        if (!dm.isInClan(player.getUniqueId())) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return;
        }
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        ConfigurationSection cfg = storageMenuConfig.getConfigurationSection("storage-menu");
        if (cfg == null) return;
        int rows = cfg.getInt("rows", 3);
        String titleRaw = cfg.getString("title", "Storage");
        Component title = parseTitle(applyPlaceholders(titleRaw, player, clan));
        Inventory inv = Bukkit.createInventory(null, rows * 9, title);
        fillItems(inv, cfg, player, clan);
        openStorageMenu.put(player.getUniqueId(), clan.getName() + ":info");
        player.openInventory(inv);
    }

    public void openClanVault(Player player, ClanData clan) {
        int level = clan.getLevel();
        int size = plugin.getConfig().getInt("storage.level-" + level, 27);
        String titleStr = "<dark_gray>[<#ffc800>" + clan.getName() + "<dark_gray>] <#ffc800>Vault <gray>| <aqua>Lv." + level;
        Component title = mm.deserialize(titleStr);
        Inventory inv = Bukkit.createInventory(null, size, title);
        ItemStack[] contents = clan.getStorageContents();
        if (contents != null) {
            int copyLen = Math.min(contents.length, inv.getSize());
            for (int i = 0; i < copyLen; i++) {
                if (contents[i] != null) inv.setItem(i, contents[i]);
            }
        }
        openStorageMenu.put(player.getUniqueId(), clan.getName() + ":vault");
        player.openInventory(inv);
    }

    public void openAdminVault(Player player, ClanData clan) {
        openClanVault(player, clan);
    }

    public void saveVaultAndClose(Player player, Inventory inv) {
        String entry = openStorageMenu.remove(player.getUniqueId());
        if (entry == null || !entry.endsWith(":vault")) return;
        String clanName = entry.replace(":vault", "");
        ClanData clan = plugin.getDataManager().getClan(clanName);
        if (clan == null) return;
        clan.setStorageContents(inv.getContents());
        plugin.getDataManager().save();
    }

    public void removeFromStorageTracking(UUID uuid) {
        openStorageMenu.remove(uuid);
    }

    public boolean isInStorageVault(UUID uuid) {
        String v = openStorageMenu.get(uuid);
        return v != null && v.endsWith(":vault");
    }

    public boolean isInStorageInfo(UUID uuid) {
        String v = openStorageMenu.get(uuid);
        return v != null && v.endsWith(":info");
    }

    public boolean isNovaMenu(String title) {
        return title != null && title.contains("NovaClans");
    }

    public void openMembersMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        if (!dm.isInClan(player.getUniqueId())) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return;
        }
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        ConfigurationSection cfg = membersMenuConfig.getConfigurationSection("members-menu");
        if (cfg == null) return;
        int rows = cfg.getInt("rows", 6);
        String titleRaw = cfg.getString("title", "Members");
        Component title = parseTitle(applyPlaceholders(titleRaw, player, clan));
        Inventory inv = Bukkit.createInventory(null, rows * 9, title);

        List<Map.Entry<UUID, ClanMember>> entries = new ArrayList<>(clan.getMembers().entrySet());
        for (int i = 0; i < entries.size() && i < inv.getSize(); i++) {
            Map.Entry<UUID, ClanMember> e = entries.get(i);
            ClanMember member = e.getValue();
            ClanRole role = member.getRole();
            String roleColor = getRoleColorMM(role);
            String roleIcon = getRoleIcon(role);

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta != null) {
                meta.setOwningPlayer(Bukkit.getOfflinePlayer(e.getKey()));
                Player online = Bukkit.getPlayer(e.getKey());
                String onlineStr = online != null ? "<green>Online" : "<red>Offline";
                meta.displayName(mm.deserialize(roleColor + member.getName()));
                List<Component> lore = List.of(
                        mm.deserialize(roleColor + roleIcon + " " + role.getDisplayName()),
                        mm.deserialize(onlineStr)
                );
                meta.lore(lore);
                head.setItemMeta(meta);
            }
            inv.setItem(i, head);
        }
        player.openInventory(inv);
    }

    public void openTopMenu(Player player) {
        ConfigurationSection cfg = topMenuConfig.getConfigurationSection("top-menu");
        if (cfg == null) return;
        int rows = cfg.getInt("rows", 6);
        String titleRaw = cfg.getString("title", "Top Clans");
        Component title = parseTitle(titleRaw);
        Inventory inv = Bukkit.createInventory(null, rows * 9, title);

        Material[] medals = {Material.GOLD_INGOT, Material.IRON_INGOT, Material.COPPER_INGOT,
                Material.EMERALD, Material.DIAMOND, Material.AMETHYST_SHARD,
                Material.LAPIS_LAZULI, Material.REDSTONE, Material.QUARTZ, Material.COAL};

        List<ClanData> topClans = plugin.getDataManager().getTopClans(10);
        for (int i = 0; i < topClans.size(); i++) {
            ClanData clan = topClans.get(i);
            Material mat = i < medals.length ? medals[i] : Material.COAL;
            String name = "<gradient:#ffc800:#f2990a><bold>#" + (i + 1) + " " + clan.getName() + "</bold></gradient>";
            List<String> lore = Arrays.asList(
                    "<#ffc800>Деңгей: <#f0e173>" + clan.getLevel(),
                    "<#ffc800>Ұпай: <#f0e173>" + clan.getPoints(),
                    "<#ffc800>Мүшелер: <#f0e173>" + clan.getMemberCount(),
                    "<#ffc800>Қазына: <#f0e173>" + plugin.getClanManager().formatMoney(clan.getBalance())
            );
            inv.setItem(i * 2, buildItem(mat, name, lore, false));
        }
        player.openInventory(inv);
    }

    public void openQuestMenu(Player player) {
        DataManager dm = plugin.getDataManager();
        if (!dm.isInClan(player.getUniqueId())) {
            plugin.getMessageManager().send(player, "not-in-clan");
            return;
        }
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        ConfigurationSection cfg = questMenuConfig.getConfigurationSection("quest-menu");
        if (cfg == null) return;
        int rows = cfg.getInt("rows", 3);
        String titleRaw = cfg.getString("title", "Quests");
        Component title = parseTitle(applyPlaceholders(titleRaw, player, clan));
        Inventory inv = Bukkit.createInventory(null, rows * 9, title);

        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        long currentPoints = clan.getPoints();
        int currentLevel = clan.getLevel();

        long nextRequired = plugin.getConfig().getLong("levels." + (currentLevel + 1), 0);
        long prevRequired = plugin.getConfig().getLong("levels." + currentLevel, 0);

        String progressBar = buildProgressBar(currentPoints - prevRequired, nextRequired - prevRequired, 20);

        String killName = "<gradient:#ffc800:#f2990a><bold>Ойыншы өлтіру</bold></gradient>";
        List<String> killLore = Arrays.asList(
                "<#ffc800>Сыйақы: <#f0e173>+2 ұпай",
                "",
                "<#ffc800>Прогресс: <#f0e173>" + currentPoints + "<#ffc800> / <#f0e173>" + nextRequired,
                progressBar
        );
        inv.setItem(11, buildItem(Material.EXPERIENCE_BOTTLE, killName, killLore, false));

        String mobName = "<gradient:#ffc800:#f2990a><bold>Моб өлтіру</bold></gradient>";
        List<String> mobLore = Arrays.asList(
                "<#ffc800>Сыйақы: <#f0e173>+1 ұпай",
                "",
                "<#ffc800>Деңгей: <#f0e173>" + currentLevel + "<#ffc800> / <#f0e173>" + maxLevel
        );
        inv.setItem(13, buildItem(Material.EXPERIENCE_BOTTLE, mobName, mobLore, false));

        boolean maxed = currentLevel >= maxLevel;
        Material statusMat = maxed ? Material.LIME_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE;
        String statusColor = maxed ? "<green>" : "<red>";
        String statusText = statusColor + (maxed ? "MAX LEVEL!" : "Жоғарылату үшін ұпай жина");
        inv.setItem(15, buildItem(statusMat, statusText, Collections.emptyList(), false));

        player.openInventory(inv);
    }

    private String buildProgressBar(long current, long max, int length) {
        if (max <= 0) return "<green>" + "█".repeat(length);
        double ratio = Math.min(1.0, (double) current / max);
        int filled = (int) (ratio * length);
        return "<green>" + "█".repeat(filled) + "<dark_gray>" + "█".repeat(length - filled)
                + " <gray>(" + String.format("%.1f", ratio * 100) + "%)";
    }

    private void fillItems(Inventory inv, ConfigurationSection cfg, Player player, ClanData clan) {
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) return;
        for (String key : items.getKeys(false)) {
            ConfigurationSection itemCfg = items.getConfigurationSection(key);
            if (itemCfg == null) continue;
            List<Integer> slots = resolveSlots(itemCfg);
            if (slots.isEmpty()) continue;
            ItemStack item = buildItemFromSection(itemCfg, player, clan);
            for (int slot : slots) {
                if (slot >= 0 && slot < inv.getSize()) inv.setItem(slot, item);
            }
        }
    }

    private List<Integer> resolveSlots(ConfigurationSection cfg) {
        List<Integer> result = new ArrayList<>();
        if (cfg.isList("slots")) {
            result.addAll(cfg.getIntegerList("slots"));
        } else if (cfg.contains("slot")) {
            result.add(cfg.getInt("slot"));
        }
        return result;
    }

    private ItemStack buildItemFromSection(ConfigurationSection cfg, Player player, ClanData clan) {
        String matStr = cfg.getString("material", "STONE");
        Material mat = parseMaterial(matStr);
        String nameRaw = cfg.getString("name", "");
        if (clan != null) nameRaw = applyPlaceholders(nameRaw, player, clan);
        List<String> loreRaw = cfg.getStringList("lore");
        List<String> lore = loreRaw.stream()
                .map(l -> clan != null ? applyPlaceholders(l, player, clan) : l)
                .collect(Collectors.toList());
        boolean enchanted = cfg.getBoolean("enchanted", false);
        ItemStack item = buildItem(mat, nameRaw, lore, enchanted);

        ConfigurationSection itemCfg = cfg;
        String action = itemCfg.getString("action", "NONE");
        return item;
    }

    private ItemStack buildItem(Material mat, String name, List<String> lore, boolean enchanted) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        if (!name.isEmpty()) meta.displayName(mm.deserialize(ensureItemNameStyle(name)));
        if (!lore.isEmpty()) {
            meta.lore(lore.stream().map(l -> mm.deserialize(ensureLoreStyle(l))).collect(Collectors.toList()));
        }
        if (enchanted) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        item.setItemMeta(meta);
        return item;
    }

    private String ensureItemNameStyle(String s) {
        if (s.contains("<gradient") || s.contains("<bold")) return s;
        return s.replaceAll("&[0-9a-fA-Fk-oK-OrR]", "")
                .replaceAll("(:\\s*)([0-9,\\.%+]+)", "$1<#f0e173>$2<#ffc800>")
                .replaceAll("(%[^%]+%)", "<#f0e173>$1<#ffc800>");
    }

    private String ensureLoreStyle(String s) {
        return s.replaceAll("&[0-9a-fA-Fk-oK-OrR]", "");
    }

    private Material parseMaterial(String str) {
        try {
            return Material.valueOf(str.toUpperCase());
        } catch (IllegalArgumentException e) {
            return Material.STONE;
        }
    }

    private Component parseTitle(String raw) {
        return mm.deserialize(raw);
    }

    private String applyPlaceholders(String text, Player player, ClanData clan) {
        if (clan == null) return text;
        ClanRole role = clan.getMemberRole(player.getUniqueId());
        String roleStr = role != null ? role.getDisplayName() : "NONE";
        return text
                .replace("%nova_clan_name%", clan.getName())
                .replace("%nova_clan_level%", String.valueOf(clan.getLevel()))
                .replace("%nova_clan_points%", String.valueOf(clan.getPoints()))
                .replace("%nova_clan_balance%", plugin.getClanManager().formatMoney(clan.getBalance()))
                .replace("%nova_clan_role%", roleStr)
                .replace("{clan}", clan.getName())
                .replace("{level}", String.valueOf(clan.getLevel()))
                .replace("{points}", String.valueOf(clan.getPoints()))
                .replace("{balance}", plugin.getClanManager().formatMoney(clan.getBalance()))
                .replace("{role}", roleStr)
                .replace("{members}", String.valueOf(clan.getMemberCount()))
                .replace("{player}", player.getName());
    }

    public boolean isMembersMenu(String title) {
        return title != null && title.contains("Members");
    }

    public boolean isTopMenu(String title) {
        return title != null && title.contains("Top");
    }

    public boolean isQuestMenu(String title) {
        return title != null && title.contains("Quest");
    }

    public void handleMainMenuSlotClick(Player player, int slot, String title) {
        DataManager dm = plugin.getDataManager();
        if (!dm.isInClan(player.getUniqueId())) {
            plugin.getMessageManager().sendRaw(player,
                    "&8[&e" + "NovaClans" + "&8] &r<#ffc800> /clan create <name>");
            return;
        }
        ClanData clan = dm.getClanByPlayer(player.getUniqueId());
        String clanMenuSection = "clan-menu";
        ConfigurationSection cfg = clanMenuConfig.getConfigurationSection(clanMenuSection);
        if (cfg == null) return;
        handleClickInConfig(player, slot, cfg);
    }

    public void handleSubMenuSlotClick(Player player, int slot, String title) {
        if (title.contains("Storage")) {
            ConfigurationSection cfg = storageMenuConfig.getConfigurationSection("storage-menu");
            if (cfg != null) handleClickInConfig(player, slot, cfg);
        }
    }

    public void handleStorageInfoSlotClick(Player player, int slot) {
        ConfigurationSection cfg = storageMenuConfig.getConfigurationSection("storage-menu");
        if (cfg != null) handleClickInConfig(player, slot, cfg);
    }

    private void handleClickInConfig(Player player, int slot, ConfigurationSection cfg) {
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) return;
        for (String key : items.getKeys(false)) {
            ConfigurationSection itemCfg = items.getConfigurationSection(key);
            if (itemCfg == null) continue;
            List<Integer> slots = resolveSlots(itemCfg);
            if (!slots.contains(slot)) continue;
            String action = itemCfg.getString("action", "NONE");
            executeAction(player, action);
            return;
        }
    }

    private void executeAction(Player player, String action) {
        switch (action.toUpperCase()) {
            case "OPEN_STORAGE_INFO" -> openStorageInfoMenu(player);
            case "OPEN_VAULT" -> {
                DataManager dm = plugin.getDataManager();
                if (dm.isInClan(player.getUniqueId())) {
                    openClanVault(player, dm.getClanByPlayer(player.getUniqueId()));
                }
            }
            case "OPEN_QUESTS" -> openQuestMenu(player);
            case "OPEN_TOP" -> openTopMenu(player);
            case "OPEN_MEMBERS" -> openMembersMenu(player);
            case "OPEN_MAIN" -> openMainMenu(player);
            case "BACK" -> openMainMenu(player);
            case "OPEN_CREATE_CHAT" -> player.closeInventory();
            default -> {}
        }
    }

    private String getRoleColorMM(ClanRole role) {
        return switch (role) {
            case LEADER -> "<red>";
            case DEPUTY -> "<yellow>";
            default -> "<gray>";
        };
    }

    private String getRoleIcon(ClanRole role) {
        return switch (role) {
            case LEADER -> "★";
            case DEPUTY -> "◆";
            default -> "•";
        };
    }
}
