package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;

public class ClanManager {

    private final Map<UUID, PendingInvite> pendingInvites;
    private final Set<UUID> clanChatToggled;
    private final DataManager dataManager;
    private final MessageManager messageManager;
    private final NovaClans plugin;
    private Economy economy;

    public ClanManager(NovaClans plugin) {
        this.plugin = plugin;
        this.dataManager = plugin.getDataManager();
        this.messageManager = plugin.getMessageManager();
        this.pendingInvites = new HashMap<>();
        this.clanChatToggled = new HashSet<>();
        setupVault();
    }

    private void setupVault() {
        var rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            plugin.getLogger().warning("Vault Economy not found!");
            return;
        }
        economy = rsp.getProvider();
    }

    public Economy getEconomy() { return economy; }

    public int getMaxMembersForLevel(int level) {
        String key = level + "-level";
        return plugin.getConfig().getInt("max-members-by-level." + key, level * 2);
    }

    public boolean createClan(Player player, String name) {
        int minLen = plugin.getConfig().getInt("clan-name-min-length", 3);
        int maxLen = plugin.getConfig().getInt("clan-name-max-length", 16);
        if (name.length() < minLen || name.length() > maxLen || !name.matches("[a-zA-Z0-9_]+")) {
            messageManager.send(player, "clan-create-invalid-name",
                    "{min}", minLen, "{max}", maxLen);
            return false;
        }
        if (dataManager.isInClan(player.getUniqueId())) {
            ClanData existing = dataManager.getClanByPlayer(player.getUniqueId());
            messageManager.send(player, "already-in-clan", "{clan}", existing.getName());
            return false;
        }
        if (dataManager.clanExists(name)) {
            messageManager.send(player, "clan-create-name-taken");
            return false;
        }
        double price = plugin.getConfig().getDouble("clan-create-price", 50000);
        if (!economy.has(player, price)) {
            messageManager.send(player, "clan-create-no-money", "{amount}", formatMoney(price));
            return false;
        }
        economy.withdrawPlayer(player, price);
        ClanData clan = new ClanData(name, player.getUniqueId());
        clan.setPvpEnabled(plugin.getConfig().getBoolean("pvp-enabled-by-default", true));
        clan.addMember(player.getUniqueId(), player.getName(), ClanRole.LEADER);
        dataManager.createClan(clan);
        dataManager.save();
        messageManager.send(player, "clan-create-success", "{clan}", name, "{amount}", formatMoney(price));
        return true;
    }

    public boolean deleteClan(Player player) {
        if (!dataManager.isInClan(player.getUniqueId())) {
            messageManager.send(player, "not-in-clan");
            return false;
        }
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        ClanRole role = clan.getMemberRole(player.getUniqueId());
        if (role == null || !role.isAtLeast(ClanRole.LEADER)) {
            messageManager.send(player, "clan-delete-no-permission");
            return false;
        }
        for (UUID uuid : new HashSet<>(clan.getMembers().keySet())) {
            Player online = Bukkit.getPlayer(uuid);
            if (online != null && !online.equals(player)) {
                messageManager.send(online, "clan-kick-notify", "{clan}", clan.getName());
            }
        }
        dataManager.deleteClan(clan.getName());
        dataManager.save();
        messageManager.send(player, "clan-delete-success", "{clan}", clan.getName());
        return true;
    }

    public boolean invitePlayer(Player inviter, Player target) {
        if (!dataManager.isInClan(inviter.getUniqueId())) {
            messageManager.send(inviter, "not-in-clan");
            return false;
        }
        ClanData clan = dataManager.getClanByPlayer(inviter.getUniqueId());
        ClanRole role = clan.getMemberRole(inviter.getUniqueId());
        if (role == null || !role.isAtLeast(ClanRole.DEPUTY)) {
            messageManager.send(inviter, "clan-invite-no-permission");
            return false;
        }
        if (dataManager.isInClan(target.getUniqueId())) {
            messageManager.send(inviter, "target-already-in-clan", "{player}", target.getName());
            return false;
        }
        int maxMembers = getMaxMembersForLevel(clan.getLevel());
        if (clan.getMemberCount() >= maxMembers) {
            messageManager.send(inviter, "clan-invite-max-members", "{max}", maxMembers);
            return false;
        }
        pendingInvites.put(target.getUniqueId(), new PendingInvite(inviter.getUniqueId(), clan.getName()));
        messageManager.send(inviter, "clan-invite-sent", "{player}", target.getName());
        messageManager.send(target, "clan-invite-received", "{player}", inviter.getName(), "{clan}", clan.getName());
        Bukkit.getScheduler().runTaskLater(plugin, () -> pendingInvites.remove(target.getUniqueId()), 1200L);
        return true;
    }

    public boolean acceptInvite(Player player) {
        PendingInvite invite = pendingInvites.get(player.getUniqueId());
        if (invite == null) {
            messageManager.send(player, "clan-invite-no-pending");
            return false;
        }
        if (dataManager.isInClan(player.getUniqueId())) {
            ClanData existing = dataManager.getClanByPlayer(player.getUniqueId());
            messageManager.send(player, "already-in-clan", "{clan}", existing.getName());
            pendingInvites.remove(player.getUniqueId());
            return false;
        }
        ClanData clan = dataManager.getClan(invite.getClanName());
        if (clan == null) {
            pendingInvites.remove(player.getUniqueId());
            return false;
        }
        int maxMembers = getMaxMembersForLevel(clan.getLevel());
        if (clan.getMemberCount() >= maxMembers) {
            messageManager.send(player, "clan-invite-max-members", "{max}", maxMembers);
            pendingInvites.remove(player.getUniqueId());
            return false;
        }
        pendingInvites.remove(player.getUniqueId());
        dataManager.addPlayerToClan(player.getUniqueId(), clan, ClanRole.MEMBER, player.getName());
        dataManager.save();
        messageManager.send(player, "clan-invite-accepted", "{player}", player.getName(), "{clan}", clan.getName());
        notifyClan(clan, "clan-invite-accepted", player.getUniqueId(), "{player}", player.getName());
        return true;
    }

    public boolean denyInvite(Player player) {
        PendingInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            messageManager.send(player, "clan-invite-no-pending");
            return false;
        }
        Player inviter = Bukkit.getPlayer(invite.getInviterUUID());
        if (inviter != null) {
            messageManager.send(inviter, "clan-invite-denied", "{player}", player.getName());
        }
        return true;
    }

    public boolean kickPlayer(Player kicker, Player target) {
        if (!dataManager.isInClan(kicker.getUniqueId())) {
            messageManager.send(kicker, "not-in-clan");
            return false;
        }
        ClanData clan = dataManager.getClanByPlayer(kicker.getUniqueId());
        ClanRole kickerRole = clan.getMemberRole(kicker.getUniqueId());
        if (kickerRole == null || !kickerRole.isAtLeast(ClanRole.DEPUTY)) {
            messageManager.send(kicker, "clan-kick-no-permission");
            return false;
        }
        if (kicker.equals(target)) {
            messageManager.send(kicker, "clan-kick-yourself");
            return false;
        }
        if (!clan.hasMember(target.getUniqueId())) {
            messageManager.send(kicker, "target-not-in-clan", "{player}", target.getName());
            return false;
        }
        ClanRole targetRole = clan.getMemberRole(target.getUniqueId());
        if (targetRole != null && targetRole.isAtLeast(ClanRole.LEADER)) {
            messageManager.send(kicker, "clan-kick-leader");
            return false;
        }
        dataManager.removePlayerFromClan(target.getUniqueId(), clan);
        dataManager.save();
        messageManager.send(kicker, "clan-kick-success", "{player}", target.getName());
        messageManager.send(target, "clan-kick-notify", "{clan}", clan.getName());
        return true;
    }

    public boolean promoteMember(Player leader, Player target) {
        if (!dataManager.isInClan(leader.getUniqueId())) {
            messageManager.send(leader, "not-in-clan");
            return false;
        }
        ClanData clan = dataManager.getClanByPlayer(leader.getUniqueId());
        ClanRole leaderRole = clan.getMemberRole(leader.getUniqueId());
        if (leaderRole == null || !leaderRole.isAtLeast(ClanRole.LEADER)) {
            messageManager.send(leader, "clan-promote-no-permission");
            return false;
        }
        if (!clan.hasMember(target.getUniqueId())) {
            messageManager.send(leader, "target-not-in-clan", "{player}", target.getName());
            return false;
        }
        ClanMember leaderMember = clan.getMember(leader.getUniqueId());
        if (leaderMember != null) leaderMember.setRole(ClanRole.DEPUTY);
        clan.setLeader(target.getUniqueId());
        ClanMember targetMember = clan.getMember(target.getUniqueId());
        if (targetMember != null) targetMember.setRole(ClanRole.LEADER);
        dataManager.save();
        messageManager.send(leader, "clan-promote-success", "{player}", target.getName());
        messageManager.send(target, "clan-promote-notify", "{clan}", clan.getName());
        return true;
    }

    public boolean setRole(Player setter, Player target, ClanRole newRole) {
        if (!dataManager.isInClan(setter.getUniqueId())) {
            messageManager.send(setter, "not-in-clan");
            return false;
        }
        ClanData clan = dataManager.getClanByPlayer(setter.getUniqueId());
        ClanRole setterRole = clan.getMemberRole(setter.getUniqueId());
        if (setterRole == null || !setterRole.isAtLeast(ClanRole.LEADER)) {
            messageManager.send(setter, "clan-role-no-permission");
            return false;
        }
        if (setter.equals(target)) {
            messageManager.send(setter, "clan-role-self");
            return false;
        }
        if (!clan.hasMember(target.getUniqueId())) {
            messageManager.send(setter, "target-not-in-clan", "{player}", target.getName());
            return false;
        }
        if (newRole == null || newRole == ClanRole.LEADER) {
            messageManager.send(setter, "clan-role-invalid");
            return false;
        }
        ClanMember member = clan.getMember(target.getUniqueId());
        if (member != null) member.setRole(newRole);
        dataManager.save();
        messageManager.send(setter, "clan-role-set", "{player}", target.getName(), "{role}", newRole.getDisplayName());
        messageManager.send(target, "clan-role-notify", "{role}", newRole.getDisplayName());
        return true;
    }

    public boolean togglePvp(Player player) {
        if (!dataManager.isInClan(player.getUniqueId())) {
            messageManager.send(player, "not-in-clan");
            return false;
        }
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        ClanRole role = clan.getMemberRole(player.getUniqueId());
        if (role == null || !role.isAtLeast(ClanRole.LEADER)) {
            messageManager.send(player, "clan-pvp-no-permission");
            return false;
        }
        clan.setPvpEnabled(!clan.isPvpEnabled());
        dataManager.save();
        if (clan.isPvpEnabled()) {
            messageManager.send(player, "clan-pvp-enabled");
        } else {
            messageManager.send(player, "clan-pvp-disabled");
        }
        return true;
    }

    public boolean isClanPvpBlocked(Player attacker, Player victim) {
        if (!dataManager.isInClan(attacker.getUniqueId())) return false;
        if (!dataManager.isInClan(victim.getUniqueId())) return false;
        ClanData attackerClan = dataManager.getClanByPlayer(attacker.getUniqueId());
        ClanData victimClan = dataManager.getClanByPlayer(victim.getUniqueId());
        if (attackerClan == null || victimClan == null) return false;
        if (!attackerClan.getName().equalsIgnoreCase(victimClan.getName())) return false;
        return !attackerClan.isPvpEnabled();
    }

    public boolean toggleClanChat(Player player) {
        if (!dataManager.isInClan(player.getUniqueId())) {
            messageManager.send(player, "not-in-clan");
            return false;
        }
        UUID uuid = player.getUniqueId();
        if (clanChatToggled.contains(uuid)) {
            clanChatToggled.remove(uuid);
            messageManager.send(player, "clan-chat-toggled-off");
            return false;
        } else {
            clanChatToggled.add(uuid);
            messageManager.send(player, "clan-chat-toggled-on");
            return true;
        }
    }

    public boolean isClanChatToggled(UUID uuid) { return clanChatToggled.contains(uuid); }

    public void sendClanChat(Player player, String message) {
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        if (clan == null) return;
        String format = messageManager.getRaw("clan-chat-format")
                .replace("{clan}", clan.getName())
                .replace("{player}", player.getName())
                .replace("{message}", message);
        for (UUID uuid : clan.getMembers().keySet()) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null) member.sendMessage(MiniMessage.miniMessage().deserialize(format));
        }
        plugin.getLogger().info("[ClanChat][" + clan.getName() + "] " + player.getName() + ": " + message);
    }

    public boolean depositToStorage(Player player, double amount) {
        if (!dataManager.isInClan(player.getUniqueId())) {
            messageManager.send(player, "not-in-clan");
            return false;
        }
        if (amount <= 0) {
            messageManager.send(player, "clan-storage-invalid-amount");
            return false;
        }
        if (!economy.has(player, amount)) {
            messageManager.send(player, "clan-storage-no-money");
            return false;
        }
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        economy.withdrawPlayer(player, amount);
        clan.addBalance(amount);
        dataManager.save();
        messageManager.send(player, "clan-storage-deposit-success",
                "{amount}", formatMoney(amount), "{balance}", formatMoney(clan.getBalance()));
        return true;
    }

    public boolean withdrawFromStorage(Player player, double amount) {
        if (!dataManager.isInClan(player.getUniqueId())) {
            messageManager.send(player, "not-in-clan");
            return false;
        }
        if (amount <= 0) {
            messageManager.send(player, "clan-storage-invalid-amount");
            return false;
        }
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        if (clan.getBalance() < amount) {
            messageManager.send(player, "clan-storage-not-enough", "{balance}", formatMoney(clan.getBalance()));
            return false;
        }
        clan.addBalance(-amount);
        economy.depositPlayer(player, amount);
        dataManager.save();
        messageManager.send(player, "clan-storage-withdraw-success",
                "{amount}", formatMoney(amount), "{balance}", formatMoney(clan.getBalance()));
        return true;
    }

    public void addPoints(ClanData clan, long amount) {
        clan.addPoints(amount);
        checkLevelUp(clan);
        dataManager.save();
    }

    private void checkLevelUp(ClanData clan) {
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (clan.getLevel() >= maxLevel) return;
        int nextLevel = clan.getLevel() + 1;
        long required = plugin.getConfig().getLong("levels." + nextLevel, Long.MAX_VALUE);
        if (clan.getPoints() >= required) {
            clan.setLevel(nextLevel);
            messageManager.broadcast("clan-levelup-broadcast",
                    "{clan}", clan.getName(),
                    "{level}", clan.getLevel(),
                    "{points}", clan.getPoints());
        }
    }

    public String getClanTag(ClanData clan) {
        return "[ClanChat][" + clan.getName() + "]";
    }

    public Map<UUID, PendingInvite> getPendingInvites() { return pendingInvites; }

    private void notifyClan(ClanData clan, String key, UUID exclude, Object... args) {
        for (UUID uuid : clan.getMembers().keySet()) {
            if (uuid.equals(exclude)) continue;
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) messageManager.send(p, key, args);
        }
    }

    public String formatMoney(double amount) {
        if (amount == Math.floor(amount)) {
            return String.format("%,.0f", amount);
        }
        return String.format("%,.2f", amount);
    }

    public static class PendingInvite {
        private final UUID inviterUUID;
        private final String clanName;

        public PendingInvite(UUID inviterUUID, String clanName) {
            this.inviterUUID = inviterUUID;
            this.clanName = clanName;
        }

        public UUID getInviterUUID() { return inviterUUID; }
        public String getClanName() { return clanName; }
    }
}
