package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.managers.MenuManager;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

public class MenuListener implements Listener {

    private final NovaClans plugin;
    private final MenuManager menuManager;

    public MenuListener(NovaClans plugin) {
        this.plugin = plugin;
        this.menuManager = plugin.getMenuManager();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title;
        try {
            title = PlainTextComponentSerializer.plainText().serialize(event.getView().title());
        } catch (Exception e) {
            return;
        }

        boolean inVault = menuManager.isInStorageVault(player.getUniqueId());
        boolean inStorageInfo = menuManager.isInStorageInfo(player.getUniqueId());

        if (inVault) return;

        if (!menuManager.isNovaMenu(title) && !inStorageInfo && !inVault) return;

        event.setCancelled(true);

        if (event.getCurrentItem() == null) return;
        int slot = event.getSlot();

        if (inStorageInfo) {
            menuManager.handleStorageInfoSlotClick(player, slot);
            return;
        }

        if (menuManager.isMembersMenu(title) || menuManager.isTopMenu(title) || menuManager.isQuestMenu(title)) {
            menuManager.handleSubMenuSlotClick(player, slot, title);
            return;
        }

        // Check if it's a Storage sub-menu (not vault, not storage-info flag, but storage title)
        if (title.contains("Қойма") || title.contains("Storage")) {
            menuManager.handleSubMenuSlotClick(player, slot, title);
            return;
        }

        menuManager.handleMainMenuSlotClick(player, slot, title);
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (menuManager.isInStorageVault(player.getUniqueId())) return;
        String title;
        try {
            title = PlainTextComponentSerializer.plainText().serialize(event.getView().title());
        } catch (Exception e) {
            return;
        }
        if (menuManager.isNovaMenu(title) || menuManager.isInStorageInfo(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (!menuManager.isInStorageVault(player.getUniqueId())) {
            menuManager.removeFromStorageTracking(player.getUniqueId());
            return;
        }
        Inventory inv = event.getInventory();
        try {
            menuManager.saveVaultAndClose(player, inv);
        } catch (Exception e) {
            plugin.getLogger().warning("Error saving vault: " + e.getMessage());
        }
    }
}
